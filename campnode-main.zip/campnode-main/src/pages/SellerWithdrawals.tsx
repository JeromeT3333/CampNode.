 import { useState, useEffect } from "react";
 import { useNavigate } from "react-router-dom";
 import { MainLayout } from "@/components/layout/MainLayout";
 import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
 import { Button } from "@/components/ui/button";
 import { Badge } from "@/components/ui/badge";
 import { Input } from "@/components/ui/input";
 import { Label } from "@/components/ui/label";
 import { useAuth } from "@/hooks/useAuth";
 import { supabase } from "@/integrations/supabase/client";
 import { toast } from "sonner";
 import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
 } from "@/components/ui/select";
 import {
   Table,
   TableBody,
   TableCell,
   TableHead,
   TableHeader,
   TableRow,
 } from "@/components/ui/table";
 import {
   Dialog,
   DialogContent,
   DialogHeader,
   DialogTitle,
   DialogFooter,
 } from "@/components/ui/dialog";
 import {
   Wallet,
   ArrowUpRight,
   CheckCircle,
   XCircle,
   Clock,
   Loader2,
   Building2,
   Plus,
 } from "lucide-react";
import { nigerianBanks as NIGERIAN_BANKS } from "@/data/nigerianBanks";
 
 interface BankDetails {
   id: string;
   bank_code: string;
   bank_name: string;
   account_number: string;
   account_name: string;
   verification_status: string;
 }
 
 interface Payout {
   id: string;
   amount: number;
   status: string;
   created_at: string;
   account_name: string;
   bank_code: string;
 }
 
 interface Transaction {
   id: string;
   seller_amount: number;
   payment_status: string;
 }
 
 const SellerWithdrawals = () => {
   const navigate = useNavigate();
   const { user, loading: authLoading } = useAuth();
   const [bankDetails, setBankDetails] = useState<BankDetails | null>(null);
   const [payouts, setPayouts] = useState<Payout[]>([]);
   const [availableBalance, setAvailableBalance] = useState(0);
   const [loading, setLoading] = useState(true);
   const [withdrawing, setWithdrawing] = useState(false);
   
   // Bank setup dialog
   const [bankDialog, setBankDialog] = useState(false);
   const [selectedBank, setSelectedBank] = useState("");
   const [accountNumber, setAccountNumber] = useState("");
   const [accountName, setAccountName] = useState("");
   const [verifying, setVerifying] = useState(false);
 
   useEffect(() => {
     if (!authLoading && !user) {
       navigate("/auth");
     }
   }, [user, authLoading, navigate]);
 
   useEffect(() => {
     if (user) {
       fetchData();
     }
   }, [user]);
 
   const fetchData = async () => {
     if (!user) return;
 
     try {
       // Fetch bank details
       const { data: bank } = await supabase
         .from("seller_bank_details")
         .select("*")
         .eq("seller_id", user.id)
         .single();
       
       setBankDetails(bank);
 
       // Fetch payouts
       const { data: payoutData } = await supabase
         .from("payouts")
         .select("*")
         .eq("seller_id", user.id)
         .order("created_at", { ascending: false });
       
       setPayouts(payoutData || []);
 
       // Calculate available balance
       const { data: transactions } = await supabase
         .from("transactions")
         .select("seller_amount, payment_status")
         .eq("seller_id", user.id)
         .eq("payment_status", "completed");
 
       const totalEarnings = (transactions || []).reduce(
         (sum: number, t: Transaction) => sum + Number(t.seller_amount),
         0
       );
 
       const totalWithdrawn = (payoutData || [])
         .filter((p) => p.status === "completed" || p.status === "processing")
         .reduce((sum, p) => sum + Number(p.amount), 0);
 
       setAvailableBalance(totalEarnings - totalWithdrawn);
     } catch (error) {
       console.error("Error fetching data:", error);
     } finally {
       setLoading(false);
     }
   };
 
   const verifyBankAccount = async () => {
     if (!selectedBank || accountNumber.length !== 10) {
       toast.error("Please enter valid bank details");
       return;
     }
 
     setVerifying(true);
     try {
       const { data, error } = await supabase.functions.invoke("verify-bank-account", {
         body: { bank_code: selectedBank, account_number: accountNumber }
       });
 
       if (error) throw error;
       if (data.status !== "success") throw new Error(data.message);
 
       setAccountName(data.data.account_name);
       toast.success("Account verified!");
     } catch (error: any) {
       toast.error(error.message || "Failed to verify account");
       setAccountName("");
     } finally {
       setVerifying(false);
     }
   };
 
   const saveBankDetails = async () => {
     if (!user || !accountName) return;
 
     try {
       const bankName = NIGERIAN_BANKS.find(b => b.code === selectedBank)?.name || "";
       
       const { error } = await supabase
         .from("seller_bank_details")
         .upsert({
           seller_id: user.id,
           bank_code: selectedBank,
           bank_name: bankName,
           account_number: accountNumber,
           account_name: accountName,
           verification_status: "verified"
         });
 
       if (error) throw error;
       toast.success("Bank details saved!");
       setBankDialog(false);
       fetchData();
     } catch (error: any) {
       toast.error(error.message || "Failed to save bank details");
     }
   };
 
   const requestWithdrawal = async () => {
     if (!user || !bankDetails || availableBalance < 100) {
       toast.error("Minimum withdrawal is ₦100");
       return;
     }
 
     setWithdrawing(true);
     try {
       const payoutRef = `WITHDRAW-${user.id.slice(0, 8)}-${Date.now()}`;
 
       const { error } = await supabase.from("payouts").insert({
         payout_reference: payoutRef,
         seller_id: user.id,
         amount: availableBalance,
         bank_code: bankDetails.bank_code,
         account_number: bankDetails.account_number,
         account_name: bankDetails.account_name,
         status: "pending"
       });
 
       if (error) throw error;
       toast.success("Withdrawal requested! It will be processed shortly.");
       fetchData();
     } catch (error: any) {
       toast.error(error.message || "Failed to request withdrawal");
     } finally {
       setWithdrawing(false);
     }
   };
 
   const formatCurrency = (amount: number) => {
     return new Intl.NumberFormat("en-NG", {
       style: "currency",
       currency: "NGN",
       minimumFractionDigits: 0,
     }).format(amount);
   };
 
   const getStatusBadge = (status: string) => {
     switch (status) {
       case "completed":
         return <Badge className="gap-1 bg-primary/10 text-primary"><CheckCircle className="h-3 w-3" />Completed</Badge>;
       case "processing":
         return <Badge variant="secondary" className="gap-1"><Clock className="h-3 w-3" />Processing</Badge>;
       case "failed":
         return <Badge variant="destructive" className="gap-1"><XCircle className="h-3 w-3" />Failed</Badge>;
       default:
         return <Badge variant="outline" className="gap-1"><Clock className="h-3 w-3" />Pending</Badge>;
     }
   };
 
   if (authLoading || loading) {
     return (
       <MainLayout>
         <div className="min-h-screen flex items-center justify-center">
           <Loader2 className="h-8 w-8 animate-spin text-primary" />
         </div>
       </MainLayout>
     );
   }
 
   return (
     <MainLayout>
       <div className="min-h-screen px-4 py-6">
         <div className="max-w-4xl mx-auto space-y-6">
           <div>
             <div className="flex items-center gap-2 mb-2">
               <Wallet className="h-6 w-6 text-primary" />
               <h1 className="text-2xl font-bold">Withdrawals</h1>
             </div>
             <p className="text-muted-foreground">Manage your earnings and withdrawals</p>
           </div>
 
           {/* Balance Card */}
           <Card className="bg-gradient-to-br from-primary/10 to-secondary/10">
             <CardContent className="pt-6">
               <div className="flex items-center justify-between">
                 <div>
                   <p className="text-sm text-muted-foreground">Available Balance</p>
                   <p className="text-3xl font-bold text-foreground">{formatCurrency(availableBalance)}</p>
                 </div>
                 <Button
                   onClick={requestWithdrawal}
                   disabled={!bankDetails || availableBalance < 100 || withdrawing}
                   className="gap-2"
                 >
                   {withdrawing ? (
                     <Loader2 className="h-4 w-4 animate-spin" />
                   ) : (
                     <ArrowUpRight className="h-4 w-4" />
                   )}
                   Withdraw
                 </Button>
               </div>
             </CardContent>
           </Card>
 
           {/* Bank Details */}
           <Card>
             <CardHeader>
               <CardTitle className="flex items-center gap-2">
                 <Building2 className="h-5 w-5" />
                 Bank Account
               </CardTitle>
               <CardDescription>Your payout destination</CardDescription>
             </CardHeader>
             <CardContent>
               {bankDetails ? (
                 <div className="flex items-center justify-between">
                   <div>
                     <p className="font-medium">{bankDetails.account_name}</p>
                     <p className="text-sm text-muted-foreground">
                       {bankDetails.bank_name} • {bankDetails.account_number}
                     </p>
                   </div>
                   <Button variant="outline" onClick={() => setBankDialog(true)}>
                     Change
                   </Button>
                 </div>
               ) : (
                 <Button onClick={() => setBankDialog(true)} className="gap-2">
                   <Plus className="h-4 w-4" />
                   Add Bank Account
                 </Button>
               )}
             </CardContent>
           </Card>
 
           {/* Payout History */}
           <Card>
             <CardHeader>
               <CardTitle>Withdrawal History</CardTitle>
             </CardHeader>
             <CardContent>
               {payouts.length === 0 ? (
                 <p className="text-center text-muted-foreground py-8">No withdrawals yet</p>
               ) : (
                 <Table>
                   <TableHeader>
                     <TableRow>
                       <TableHead>Amount</TableHead>
                       <TableHead>Account</TableHead>
                       <TableHead>Status</TableHead>
                       <TableHead>Date</TableHead>
                     </TableRow>
                   </TableHeader>
                   <TableBody>
                     {payouts.map((payout) => (
                       <TableRow key={payout.id}>
                         <TableCell className="font-medium">{formatCurrency(payout.amount)}</TableCell>
                         <TableCell>{payout.account_name}</TableCell>
                         <TableCell>{getStatusBadge(payout.status)}</TableCell>
                         <TableCell>
                           {new Date(payout.created_at).toLocaleDateString("en-NG")}
                         </TableCell>
                       </TableRow>
                     ))}
                   </TableBody>
                 </Table>
               )}
             </CardContent>
           </Card>
         </div>
       </div>
 
       {/* Bank Details Dialog */}
       <Dialog open={bankDialog} onOpenChange={setBankDialog}>
         <DialogContent>
           <DialogHeader>
             <DialogTitle>Add Bank Account</DialogTitle>
           </DialogHeader>
           <div className="space-y-4 py-4">
             <div className="space-y-2">
               <Label>Bank</Label>
               <Select value={selectedBank} onValueChange={setSelectedBank}>
                 <SelectTrigger>
                   <SelectValue placeholder="Select your bank" />
                 </SelectTrigger>
                 <SelectContent>
                   {NIGERIAN_BANKS.map((bank) => (
                     <SelectItem key={bank.code} value={bank.code}>
                       {bank.name}
                     </SelectItem>
                   ))}
                 </SelectContent>
               </Select>
             </div>
             <div className="space-y-2">
               <Label>Account Number</Label>
               <div className="flex gap-2">
                 <Input
                   value={accountNumber}
                   onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                   placeholder="0123456789"
                   maxLength={10}
                 />
                 <Button
                   variant="outline"
                   onClick={verifyBankAccount}
                   disabled={!selectedBank || accountNumber.length !== 10 || verifying}
                 >
                   {verifying ? <Loader2 className="h-4 w-4 animate-spin" /> : "Verify"}
                 </Button>
               </div>
             </div>
             {accountName && (
               <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
                 <p className="text-sm text-muted-foreground">Account Name</p>
                 <p className="font-medium">{accountName}</p>
               </div>
             )}
           </div>
           <DialogFooter>
             <Button variant="outline" onClick={() => setBankDialog(false)}>Cancel</Button>
             <Button onClick={saveBankDetails} disabled={!accountName}>Save</Button>
           </DialogFooter>
         </DialogContent>
       </Dialog>
     </MainLayout>
   );
 };
 
 export default SellerWithdrawals;