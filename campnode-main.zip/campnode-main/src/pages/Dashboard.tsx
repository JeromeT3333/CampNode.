import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { 
  Package, 
  ShoppingCart, 
  Bell, 
  Receipt, 
  Store, 
  User, 
  Settings,
  Plus,
  ArrowRight,
  TrendingUp,
  Wallet,
  Loader2,
  MessageCircle
} from "lucide-react";
import { cn } from "@/lib/utils";

const stats = [
  { label: "Active Listings", value: "0", icon: Package, color: "text-primary" },
  { label: "Orders", value: "0", icon: ShoppingCart, color: "text-secondary" },
  { label: "Notifications", value: "0", icon: Bell, color: "text-accent" },
  { label: "Wallet Balance", value: "₦0", icon: Wallet, color: "text-campus-green" },
];

const quickActions = [
  { label: "Add Product", icon: Plus, href: "/add-product", color: "bg-primary" },
  { label: "Create Shop", icon: Store, href: "/create-shop", color: "bg-secondary" },
  { label: "View Orders", icon: ShoppingCart, href: "/orders", color: "bg-accent" },
  { label: "Messages", icon: MessageCircle, href: "/conversations", color: "bg-campus-blue" },
];

const menuItems = [
  { label: "My Listings", icon: Package, href: "/my-listings" },
  { label: "My Orders", icon: ShoppingCart, href: "/orders" },
  { label: "Messages", icon: MessageCircle, href: "/conversations" },
  { label: "Notifications", icon: Bell, href: "/notifications" },
  { label: "Receipts", icon: Receipt, href: "/receipts" },
  { label: "My Shops", icon: Store, href: "/my-shops" },
  { label: "Profile", icon: User, href: "/profile" },
  { label: "Settings", icon: Settings, href: "/settings" },
];

const Dashboard = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user) {
    return null; // Will redirect
  }

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-foreground">
              Welcome, {user.user_metadata?.full_name || user.email?.split("@")[0]}!
            </h1>
            <p className="text-muted-foreground">
              Manage your listings, orders, and shop
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="bg-card rounded-xl p-4 border border-border"
              >
                <div className="flex items-center justify-between mb-2">
                  <stat.icon className={cn("h-5 w-5", stat.color)} />
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {quickActions.map((action) => (
                <Link
                  key={action.label}
                  to={action.href}
                  className={cn(
                    "flex flex-col items-center justify-center p-6 rounded-xl",
                    "text-white transition-all duration-200",
                    "hover:scale-105 hover:shadow-lg",
                    action.color
                  )}
                >
                  <action.icon className="h-8 w-8 mb-2" />
                  <span className="font-medium text-sm">{action.label}</span>
                </Link>
              ))}
            </div>
          </div>

          {/* Menu Grid */}
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4">Menu</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {menuItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.href}
                  className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border hover:border-primary/50 hover:shadow-sm transition-all"
                >
                  <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                    <item.icon className="h-5 w-5 text-foreground" />
                  </div>
                  <span className="font-medium text-foreground">{item.label}</span>
                  <ArrowRight className="h-4 w-4 text-muted-foreground ml-auto" />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Dashboard;
