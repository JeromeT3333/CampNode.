import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { 
  CheckCircle, 
  XCircle, 
  Loader2, 
  Download, 
  ShoppingBag, 
  MessageCircle,
  Receipt,
  Home,
  ArrowRight
} from "lucide-react";
import { downloadReceiptAsPDF } from "@/lib/receiptGenerator";
import { format } from "date-fns";

interface TransactionDetails {
  transactionReference: string;
  productName: string;
  totalAmount: number;
  date: Date;
}

const PaymentComplete = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const [status, setStatus] = useState<"loading" | "success" | "failed">("loading");
  const [transaction, setTransaction] = useState<TransactionDetails | null>(null);
  const [orderId, setOrderId] = useState<string | null>(null);

  useEffect(() => {
    const checkPayment = async () => {
      const txStatus = searchParams.get("status");
      const txRef = searchParams.get("tx_ref");
      const transactionId = searchParams.get("transaction_id");

      if (txStatus === "successful" || txStatus === "completed") {
        setStatus("success");

        // Try to fetch transaction details
        if (txRef && user) {
          try {
            const { data: txData } = await supabase
              .from("transactions")
              .select(`
                transaction_reference,
                gross_amount,
                created_at,
                order_id,
                products (name)
              `)
              .eq("transaction_reference", txRef)
              .single();

            if (txData) {
              setTransaction({
                transactionReference: txData.transaction_reference,
                productName: txData.products?.name || "Product",
                totalAmount: txData.gross_amount,
                date: new Date(txData.created_at),
              });
              setOrderId(txData.order_id);
            }
          } catch (error) {
            console.error("Error fetching transaction:", error);
          }
        }
      } else if (txStatus === "cancelled" || txStatus === "failed") {
        setStatus("failed");
      } else {
        // Callback redirect without explicit status - assume success
        setTimeout(() => setStatus("success"), 1500);
      }
    };

    checkPayment();
  }, [searchParams, user]);

  const handleDownloadReceipt = () => {
    if (!transaction) return;

    downloadReceiptAsPDF({
      ...transaction,
      buyerName: user?.email || "Customer",
      status: "Completed",
      type: "buyer",
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <MainLayout>
      <div className="min-h-screen flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          {status === "loading" && (
            <Card>
              <CardContent className="pt-8 pb-8 text-center">
                <Loader2 className="h-16 w-16 animate-spin text-primary mx-auto mb-4" />
                <h1 className="text-2xl font-bold text-foreground mb-2">
                  Processing Payment...
                </h1>
                <p className="text-muted-foreground">
                  Please wait while we confirm your payment.
                </p>
              </CardContent>
            </Card>
          )}

          {status === "success" && (
            <Card className="overflow-hidden">
              {/* Success Header */}
              <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-8 text-center text-white">
                <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-10 w-10" />
                </div>
                <h1 className="text-2xl font-bold mb-1">Payment Successful!</h1>
                <p className="text-white/80">Your order has been placed</p>
              </div>

              <CardContent className="p-6 space-y-6">
                {/* Transaction Details */}
                {transaction && (
                  <div className="bg-muted/50 rounded-xl p-4 space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Reference</span>
                      <span className="font-mono text-xs">{transaction.transactionReference.slice(0, 20)}...</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Product</span>
                      <span className="font-medium text-right max-w-[60%] truncate">{transaction.productName}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Date</span>
                      <span>{format(transaction.date, "MMM d, yyyy h:mm a")}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between">
                      <span className="font-medium">Total Paid</span>
                      <span className="text-lg font-bold text-primary">
                        {formatPrice(transaction.totalAmount)}
                      </span>
                    </div>
                  </div>
                )}

                {/* What's Next */}
                <div className="space-y-2">
                  <h3 className="font-medium text-foreground flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-primary" />
                    What's Next?
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    You can now chat with the seller to arrange delivery. Your payment is held safely in escrow until you confirm receipt.
                  </p>
                </div>

                {/* Actions */}
                <div className="space-y-3">
                  {orderId && (
                    <Button
                      className="w-full gap-2"
                      onClick={() => navigate(`/chat/${orderId}`)}
                    >
                      <MessageCircle className="h-4 w-4" />
                      Chat with Seller
                    </Button>
                  )}

                  <Button
                    variant="outline"
                    className="w-full gap-2"
                    onClick={() => navigate("/orders")}
                  >
                    <ShoppingBag className="h-4 w-4" />
                    View My Orders
                  </Button>

                  {transaction && (
                    <Button
                      variant="ghost"
                      className="w-full gap-2"
                      onClick={handleDownloadReceipt}
                    >
                      <Download className="h-4 w-4" />
                      Download Receipt
                    </Button>
                  )}
                </div>

                <Separator />

                <Button
                  variant="link"
                  className="w-full gap-2"
                  onClick={() => navigate("/products")}
                >
                  <Home className="h-4 w-4" />
                  Continue Shopping
                </Button>
              </CardContent>
            </Card>
          )}

          {status === "failed" && (
            <Card>
              <CardContent className="pt-8 pb-8 text-center">
                <div className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-4">
                  <XCircle className="h-10 w-10 text-red-600" />
                </div>
                <h1 className="text-2xl font-bold text-foreground mb-2">
                  Payment Failed
                </h1>
                <p className="text-muted-foreground mb-6">
                  Your payment could not be processed. Please try again or use a different payment method.
                </p>
                <div className="space-y-2">
                  <Button
                    className="w-full"
                    onClick={() => navigate(-1)}
                  >
                    Try Again
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => navigate("/")}
                  >
                    Go Home
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default PaymentComplete;
