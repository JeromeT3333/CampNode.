import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { MainLayout } from "@/components/layout/MainLayout";
import { ProductCard } from "@/components/ProductCard";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MapPin, Star, Package, Truck, CheckCircle } from "lucide-react";

interface Shop {
  id: string;
  name: string;
  description: string | null;
  cover_image: string | null;
  profile_image: string | null;
  location: string | null;
  category: string;
  rating: number | null;
  has_delivery: boolean | null;
  is_verified: boolean | null;
  owner_id: string;
}

interface Product {
  id: string;
  name: string;
  price: number;
  image: string | null;
  description: string | null;
  category: string;
  location: string | null;
  is_service: boolean | null;
  is_sponsored: boolean | null;
}

interface Review {
  id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  reviewer: {
    full_name: string | null;
    avatar_url: string | null;
  } | null;
}

const ShopDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [shop, setShop] = useState<Shop | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchShopData = async () => {
      if (!id) return;

      try {
        // Fetch shop details
        const { data: shopData, error: shopError } = await supabase
          .from("shops")
          .select("*")
          .eq("id", id)
          .single();

        if (shopError) throw shopError;
        setShop(shopData);

        // Fetch shop products
        const { data: productsData, error: productsError } = await supabase
          .from("products")
          .select("*")
          .eq("shop_id", id)
          .eq("is_active", true);

        if (productsError) throw productsError;
        setProducts(productsData || []);

        // Fetch shop reviews
        const { data: reviewsData, error: reviewsError } = await supabase
          .from("reviews")
          .select(`
            id,
            rating,
            comment,
            created_at,
            reviewer_id
          `)
          .eq("shop_id", id)
          .order("created_at", { ascending: false });

        if (reviewsError) throw reviewsError;

        // Fetch reviewer profiles
        if (reviewsData && reviewsData.length > 0) {
          const reviewerIds = reviewsData.map((r) => r.reviewer_id);
          const { data: profilesData } = await supabase
            .from("profiles")
            .select("user_id, full_name, avatar_url")
            .in("user_id", reviewerIds);

          const profilesMap = new Map(
            profilesData?.map((p) => [p.user_id, p]) || []
          );

          const reviewsWithProfiles = reviewsData.map((review) => ({
            ...review,
            reviewer: profilesMap.get(review.reviewer_id) || null,
          }));

          setReviews(reviewsWithProfiles);
        }
      } catch (error) {
        console.error("Error fetching shop data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchShopData();
  }, [id]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-NG", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < rating ? "fill-yellow-400 text-yellow-400" : "text-muted"
        }`}
      />
    ));
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-64 w-full rounded-xl mb-6" />
          <Skeleton className="h-8 w-1/3 mb-4" />
          <Skeleton className="h-4 w-2/3 mb-8" />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-64 rounded-xl" />
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!shop) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Shop not found</h1>
          <Link to="/shops" className="text-primary hover:underline">
            Browse all shops
          </Link>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen bg-background">
        {/* Cover Image */}
        <div className="relative h-48 md:h-64 lg:h-80 bg-muted">
          {shop.cover_image ? (
            <img
              src={shop.cover_image}
              alt={`${shop.name} cover`}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-r from-primary/20 to-primary/10" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
        </div>

        <div className="container mx-auto px-4">
          {/* Shop Info */}
          <div className="relative -mt-16 mb-8">
            <Card className="overflow-visible">
              <CardContent className="pt-0">
                <div className="flex flex-col md:flex-row gap-6">
                  {/* Profile Image */}
                  <div className="-mt-12 md:-mt-16">
                    <Avatar className="h-24 w-24 md:h-32 md:w-32 border-4 border-background shadow-lg">
                      <AvatarImage src={shop.profile_image || undefined} />
                      <AvatarFallback className="text-2xl md:text-3xl bg-primary text-primary-foreground">
                        {shop.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                  </div>

                  {/* Shop Details */}
                  <div className="flex-1 pt-4 md:pt-6">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <h1 className="text-2xl md:text-3xl font-bold">{shop.name}</h1>
                      {shop.is_verified && (
                        <CheckCircle className="h-5 w-5 text-primary" />
                      )}
                    </div>

                    {shop.description && (
                      <p className="text-muted-foreground mb-4 max-w-2xl">
                        {shop.description}
                      </p>
                    )}

                    <div className="flex flex-wrap gap-4 text-sm">
                      <Badge variant="secondary">{shop.category}</Badge>
                      
                      {shop.location && (
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <MapPin className="h-4 w-4" />
                          {shop.location}
                        </span>
                      )}

                      <span className="flex items-center gap-1 text-muted-foreground">
                        <Package className="h-4 w-4" />
                        {products.length} Products
                      </span>

                      {shop.has_delivery && (
                        <span className="flex items-center gap-1 text-green-600">
                          <Truck className="h-4 w-4" />
                          Delivery Available
                        </span>
                      )}

                      {shop.rating && shop.rating > 0 && (
                        <span className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          {shop.rating.toFixed(1)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Products Section */}
          <section className="mb-12">
            <h2 className="text-xl font-semibold mb-6">Products</h2>
            {products.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {products.map((product, index) => (
                  <ProductCard
                    key={product.id}
                    product={{
                      id: product.id,
                      name: product.name,
                      price: Number(product.price),
                      image: product.image || "/placeholder.svg",
                      description: product.description || "",
                      category: product.category,
                      location: product.location || undefined,
                      isService: product.is_service || false,
                      isSponsored: product.is_sponsored || false,
                      shopName: shop.name,
                    }}
                    index={index}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No products available yet</p>
                </CardContent>
              </Card>
            )}
          </section>

          {/* Reviews Section */}
          <section className="mb-12">
            <h2 className="text-xl font-semibold mb-6">
              Reviews ({reviews.length})
            </h2>
            {reviews.length > 0 ? (
              <div className="space-y-4">
                {reviews.map((review) => (
                  <Card key={review.id}>
                    <CardContent className="py-4">
                      <div className="flex items-start gap-4">
                        <Avatar>
                          <AvatarImage src={review.reviewer?.avatar_url || undefined} />
                          <AvatarFallback>
                            {review.reviewer?.full_name?.charAt(0) || "U"}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium">
                              {review.reviewer?.full_name || "Anonymous"}
                            </span>
                            <span className="text-sm text-muted-foreground">
                              {formatDate(review.created_at)}
                            </span>
                          </div>
                          <div className="flex items-center gap-1 mb-2">
                            {renderStars(review.rating)}
                          </div>
                          {review.comment && (
                            <p className="text-muted-foreground">{review.comment}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <Star className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No reviews yet</p>
                </CardContent>
              </Card>
            )}
          </section>
        </div>
      </div>
    </MainLayout>
  );
};

export default ShopDetail;
