import { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, MessageCircle, User, Package, Search } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { OnlineIndicatorBadge } from "@/components/chat/OnlineStatus";
import { usePresence } from "@/hooks/useOnlineStatus";
import { useConversationStatus } from "@/hooks/useConversationStatus";

interface ConversationWithDetails {
  id: string;
  order_id: string | null;
  buyer_id: string;
  seller_id: string;
  is_active: boolean | null;
  updated_at: string;
  created_at: string;
  chat_theme: string | null;
  other_user_id: string;
  other_user_name: string;
  other_user_avatar: string | null;
  last_message: string | null;
  last_message_time: string | null;
  unread_count: number;
}

const Conversations = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [conversations, setConversations] = useState<ConversationWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  // Track presence
  usePresence(user?.id);
  
  // Track typing status across all conversations
  const { isTypingInConversation } = useConversationStatus(user?.id);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchConversations = async () => {
      if (!user) return;

      try {
        // Fetch all conversations for this user, sorted by most recent activity
        const { data: convData, error: convError } = await supabase
          .from("conversations")
          .select("*")
          .or(`buyer_id.eq.${user.id},seller_id.eq.${user.id}`);

        if (convError) throw convError;

        // Get details for each conversation
        const conversationsWithDetails = await Promise.all(
          (convData || []).map(async (conv) => {
            const otherUserId = conv.buyer_id === user.id ? conv.seller_id : conv.buyer_id;

            // Get other user's profile
            const { data: profileData } = await supabase
              .from("profiles")
              .select("full_name, avatar_url")
              .eq("user_id", otherUserId)
              .single();

            // Get last message
            const { data: lastMsgData } = await supabase
              .from("messages")
              .select("content, created_at, message_type")
              .eq("conversation_id", conv.id)
              .order("created_at", { ascending: false })
              .limit(1)
              .single();

            // Get unread count
            const { count: unreadCount } = await supabase
              .from("messages")
              .select("*", { count: "exact", head: true })
              .eq("conversation_id", conv.id)
              .eq("is_read", false)
              .neq("sender_id", user.id);

            let lastMessageText = lastMsgData?.content || null;
            if (lastMsgData?.message_type === "image") lastMessageText = "📷 Image";
            if (lastMsgData?.message_type === "voice") lastMessageText = "🎤 Voice message";
            if (lastMsgData?.message_type === "sticker") lastMessageText = "😊 Sticker";
            if (lastMsgData?.message_type === "file") lastMessageText = "📎 File";

            return {
              ...conv,
              other_user_id: otherUserId,
              other_user_name: profileData?.full_name || "User",
              other_user_avatar: profileData?.avatar_url || null,
              last_message: lastMessageText,
              last_message_time: lastMsgData?.created_at || null,
              unread_count: unreadCount || 0,
            } as ConversationWithDetails;
          })
        );

        // Sort by last message time (most recent first)
        conversationsWithDetails.sort((a, b) => {
          const timeA = a.last_message_time ? new Date(a.last_message_time).getTime() : new Date(a.updated_at).getTime();
          const timeB = b.last_message_time ? new Date(b.last_message_time).getTime() : new Date(b.updated_at).getTime();
          return timeB - timeA;
        });

        setConversations(conversationsWithDetails);
      } catch (error) {
        console.error("Error fetching conversations:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchConversations();
  }, [user]);

  // Real-time subscription for new messages
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel("conversations-updates")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
        },
        async (payload) => {
          const newMsg = payload.new as { conversation_id: string; sender_id: string; content: string; message_type: string; created_at: string };
          
          // Update conversation in place
          setConversations((prev) =>
            prev.map((conv) => {
              if (conv.id === newMsg.conversation_id) {
                let messageText = newMsg.content;
                if (newMsg.message_type === "image") messageText = "📷 Image";
                if (newMsg.message_type === "voice") messageText = "🎤 Voice message";
                if (newMsg.message_type === "sticker") messageText = "😊 Sticker";
                if (newMsg.message_type === "file") messageText = "📎 File";
                
                return {
                  ...conv,
                  last_message: messageText,
                  last_message_time: newMsg.created_at,
                  unread_count: newMsg.sender_id !== user.id ? conv.unread_count + 1 : conv.unread_count,
                };
              }
              return conv;
            }).sort((a, b) => {
              const timeA = a.last_message_time ? new Date(a.last_message_time).getTime() : 0;
              const timeB = b.last_message_time ? new Date(b.last_message_time).getTime() : 0;
              return timeB - timeA;
            })
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const handleConversationClick = (conv: ConversationWithDetails) => {
    navigate(`/conversation/${conv.id}`);
  };

  const filteredConversations = useMemo(() => {
    if (!searchQuery.trim()) return conversations;
    return conversations.filter((conv) =>
      conv.other_user_name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [conversations, searchQuery]);

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user) return null;

  return (
    <MainLayout>
      <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-xl border-b border-border/50">
          <div className="max-w-2xl mx-auto px-4 py-4">
            <h1 className="text-2xl font-bold text-foreground mb-1">Messages</h1>
            <p className="text-sm text-muted-foreground mb-4">Your conversations</p>
            
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-muted/50 border-0 focus-visible:ring-1"
              />
            </div>
          </div>
        </div>

        {/* Conversations List */}
        <div className="max-w-2xl mx-auto">
          {filteredConversations.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 px-4">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center mb-4">
                <MessageCircle className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-lg font-medium text-foreground mb-2">
                {searchQuery ? "No results found" : "No conversations yet"}
              </h3>
              <p className="text-muted-foreground text-center text-sm">
                {searchQuery 
                  ? "Try a different search term"
                  : "Start chatting by messaging a seller or ordering a product"
                }
              </p>
            </div>
          ) : (
            <div className="divide-y divide-border/50">
              {filteredConversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => handleConversationClick(conv)}
                  className={cn(
                    "w-full flex items-center gap-4 p-4 hover:bg-muted/50 transition-all duration-200 text-left",
                    conv.unread_count > 0 && "bg-primary/5 hover:bg-primary/10"
                  )}
                >
                  {/* Avatar with online status */}
                  <div className="relative flex-shrink-0">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center overflow-hidden ring-2 ring-background shadow-md">
                      {conv.other_user_avatar ? (
                        <img
                          src={conv.other_user_avatar}
                          alt={conv.other_user_name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="h-7 w-7 text-muted-foreground" />
                      )}
                    </div>
                    <OnlineIndicatorBadge userId={conv.other_user_id} className="w-4 h-4" />
                    {conv.unread_count > 0 && (
                      <span className="absolute -top-1 -right-1 min-w-[22px] h-[22px] bg-primary rounded-full flex items-center justify-center text-xs text-primary-foreground font-semibold px-1 shadow-lg">
                        {conv.unread_count > 99 ? "99+" : conv.unread_count}
                      </span>
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className={cn(
                        "font-medium text-foreground truncate",
                        conv.unread_count > 0 && "font-semibold"
                      )}>
                        {conv.other_user_name}
                      </span>
                      {conv.last_message_time && (
                        <span className="text-xs text-muted-foreground flex-shrink-0">
                          {format(new Date(conv.last_message_time), "MMM d")}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {conv.order_id && (
                        <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                          <Package className="h-3 w-3" />
                          <span className="text-[10px] font-medium">Order</span>
                        </div>
                      )}
                      {isTypingInConversation(conv.id) ? (
                        <p className="text-sm text-primary font-medium flex items-center gap-1">
                          <span className="flex gap-0.5">
                            <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                            <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                            <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                          </span>
                          typing...
                        </p>
                      ) : (
                        <p className={cn(
                          "text-sm truncate flex-1",
                          conv.unread_count > 0 ? "text-foreground font-medium" : "text-muted-foreground"
                        )}>
                          {conv.last_message || "No messages yet"}
                        </p>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default Conversations;