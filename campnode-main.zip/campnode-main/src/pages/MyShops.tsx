import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { 
  Store, 
  Plus, 
  Eye,
  Loader2,
  MapPin,
  Star,
  Package,
  CheckCircle,
  MoreVertical,
  Trash2,
  Settings
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Shop {
  id: string;
  name: string;
  description: string | null;
  cover_image: string | null;
  profile_image: string | null;
  location: string | null;
  category: string;
  rating: number | null;
  is_verified: boolean | null;
  created_at: string;
  product_count?: number;
}

const MyShops = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [shops, setShops] = useState<Shop[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [shopToDelete, setShopToDelete] = useState<Shop | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchShops = async () => {
      if (!user) return;

      try {
        const { data: shopsData, error: shopsError } = await supabase
          .from("shops")
          .select("*")
          .eq("owner_id", user.id)
          .order("created_at", { ascending: false });

        if (shopsError) throw shopsError;

        // Get product counts for each shop
        const shopIds = shopsData?.map(s => s.id) || [];
        const { data: productsData } = await supabase
          .from("products")
          .select("shop_id")
          .in("shop_id", shopIds)
          .eq("is_active", true);

        const counts: Record<string, number> = {};
        productsData?.forEach(p => {
          if (p.shop_id) {
            counts[p.shop_id] = (counts[p.shop_id] || 0) + 1;
          }
        });

        const shopsWithCounts = shopsData?.map(shop => ({
          ...shop,
          product_count: counts[shop.id] || 0
        })) || [];

        setShops(shopsWithCounts);
      } catch (error) {
        console.error("Error fetching shops:", error);
        toast.error("Failed to load your shops");
      } finally {
        setLoading(false);
      }
    };

    fetchShops();
  }, [user]);

  const deleteShop = async (id: string) => {
    setDeletingId(id);
    try {
      const { error } = await supabase
        .from("shops")
        .delete()
        .eq("id", id);

      if (error) throw error;

      setShops(shops.filter(s => s.id !== id));
      toast.success("Shop deleted successfully");
    } catch (error) {
      toast.error("Failed to delete shop");
    } finally {
      setDeletingId(null);
    }
  };

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen px-4 py-6">
          <div className="max-w-4xl mx-auto space-y-4">
            {[...Array(2)].map((_, i) => (
              <Skeleton key={i} className="h-48 rounded-xl" />
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!user) return null;

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Store className="h-6 w-6 text-primary" />
                <h1 className="text-2xl font-bold text-foreground">My Shops</h1>
              </div>
              <p className="text-muted-foreground">
                Manage your business shops
              </p>
            </div>
            <Link to="/create-shop">
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Create Shop
              </Button>
            </Link>
          </div>

          {/* Shops */}
          {shops.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Store className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="font-semibold text-foreground mb-2">No shops yet</h3>
                <p className="text-muted-foreground text-sm mb-4 text-center">
                  Create your first shop to start listing products and services
                </p>
                <Link to="/create-shop">
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    Create Your First Shop
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {shops.map((shop) => (
                <Card key={shop.id} className="overflow-hidden">
                  <div className="relative h-32">
                    <img
                      src={shop.cover_image || "/placeholder.svg"}
                      alt={shop.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    
                    {/* Profile Image */}
                    <div className="absolute bottom-0 left-4 translate-y-1/2">
                      <div className="w-16 h-16 rounded-full border-4 border-card overflow-hidden bg-muted">
                        <img
                          src={shop.profile_image || "/placeholder.svg"}
                          alt={shop.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>

                    {/* Badges */}
                    <div className="absolute top-3 right-3 flex gap-2">
                      {shop.is_verified && (
                        <Badge className="bg-green-500 hover:bg-green-600 gap-1">
                          <CheckCircle className="h-3 w-3" />
                          Verified
                        </Badge>
                      )}
                    </div>
                  </div>

                  <CardContent className="pt-10 pb-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-lg text-foreground">
                          {shop.name}
                        </h3>
                        {shop.location && (
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {shop.location}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          {shop.rating?.toFixed(1) || "0.0"}
                        </span>
                        <span className="flex items-center gap-1">
                          <Package className="h-4 w-4" />
                          {shop.product_count} products
                        </span>
                      </div>
                    </div>

                    {shop.description && (
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                        {shop.description}
                      </p>
                    )}

                                    {/* Actions */}
                                    <div className="flex items-center gap-2">
                                      <Link to={`/shop-dashboard/${shop.id}`}>
                                        <Button size="sm" className="gap-1">
                                          <Settings className="h-4 w-4" />
                                          Manage
                                        </Button>
                                      </Link>
                                      <Link to={`/shop/${shop.id}`}>
                                        <Button variant="outline" size="sm" className="gap-1">
                                          <Eye className="h-4 w-4" />
                                          View
                                        </Button>
                                      </Link>

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link to={`/shop/${shop.id}`} className="flex items-center gap-2">
                              <Eye className="h-4 w-4" />
                              View Shop
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => setShopToDelete(shop)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete Shop
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!shopToDelete} onOpenChange={(open) => !open && setShopToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Shop</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{shopToDelete?.name}"? This will also delete all products associated with this shop. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (shopToDelete) {
                  deleteShop(shopToDelete.id);
                  setShopToDelete(null);
                }
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deletingId === shopToDelete?.id}
            >
              {deletingId === shopToDelete?.id ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : null}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
};

export default MyShops;
