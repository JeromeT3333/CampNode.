import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ImageUpload } from "@/components/ImageUpload";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { nigerianBanks, getBankNameByCode } from "@/data/nigerianBanks";
import { 
  User, 
  Phone, 
  MapPin, 
  Loader2,
  Save,
  CreditCard,
  CheckCircle,
  AlertCircle,
  Edit,
  Trash2
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Profile {
  full_name: string | null;
  phone: string | null;
  campus_location: string | null;
  avatar_url: string | null;
}

interface BankDetails {
  id: string;
  bank_code: string;
  bank_name: string;
  account_number: string;
  account_name: string;
  verification_status: string;
}

const Profile = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  
  const [profile, setProfile] = useState<Profile>({
    full_name: "",
    phone: "",
    campus_location: "",
    avatar_url: ""
  });
  const [bankDetails, setBankDetails] = useState<BankDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  // Bank verification states
  const [bankCode, setBankCode] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [verifiedName, setVerifiedName] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;
      
      try {
        // Fetch profile
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("user_id", user.id)
          .single();

        if (profileError && profileError.code !== "PGRST116") {
          console.error("Error fetching profile:", profileError);
        } else if (profileData) {
          setProfile({
            full_name: profileData.full_name || "",
            phone: profileData.phone || "",
            campus_location: profileData.campus_location || "",
            avatar_url: profileData.avatar_url || ""
          });
        }

        // Fetch bank details
        const { data: bankData, error: bankError } = await supabase
          .from("seller_bank_details")
          .select("*")
          .eq("seller_id", user.id)
          .single();

        if (bankError && bankError.code !== "PGRST116") {
          console.error("Error fetching bank details:", bankError);
        } else if (bankData) {
          setBankDetails(bankData);
        }
      } catch (error) {
        console.error("Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const handleSaveProfile = async () => {
    if (!user) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .upsert({
          user_id: user.id,
          full_name: profile.full_name,
          phone: profile.phone,
          campus_location: profile.campus_location,
          avatar_url: profile.avatar_url
        }, {
          onConflict: "user_id"
        });

      if (error) throw error;
      toast.success("Profile updated successfully!");
    } catch (error: unknown) {
      console.error("Profile update error:", error);
      toast.error("Failed to update profile. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleVerifyBank = async () => {
    if (!bankCode || !accountNumber) {
      toast.error("Please select a bank and enter account number");
      return;
    }

    setVerifying(true);
    setVerifiedName("");
    
    try {
      const { data, error } = await supabase.functions.invoke("verify-bank-account", {
        body: { bank_code: bankCode, account_number: accountNumber }
      });

      if (error) throw error;
      
      if (data.status === "success" && data.data?.account_name) {
        setVerifiedName(data.data.account_name);
        toast.success("Account verified successfully!");
      } else {
        toast.error(data.message || "Could not verify account");
      }
    } catch (error: unknown) {
      console.error("Verification error:", error);
      toast.error("Could not verify account. Please check the details and try again.");
    } finally {
      setVerifying(false);
    }
  };

  const handleSaveBankDetails = async () => {
    if (!user || !verifiedName) {
      toast.error("Please verify your account first");
      return;
    }

    setSaving(true);
    try {
      const bankName = getBankNameByCode(bankCode);
      
      const { data, error } = await supabase
        .from("seller_bank_details")
        .upsert({
          seller_id: user.id,
          bank_code: bankCode,
          bank_name: bankName,
          account_number: accountNumber,
          account_name: verifiedName,
          verification_status: "verified"
        }, {
          onConflict: "seller_id"
        })
        .select()
        .single();

      if (error) throw error;
      
      setBankDetails(data);
      setIsEditing(false);
      setBankCode("");
      setAccountNumber("");
      setVerifiedName("");
      
      toast.success("Bank details saved successfully!");
    } catch (error: unknown) {
      console.error("Save bank details error:", error);
      toast.error("Failed to save bank details. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteBankDetails = async () => {
    if (!user || !bankDetails) return;

    setDeleting(true);
    try {
      const { error } = await supabase
        .from("seller_bank_details")
        .delete()
        .eq("seller_id", user.id);

      if (error) throw error;
      
      setBankDetails(null);
      toast.success("Bank details deleted successfully!");
    } catch (error: unknown) {
      console.error("Delete bank details error:", error);
      toast.error("Failed to delete bank details. Please try again.");
    } finally {
      setDeleting(false);
    }
  };

  const startEditing = () => {
    setIsEditing(true);
    if (bankDetails) {
      setBankCode(bankDetails.bank_code);
      setAccountNumber(bankDetails.account_number);
    }
  };

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user) return null;

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-2xl mx-auto space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Profile</h1>
            <p className="text-muted-foreground">Manage your account settings</p>
          </div>

          {/* Personal Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Personal Information
              </CardTitle>
              <CardDescription>Update your personal details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Avatar Upload */}
              <div className="flex items-center gap-4">
              <ImageUpload
                value={profile.avatar_url || undefined}
                onChange={(url) => setProfile({ ...profile, avatar_url: url })}
                bucket="avatars"
                folder={user?.id}
                aspectRatio="square"
                className="w-24 h-24 rounded-full"
                placeholder="Photo"
              />
                <div>
                  <p className="font-medium text-foreground">Profile Photo</p>
                  <p className="text-sm text-muted-foreground">Click to upload a new photo</p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" value={user.email || ""} disabled className="bg-muted" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  value={profile.full_name || ""}
                  onChange={(e) => setProfile({ ...profile, full_name: e.target.value })}
                  placeholder="Enter your full name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  Phone Number
                </Label>
                <Input
                  id="phone"
                  value={profile.phone || ""}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  placeholder="Enter your phone number"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location" className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Campus Location
                </Label>
                <Input
                  id="location"
                  value={profile.campus_location || ""}
                  onChange={(e) => setProfile({ ...profile, campus_location: e.target.value })}
                  placeholder="e.g., Main Campus, Building A"
                />
              </div>

              <Button onClick={handleSaveProfile} disabled={saving} className="w-full gap-2">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save Profile
              </Button>
            </CardContent>
          </Card>

          {/* Bank Details for Sellers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Seller Bank Details
              </CardTitle>
              <CardDescription>
                Add your bank details to receive payouts when you make sales
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {bankDetails?.verification_status === "verified" && !isEditing ? (
                <>
                  <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                    <div className="flex items-center gap-2 text-green-600 mb-2">
                      <CheckCircle className="h-5 w-5" />
                      <span className="font-medium">Bank Account Verified</span>
                    </div>
                    <div className="space-y-1 text-sm">
                      <p><span className="text-muted-foreground">Bank:</span> {bankDetails.bank_name}</p>
                      <p><span className="text-muted-foreground">Account:</span> {bankDetails.account_number}</p>
                      <p><span className="text-muted-foreground">Name:</span> {bankDetails.account_name}</p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1 gap-2"
                      onClick={startEditing}
                    >
                      <Edit className="h-4 w-4" />
                      Edit Details
                    </Button>
                    
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="destructive" 
                          className="flex-1 gap-2"
                          disabled={deleting}
                        >
                          {deleting ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4" />
                          )}
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Bank Details</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete your bank details? You won't be able to receive payouts until you add new bank details.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={handleDeleteBankDetails}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="bankName">Select Bank</Label>
                    <Select value={bankCode} onValueChange={setBankCode}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your bank" />
                      </SelectTrigger>
                      <SelectContent>
                        {nigerianBanks.map((bank) => (
                          <SelectItem key={bank.code} value={bank.code}>
                            {bank.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="accountNumber">Account Number</Label>
                    <Input
                      id="accountNumber"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      placeholder="Enter 10-digit account number"
                      maxLength={10}
                    />
                  </div>

                  {verifiedName && (
                    <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20 flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span className="text-green-600 font-medium">{verifiedName}</span>
                    </div>
                  )}

                  <div className="flex gap-2">
                    {isEditing && (
                      <Button 
                        variant="outline"
                        onClick={() => {
                          setIsEditing(false);
                          setBankCode("");
                          setAccountNumber("");
                          setVerifiedName("");
                        }}
                        className="flex-1"
                      >
                        Cancel
                      </Button>
                    )}
                    
                    <Button 
                      variant="outline" 
                      onClick={handleVerifyBank} 
                      disabled={verifying || !bankCode || !accountNumber}
                      className="flex-1"
                    >
                      {verifying ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <>
                          <AlertCircle className="h-4 w-4 mr-2" />
                          Verify Account
                        </>
                      )}
                    </Button>
                    
                    {verifiedName && (
                      <Button 
                        onClick={handleSaveBankDetails} 
                        disabled={saving}
                        className="flex-1"
                      >
                        {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                        Save Details
                      </Button>
                    )}
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default Profile;
