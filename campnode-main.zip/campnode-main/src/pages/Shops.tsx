import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { ShopCard } from "@/components/ShopCard";
import { categories } from "@/data/mockData";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { Store, Search } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface Shop {
  id: string;
  name: string;
  description: string | null;
  cover_image: string | null;
  profile_image: string | null;
  location: string | null;
  category: string;
  rating: number | null;
  is_verified: boolean | null;
}

const ShopsPage = () => {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [query, setQuery] = useState("");
  const [shops, setShops] = useState<Shop[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchShops = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("shops")
          .select("id, name, description, cover_image, profile_image, location, category, rating, is_verified")
          .order("created_at", { ascending: false });

        if (error) throw error;
        setShops(data || []);
      } catch (error) {
        console.error("Error fetching shops:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchShops();
  }, []);

  // Count products for each shop
  const [productCounts, setProductCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    const fetchProductCounts = async () => {
      if (shops.length === 0) return;
      
      const shopIds = shops.map(s => s.id);
      const { data, error } = await supabase
        .from("products")
        .select("shop_id")
        .in("shop_id", shopIds)
        .eq("is_active", true);

      if (error) {
        console.error("Error fetching product counts:", error);
        return;
      }

      const counts: Record<string, number> = {};
      data?.forEach(p => {
        if (p.shop_id) {
          counts[p.shop_id] = (counts[p.shop_id] || 0) + 1;
        }
      });
      setProductCounts(counts);
    };

    fetchProductCounts();
  }, [shops]);

  const filteredShops = shops.filter((shop) => {
    const matchesQuery = query === "" ||
      shop.name.toLowerCase().includes(query.toLowerCase()) ||
      (shop.description?.toLowerCase().includes(query.toLowerCase()) ?? false);
    const matchesCategory = selectedCategory === "all" || shop.category === selectedCategory;
    return matchesQuery && matchesCategory;
  });

  // Map database shops to ShopCard format
  const mappedShops = filteredShops.map(shop => ({
    id: shop.id,
    name: shop.name,
    description: shop.description || "",
    coverImage: shop.cover_image || "/placeholder.svg",
    profileImage: shop.profile_image || "/placeholder.svg",
    location: shop.location || "Unknown",
    category: shop.category,
    rating: shop.rating || 0,
    productCount: productCounts[shop.id] || 0,
    isVerified: shop.is_verified || false,
  }));

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Store className="h-6 w-6 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">Shops</h1>
            </div>
            <p className="text-muted-foreground">
              Discover verified shops and local businesses on campus
            </p>
          </div>

          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search shops..."
              className={cn(
                "w-full pl-12 pr-4 py-3 rounded-xl",
                "bg-muted/50 border border-border",
                "text-foreground placeholder:text-muted-foreground",
                "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              )}
            />
          </div>

          {/* Category Filter */}
          <div className="overflow-x-auto scrollbar-none -mx-4 px-4 mb-6">
            <div className="flex gap-2 pb-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap",
                    "transition-all duration-200 text-sm font-medium",
                    selectedCategory === category.id
                      ? "bg-primary text-primary-foreground shadow-md"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  )}
                >
                  <span>{category.icon}</span>
                  <span>{category.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Loading State */}
          {loading && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-48 rounded-xl" />
              ))}
            </div>
          )}

          {/* Shops Grid */}
          {!loading && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mappedShops.map((shop, index) => (
                <ShopCard key={shop.id} shop={shop} index={index} />
              ))}
            </div>
          )}

          {!loading && filteredShops.length === 0 && (
            <div className="text-center py-16">
              <Store className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-semibold text-foreground mb-2">No shops found</h3>
              <p className="text-muted-foreground text-sm">
                Try adjusting your search or category filter
              </p>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default ShopsPage;
