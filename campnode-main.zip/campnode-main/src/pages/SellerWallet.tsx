import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { nigerianBanks } from "@/data/nigerianBanks";
import {
  Wallet,
  ArrowDownToLine,
  ArrowUpFromLine,
  Clock,
  CheckCircle,
  XCircle,
  Loader2,
  TrendingUp,
  Building2,
  Shield,
  AlertCircle,
  RefreshCw,
  ChevronLeft,
  Info
} from "lucide-react";
import { format } from "date-fns";

interface SellerWallet {
  id: string;
  pending_balance: number;
  available_balance: number;
  total_earnings: number;
  total_withdrawn: number;
  currency: string;
}

interface WalletTransaction {
  id: string;
  transaction_type: string;
  amount: number;
  balance_after: number;
  balance_type: string;
  description: string | null;
  reference: string | null;
  created_at: string;
}

interface Payout {
  id: string;
  payout_reference: string;
  amount: number;
  status: string;
  bank_code: string;
  account_number: string;
  account_name: string;
  failure_reason: string | null;
  created_at: string;
}

interface BankDetails {
  id: string;
  bank_code: string;
  bank_name: string;
  account_number: string;
  account_name: string;
  verification_status: string;
}

const MIN_WITHDRAWAL = 1000;

const SellerWalletPage = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [wallet, setWallet] = useState<SellerWallet | null>(null);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [bankDetails, setBankDetails] = useState<BankDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [withdrawing, setWithdrawing] = useState(false);
  const [verifying, setVerifying] = useState(false);

  // Withdrawal form
  const [withdrawAmount, setWithdrawAmount] = useState("");

  // Bank form
  const [selectedBank, setSelectedBank] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [accountName, setAccountName] = useState("");

  const fetchWalletData = useCallback(async () => {
    if (!user) return;

    try {
      // Fetch wallet
      const { data: walletData } = await supabase
        .from('seller_wallets')
        .select('*')
        .eq('seller_id', user.id)
        .single();

      setWallet(walletData);

      // Fetch transactions if wallet exists
      if (walletData) {
        const { data: txData } = await supabase
          .from('wallet_transactions')
          .select('*')
          .eq('wallet_id', walletData.id)
          .order('created_at', { ascending: false })
          .limit(20);

        setTransactions(txData || []);
      }

      // Fetch payouts
      const { data: payoutData } = await supabase
        .from('payouts')
        .select('*')
        .eq('seller_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      setPayouts(payoutData || []);

      // Fetch bank details
      const { data: bankData } = await supabase
        .from('seller_bank_details')
        .select('*')
        .eq('seller_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      setBankDetails(bankData);
    } catch (error) {
      console.error("Error fetching wallet data:", error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth?redirect=/wallet');
      return;
    }
    fetchWalletData();
  }, [user, authLoading, navigate, fetchWalletData]);

  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const handleVerifyBank = async () => {
    if (!selectedBank || !accountNumber || accountNumber.length !== 10) {
      toast.error("Please select a bank and enter a valid 10-digit account number");
      return;
    }

    setVerifying(true);

    try {
      const { data, error } = await supabase.functions.invoke('verify-bank-account', {
        body: { bank_code: selectedBank, account_number: accountNumber }
      });

      if (error) throw error;
      if (data.status !== 'success') throw new Error(data.message);

      setAccountName(data.data.account_name);

      // Save bank details
      const bank = nigerianBanks.find(b => b.code === selectedBank);
      
      await supabase
        .from('seller_bank_details')
        .upsert({
          seller_id: user!.id,
          bank_code: selectedBank,
          bank_name: bank?.name || '',
          account_number: accountNumber,
          account_name: data.data.account_name,
          verification_status: 'verified'
        }, { onConflict: 'seller_id' });

      // Create subaccount
      await supabase.functions.invoke('create-seller-subaccount', {
        body: {
          bank_code: selectedBank,
          account_number: accountNumber,
          business_name: data.data.account_name
        }
      });

      toast.success("Bank account verified and linked successfully!");
      fetchWalletData();
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : 'Verification failed';
      toast.error(message);
    } finally {
      setVerifying(false);
    }
  };

  const handleWithdraw = async () => {
    const amount = parseFloat(withdrawAmount);
    
    if (!amount || amount < MIN_WITHDRAWAL) {
      toast.error(`Minimum withdrawal is ${formatPrice(MIN_WITHDRAWAL)}`);
      return;
    }

    if (!wallet || amount > wallet.available_balance) {
      toast.error("Insufficient balance");
      return;
    }

    if (!bankDetails || bankDetails.verification_status !== 'verified') {
      toast.error("Please verify your bank account first");
      return;
    }

    setWithdrawing(true);

    try {
      const { data, error } = await supabase.functions.invoke('process-withdrawal', {
        body: { amount }
      });

      if (error) throw error;
      if (data.status !== 'success') throw new Error(data.message);

      toast.success(`Withdrawal of ${formatPrice(amount)} initiated!`);
      setWithdrawAmount("");
      fetchWalletData();
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : 'Withdrawal failed';
      toast.error(message);
    } finally {
      setWithdrawing(false);
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'escrow_credit':
      case 'instant_credit':
        return <ArrowDownToLine className="h-4 w-4 text-green-600" />;
      case 'escrow_release':
        return <CheckCircle className="h-4 w-4 text-primary" />;
      case 'withdrawal':
        return <ArrowUpFromLine className="h-4 w-4 text-orange-500" />;
      case 'withdrawal_refund':
        return <RefreshCw className="h-4 w-4 text-blue-500" />;
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500">Completed</Badge>;
      case 'processing':
        return <Badge className="bg-blue-500">Processing</Badge>;
      case 'pending':
        return <Badge variant="secondary">Pending</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Calculate transfer fee
  const getTransferFee = (amount: number) => {
    if (amount <= 5000) return 10.75;
    if (amount <= 50000) return 26.88;
    return 53.75;
  };

  const withdrawAmountNum = parseFloat(withdrawAmount) || 0;
  const transferFee = getTransferFee(withdrawAmountNum);
  const netWithdrawal = Math.max(0, withdrawAmountNum - transferFee);

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="rounded-full">
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Seller Wallet</h1>
              <p className="text-sm text-muted-foreground">Manage your earnings and withdrawals</p>
            </div>
          </div>

          {/* Balance Cards */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Wallet className="h-4 w-4" />
                  Available Balance
                </div>
                <p className="text-2xl font-bold text-primary">
                  {formatPrice(wallet?.available_balance || 0)}
                </p>
              </CardContent>
            </Card>

            <Card className="border-orange-200 dark:border-orange-900">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Clock className="h-4 w-4" />
                  Pending (Escrow)
                </div>
                <p className="text-2xl font-bold text-orange-600">
                  {formatPrice(wallet?.pending_balance || 0)}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <TrendingUp className="h-4 w-4" />
                  Total Earnings
                </div>
                <p className="text-2xl font-bold text-foreground">
                  {formatPrice(wallet?.total_earnings || 0)}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <ArrowUpFromLine className="h-4 w-4" />
                  Total Withdrawn
                </div>
                <p className="text-2xl font-bold text-foreground">
                  {formatPrice(wallet?.total_withdrawn || 0)}
                </p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="withdraw" className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
              <TabsTrigger value="bank">Bank Account</TabsTrigger>
            </TabsList>

            {/* Withdraw Tab */}
            <TabsContent value="withdraw">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ArrowUpFromLine className="h-5 w-5" />
                    Withdraw to Bank
                  </CardTitle>
                  <CardDescription>
                    Transfer your available balance to your verified bank account
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!bankDetails || bankDetails.verification_status !== 'verified' ? (
                    <div className="flex items-start gap-3 p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                      <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-amber-700 dark:text-amber-400">Bank Account Required</p>
                        <p className="text-sm text-muted-foreground">
                          Please add and verify your bank account in the "Bank Account" tab before withdrawing.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="p-3 rounded-lg bg-muted/50 flex items-center gap-3">
                        <Building2 className="h-5 w-5 text-muted-foreground" />
                        <div className="flex-1">
                          <p className="font-medium">{bankDetails.bank_name}</p>
                          <p className="text-sm text-muted-foreground">
                            {bankDetails.account_number} • {bankDetails.account_name}
                          </p>
                        </div>
                        <Badge className="bg-green-500">Verified</Badge>
                      </div>

                      <div>
                        <Label htmlFor="amount">Amount to Withdraw</Label>
                        <Input
                          id="amount"
                          type="number"
                          placeholder={`Min: ${formatPrice(MIN_WITHDRAWAL)}`}
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                          className="mt-1.5"
                        />
                      </div>

                      {withdrawAmountNum > 0 && (
                        <div className="p-3 rounded-lg bg-muted/50 space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Withdrawal Amount</span>
                            <span>{formatPrice(withdrawAmountNum)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Transfer Fee</span>
                            <span className="text-destructive">-{formatPrice(transferFee)}</span>
                          </div>
                          <Separator />
                          <div className="flex justify-between font-medium">
                            <span>You'll Receive</span>
                            <span className="text-primary">{formatPrice(netWithdrawal)}</span>
                          </div>
                        </div>
                      )}

                      <Button
                        className="w-full"
                        onClick={handleWithdraw}
                        disabled={withdrawing || withdrawAmountNum < MIN_WITHDRAWAL || withdrawAmountNum > (wallet?.available_balance || 0)}
                      >
                        {withdrawing ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : (
                          <ArrowUpFromLine className="h-4 w-4 mr-2" />
                        )}
                        Withdraw {withdrawAmountNum > 0 ? formatPrice(withdrawAmountNum) : ''}
                      </Button>
                    </>
                  )}

                  {/* Recent Payouts */}
                  {payouts.length > 0 && (
                    <div className="mt-6">
                      <h4 className="font-medium mb-3">Recent Withdrawals</h4>
                      <div className="space-y-2">
                        {payouts.slice(0, 5).map((payout) => (
                          <div key={payout.id} className="flex items-center justify-between p-3 rounded-lg border">
                            <div>
                              <p className="font-medium">{formatPrice(payout.amount)}</p>
                              <p className="text-xs text-muted-foreground">
                                {format(new Date(payout.created_at), 'MMM d, yyyy')}
                              </p>
                            </div>
                            <div className="text-right">
                              {getStatusBadge(payout.status)}
                              {payout.failure_reason && (
                                <p className="text-xs text-destructive mt-1">{payout.failure_reason}</p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Transactions Tab */}
            <TabsContent value="transactions">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Transaction History
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {transactions.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Wallet className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No transactions yet</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {transactions.map((tx) => (
                        <div key={tx.id} className="flex items-center gap-3 p-3 rounded-lg border">
                          {getTransactionIcon(tx.transaction_type)}
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">
                              {tx.description || tx.transaction_type.replace(/_/g, ' ')}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(tx.created_at), 'MMM d, yyyy h:mm a')}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className={`font-semibold ${tx.amount > 0 ? 'text-green-600' : 'text-destructive'}`}>
                              {tx.amount > 0 ? '+' : ''}{formatPrice(tx.amount)}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Bal: {formatPrice(tx.balance_after)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Bank Account Tab */}
            <TabsContent value="bank">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="h-5 w-5" />
                    Bank Account
                  </CardTitle>
                  <CardDescription>
                    Link your bank account for withdrawals
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {bankDetails?.verification_status === 'verified' ? (
                    <div className="space-y-4">
                      <div className="p-4 rounded-lg border border-green-200 dark:border-green-900 bg-green-50 dark:bg-green-950/30">
                        <div className="flex items-start gap-3">
                          <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                          <div>
                            <p className="font-semibold text-green-700 dark:text-green-400">
                              Bank Account Verified
                            </p>
                            <div className="mt-2 space-y-1 text-sm">
                              <p><span className="text-muted-foreground">Bank:</span> {bankDetails.bank_name}</p>
                              <p><span className="text-muted-foreground">Account:</span> {bankDetails.account_number}</p>
                              <p><span className="text-muted-foreground">Name:</span> {bankDetails.account_name}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                        <Info className="h-4 w-4 flex-shrink-0 mt-0.5" />
                        <p>To change your bank account, contact support.</p>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div>
                        <Label>Select Bank</Label>
                        <Select value={selectedBank} onValueChange={setSelectedBank}>
                          <SelectTrigger className="mt-1.5">
                            <SelectValue placeholder="Choose your bank" />
                          </SelectTrigger>
                          <SelectContent>
                            {nigerianBanks.map((bank) => (
                              <SelectItem key={bank.code} value={bank.code}>
                                {bank.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="accountNumber">Account Number</Label>
                        <Input
                          id="accountNumber"
                          value={accountNumber}
                          onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                          placeholder="Enter 10-digit account number"
                          maxLength={10}
                          className="mt-1.5"
                        />
                      </div>

                      {accountName && (
                        <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-900">
                          <p className="text-sm text-green-700 dark:text-green-400">
                            <span className="font-medium">Account Name:</span> {accountName}
                          </p>
                        </div>
                      )}

                      <Button
                        className="w-full"
                        onClick={handleVerifyBank}
                        disabled={verifying || !selectedBank || accountNumber.length !== 10}
                      >
                        {verifying ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : (
                          <Shield className="h-4 w-4 mr-2" />
                        )}
                        Verify & Link Account
                      </Button>

                      <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                        <Shield className="h-4 w-4 flex-shrink-0 mt-0.5" />
                        <p>Your bank details are encrypted and secured. We verify account ownership to protect your earnings.</p>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
};

export default SellerWalletPage;
