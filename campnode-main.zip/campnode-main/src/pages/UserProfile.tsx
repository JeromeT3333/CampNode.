import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { ProductCard } from "@/components/ProductCard";
import { ShopCard } from "@/components/ShopCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { 
  MapPin, 
  GraduationCap, 
  Store, 
  ShoppingBag, 
  Loader2,
  ArrowLeft,
  MessageCircle
} from "lucide-react";

interface Profile {
  id: string;
  user_id: string;
  full_name: string | null;
  username: string | null;
  avatar_url: string | null;
  department: string | null;
  campus_location: string | null;
}

interface Product {
  id: string;
  name: string;
  price: number;
  image: string | null;
  description: string | null;
  category: string;
  location: string | null;
  is_service: boolean | null;
  is_sponsored: boolean | null;
  shops?: { name: string } | null;
}

interface Shop {
  id: string;
  name: string;
  description: string | null;
  cover_image: string | null;
  profile_image: string | null;
  category: string;
  location: string | null;
  rating: number | null;
  is_verified: boolean | null;
}

const UserProfile = () => {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  
  const [profile, setProfile] = useState<Profile | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  const [productCounts, setProductCounts] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);

  const isOwnProfile = currentUser?.id === userId;

  useEffect(() => {
    if (!userId) return;

    const fetchUserData = async () => {
      setLoading(true);
      try {
        // Fetch profile - exclude phone for privacy
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("id, user_id, full_name, username, avatar_url, department, campus_location")
          .eq("user_id", userId)
          .single();

        if (profileError) throw profileError;
        setProfile(profileData);

        // Fetch user's active products (non-anonymous only for other users)
        let productQuery = supabase
          .from("products")
          .select("*, shops(name)")
          .eq("seller_id", userId)
          .eq("is_active", true);

        if (!isOwnProfile) {
          productQuery = productQuery.eq("is_anonymous", false);
        }

        const { data: productsData } = await productQuery;
        setProducts(productsData || []);

        // Fetch user's shops
        const { data: shopsData } = await supabase
          .from("shops")
          .select("*")
          .eq("owner_id", userId);
        
        setShops(shopsData || []);

        // Fetch product counts for shops
        if (shopsData && shopsData.length > 0) {
          const shopIds = shopsData.map((s) => s.id);
          const { data: countData } = await supabase
            .from("products")
            .select("shop_id")
            .in("shop_id", shopIds)
            .eq("is_active", true);

          if (countData) {
            const counts: Record<string, number> = {};
            countData.forEach((p) => {
              if (p.shop_id) {
                counts[p.shop_id] = (counts[p.shop_id] || 0) + 1;
              }
            });
            setProductCounts(counts);
          }
        }
      } catch (error) {
        console.error("Error fetching user profile:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [userId, isOwnProfile]);

  const mapProduct = (product: Product) => ({
    id: product.id,
    name: product.name,
    price: product.price,
    image: product.image || "/placeholder.svg",
    description: product.description || "",
    category: product.category,
    location: product.location || undefined,
    isService: product.is_service || false,
    isSponsored: product.is_sponsored || false,
    shopName: product.shops?.name,
  });

  const mapShop = (shop: Shop) => ({
    id: shop.id,
    name: shop.name,
    description: shop.description || "",
    coverImage: shop.cover_image || "/placeholder.svg",
    profileImage: shop.profile_image || "/placeholder.svg",
    category: shop.category,
    location: shop.location || "Campus",
    rating: shop.rating || 0,
    productCount: productCounts[shop.id] || 0,
    isVerified: shop.is_verified || false,
  });

  if (loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!profile) {
    return (
      <MainLayout>
        <div className="min-h-screen flex flex-col items-center justify-center px-4">
          <h2 className="text-xl font-semibold text-foreground mb-2">User Not Found</h2>
          <p className="text-muted-foreground mb-4">This user profile doesn't exist.</p>
          <Button onClick={() => navigate(-1)} variant="outline">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Go Back
          </Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate(-1)}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>

          {/* Profile Header */}
          <div className="bg-card rounded-2xl border border-border p-6 mb-6">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
              <Avatar className="h-24 w-24 ring-4 ring-primary/20">
                <AvatarImage src={profile.avatar_url || undefined} />
                <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                  {profile.full_name?.charAt(0) || profile.username?.charAt(0) || "U"}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 text-center sm:text-left">
                <h1 className="text-2xl font-bold text-foreground mb-1">
                  {profile.full_name || "Anonymous User"}
                </h1>
                {profile.username && (
                  <p className="text-primary font-medium mb-3">@{profile.username}</p>
                )}
                
                <div className="flex flex-wrap justify-center sm:justify-start gap-2 mb-4">
                  {profile.department && (
                    <Badge variant="secondary" className="gap-1">
                      <GraduationCap className="h-3 w-3" />
                      {profile.department}
                    </Badge>
                  )}
                  {profile.campus_location && (
                    <Badge variant="outline" className="gap-1">
                      <MapPin className="h-3 w-3" />
                      {profile.campus_location}
                    </Badge>
                  )}
                </div>

                {/* Stats */}
                <div className="flex justify-center sm:justify-start gap-6 text-sm">
                  <div className="text-center">
                    <p className="font-bold text-foreground">{shops.length}</p>
                    <p className="text-muted-foreground">Shops</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-foreground">{products.length}</p>
                    <p className="text-muted-foreground">Products</p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              {!isOwnProfile && currentUser && (
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => navigate(`/dm/${userId}`)}
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Message
                  </Button>
                </div>
              )}

              {isOwnProfile && (
                <Button onClick={() => navigate("/profile")} variant="outline" size="sm">
                  Edit Profile
                </Button>
              )}
            </div>
          </div>

          {/* Tabs for Shops and Products */}
          <Tabs defaultValue="products" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="products" className="gap-2">
                <ShoppingBag className="h-4 w-4" />
                Products ({products.length})
              </TabsTrigger>
              <TabsTrigger value="shops" className="gap-2">
                <Store className="h-4 w-4" />
                Shops ({shops.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="products">
              {products.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {products.map((product, index) => (
                    <ProductCard key={product.id} product={mapProduct(product)} index={index} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-muted/30 rounded-xl">
                  <ShoppingBag className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">No products listed yet</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="shops">
              {shops.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {shops.map((shop, index) => (
                    <ShopCard key={shop.id} shop={mapShop(shop)} index={index} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-muted/30 rounded-xl">
                  <Store className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">No shops created yet</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
};

export default UserProfile;