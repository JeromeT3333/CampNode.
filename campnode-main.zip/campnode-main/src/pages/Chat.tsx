import { useEffect, useState, useRef, useCallback, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { ModernChatBubble } from "@/components/chat/ModernChatBubble";
import { ChatInputBar } from "@/components/chat/ChatInputBar";
import { TypingIndicator } from "@/components/chat/TypingIndicator";
import { ChatHeader } from "@/components/chat/ChatHeader";
import { chatThemes } from "@/components/chat/ChatThemeSelector";
import { useTypingIndicator } from "@/hooks/useTypingIndicator";
import { usePresence } from "@/hooks/useOnlineStatus";
import { cn } from "@/lib/utils";

interface Message {
  id: string;
  content: string | null;
  sender_id: string;
  created_at: string;
  is_read: boolean | null;
  message_type: string;
  attachment_url: string | null;
  is_pinned: boolean | null;
  is_deleted: boolean | null;
}

interface Reaction {
  emoji: string;
  user_id: string;
  message_id: string;
}

interface Conversation {
  id: string;
  order_id: string | null;
  buyer_id: string;
  seller_id: string;
  is_active: boolean | null;
  chat_theme: string | null;
}

const Chat = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [reactions, setReactions] = useState<Reaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [otherUserName, setOtherUserName] = useState("User");
  const [otherUserAvatar, setOtherUserAvatar] = useState<string | null>(null);
  const [otherUserId, setOtherUserId] = useState<string | undefined>();
  const [chatTheme, setChatTheme] = useState("default");
  const [searchQuery, setSearchQuery] = useState("");

  const { isOtherUserTyping, handleTypingStart, stopTyping } = useTypingIndicator(
    conversation?.id,
    user?.id
  );

  // Track online presence
  usePresence(user?.id);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchConversation = async () => {
      if (!orderId || !user) return;

      try {
        // First check if conversation exists
        let { data: convData, error: convError } = await supabase
          .from("conversations")
          .select("*")
          .eq("order_id", orderId)
          .single();

        if (convError && convError.code === "PGRST116") {
          // Conversation doesn't exist, create it
          const { data: orderData, error: orderError } = await supabase
            .from("orders")
            .select("buyer_id, seller_id")
            .eq("id", orderId)
            .single();

          if (orderError) throw orderError;

          // Verify user is part of this order
          if (orderData.buyer_id !== user.id && orderData.seller_id !== user.id) {
            toast.error("You don't have access to this conversation");
            navigate("/orders");
            return;
          }

          // Create conversation
          const { data: newConv, error: createError } = await supabase
            .from("conversations")
            .insert({
              order_id: orderId,
              buyer_id: orderData.buyer_id,
              seller_id: orderData.seller_id
            })
            .select()
            .single();

          if (createError) {
            console.error("Create conversation error:", createError);
          } else {
            convData = newConv;
          }
        }

        if (convData) {
          setConversation(convData);
          if (convData.chat_theme) {
            setChatTheme(convData.chat_theme);
          }

          // Get other user's name and avatar
          const recipientId = convData.buyer_id === user.id 
            ? convData.seller_id 
            : convData.buyer_id;

          setOtherUserId(recipientId);

          const { data: profileData } = await supabase
            .from("profiles")
            .select("full_name, avatar_url")
            .eq("user_id", recipientId)
            .single();

          if (profileData?.full_name) {
            setOtherUserName(profileData.full_name);
          }
          if (profileData?.avatar_url) {
            setOtherUserAvatar(profileData.avatar_url);
          }

          // Fetch messages
          const { data: msgData, error: msgError } = await supabase
            .from("messages")
            .select("*")
            .eq("conversation_id", convData.id)
            .order("created_at", { ascending: true });

          if (msgError) throw msgError;
          setMessages(msgData || []);

          // Fetch reactions
          if (msgData && msgData.length > 0) {
            const msgIds = msgData.map((m) => m.id);
            const { data: reactionsData } = await supabase
              .from("message_reactions")
              .select("*")
              .in("message_id", msgIds);
            setReactions(reactionsData || []);
          }

          // Mark unread messages as read
          if (msgData && user) {
            const unreadIds = msgData
              .filter((m) => m.sender_id !== user.id && !m.is_read)
              .map((m) => m.id);

            if (unreadIds.length > 0) {
              await supabase
                .from("messages")
                .update({ is_read: true })
                .in("id", unreadIds);
            }
          }
        }
      } catch (error: any) {
        console.error("Error:", error);
        toast.error("Failed to load conversation");
      } finally {
        setLoading(false);
      }
    };

    fetchConversation();
  }, [orderId, user, navigate]);

  // Real-time subscription
  useEffect(() => {
    if (!conversation?.id || !user) return;

    const channel = supabase
      .channel(`messages-${conversation.id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${conversation.id}`
        },
        (payload) => {
          if (payload.eventType === "INSERT") {
            const newMsg = payload.new as Message;
            setMessages((prev) => {
              if (prev.some((m) => m.id === newMsg.id)) return prev;
              return [...prev, newMsg];
            });

            if (newMsg.sender_id !== user.id) {
              supabase
                .from("messages")
                .update({ is_read: true })
                .eq("id", newMsg.id)
                .then();
            }
          } else if (payload.eventType === "UPDATE") {
            const updatedMsg = payload.new as Message;
            setMessages((prev) =>
              prev.map((m) => (m.id === updatedMsg.id ? updatedMsg : m))
            );
          }
        }
      )
      .subscribe();

    // Subscribe to reactions
    const reactionsChannel = supabase
      .channel(`reactions-${conversation.id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "message_reactions"
        },
        (payload) => {
          if (payload.eventType === "INSERT") {
            const newReaction = payload.new as Reaction;
            setReactions((prev) => [...prev, newReaction]);
          } else if (payload.eventType === "DELETE") {
            const deletedReaction = payload.old as { id: string };
            setReactions((prev) => prev.filter((r) => (r as any).id !== deletedReaction.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      supabase.removeChannel(reactionsChannel);
    };
  }, [conversation?.id, user]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isOtherUserTyping]);

  const handleThemeChange = useCallback(
    async (themeId: string) => {
      setChatTheme(themeId);
      if (conversation?.id) {
        await supabase
          .from("conversations")
          .update({ chat_theme: themeId })
          .eq("id", conversation.id);
      }
    },
    [conversation?.id]
  );

  const uploadAttachment = useCallback(async (
    file: Blob,
    type: "image" | "voice" | "file"
  ): Promise<string> => {
    if (!user || !conversation) throw new Error("Not authenticated");

    let extension = "bin";
    let contentType = "application/octet-stream";
    
    if (type === "image") {
      extension = "jpg";
      contentType = "image/jpeg";
    } else if (type === "voice") {
      extension = "webm";
      contentType = "audio/webm";
    } else if (file instanceof File) {
      extension = file.name.split(".").pop() || "bin";
      contentType = file.type || "application/octet-stream";
    }

    const fileName = `${user.id}/${conversation.id}/${Date.now()}.${extension}`;

    const { error: uploadError } = await supabase.storage
      .from("chat-attachments")
      .upload(fileName, file, { contentType });

    if (uploadError) throw uploadError;

    const { data: signedData, error: signedError } = await supabase.storage
      .from("chat-attachments")
      .createSignedUrl(fileName, 60 * 60 * 24 * 365);

    if (signedError || !signedData?.signedUrl) {
      throw signedError || new Error("Failed to generate URL");
    }

    return signedData.signedUrl;
  }, [user, conversation]);

  const handleSendText = useCallback(async (text: string) => {
    if (!conversation || !user) return;
    stopTyping();

    const { error } = await supabase.from("messages").insert({
      conversation_id: conversation.id,
      sender_id: user.id,
      content: text,
      message_type: "text"
    });

    if (error) throw error;
  }, [conversation, user, stopTyping]);

  const handleSendSticker = useCallback(async (sticker: string) => {
    if (!conversation || !user) return;
    stopTyping();

    const { error } = await supabase.from("messages").insert({
      conversation_id: conversation.id,
      sender_id: user.id,
      content: sticker,
      message_type: "sticker"
    });

    if (error) throw error;
  }, [conversation, user, stopTyping]);

  const handleSendVoice = useCallback(async (blob: Blob) => {
    if (!conversation || !user) return;

    const attachmentUrl = await uploadAttachment(blob, "voice");

    const { error } = await supabase.from("messages").insert({
      conversation_id: conversation.id,
      sender_id: user.id,
      content: null,
      message_type: "voice",
      attachment_url: attachmentUrl
    });

    if (error) throw error;
  }, [conversation, user, uploadAttachment]);

  const handleSendImage = useCallback(async (file: File) => {
    if (!conversation || !user) return;

    const attachmentUrl = await uploadAttachment(file, "image");

    const { error } = await supabase.from("messages").insert({
      conversation_id: conversation.id,
      sender_id: user.id,
      content: null,
      message_type: "image",
      attachment_url: attachmentUrl
    });

    if (error) throw error;
  }, [conversation, user, uploadAttachment]);

  const handleSendFile = useCallback(async (file: File) => {
    if (!conversation || !user) return;

    const attachmentUrl = await uploadAttachment(file, "file");

    const { error } = await supabase.from("messages").insert({
      conversation_id: conversation.id,
      sender_id: user.id,
      content: file.name,
      message_type: "file",
      attachment_url: attachmentUrl
    });

    if (error) throw error;
  }, [conversation, user, uploadAttachment]);

  const currentTheme = chatThemes.find((t) => t.id === chatTheme) || chatThemes[0];

  // Filter messages by search query
  const filteredMessages = useMemo(() => {
    if (!searchQuery.trim()) return messages;
    return messages.filter((msg) =>
      msg.content?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [messages, searchQuery]);

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user) return null;

  const isClosed = conversation && !conversation.is_active;

  return (
    <MainLayout>
      <div className={cn("min-h-screen flex flex-col", currentTheme.background)}>
        <ChatHeader
          otherUserName={otherUserName}
          otherUserAvatar={otherUserAvatar}
          otherUserId={otherUserId}
          isTyping={isOtherUserTyping}
          isClosed={!!isClosed}
          isOrderChat
          chatTheme={chatTheme}
          onThemeChange={handleThemeChange}
          onBack={() => navigate("/orders")}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-6">
          <div className="max-w-3xl mx-auto space-y-4">
            {filteredMessages.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                  <span className="text-3xl">{searchQuery ? "🔍" : "📦"}</span>
                </div>
                <h3 className="text-lg font-medium text-foreground mb-1">
                  {searchQuery ? "No messages found" : "Order conversation"}
                </h3>
                <p className="text-muted-foreground text-sm">
                  {searchQuery ? "Try a different search term" : "Discuss your order details here"}
                </p>
              </div>
            ) : (
              filteredMessages.map((message) => (
                <ModernChatBubble
                  key={message.id}
                  id={message.id}
                  content={message.content}
                  messageType={message.message_type as "text" | "image" | "voice" | "sticker" | "file"}
                  attachmentUrl={message.attachment_url}
                  isOwnMessage={message.sender_id === user.id}
                  createdAt={message.created_at}
                  isRead={message.is_read}
                  isPinned={message.is_pinned}
                  isDeleted={message.is_deleted}
                  reactions={reactions.filter((r) => r.message_id === message.id)}
                  currentUserId={user.id}
                  conversationId={conversation?.id}
                  searchQuery={searchQuery}
                />
              ))
            )}
            {isOtherUserTyping && (
              <TypingIndicator userName={otherUserName} />
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Input */}
        <ChatInputBar
          isClosed={!!isClosed}
          onSendText={handleSendText}
          onSendVoice={handleSendVoice}
          onSendImage={handleSendImage}
          onSendSticker={handleSendSticker}
          onSendFile={handleSendFile}
          onTyping={handleTypingStart}
        />
      </div>
    </MainLayout>
  );
};

export default Chat;