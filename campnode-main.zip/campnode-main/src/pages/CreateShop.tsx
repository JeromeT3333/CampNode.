import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { z } from "zod";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ImageUpload } from "@/components/ImageUpload";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { 
  Store, 
  MapPin, 
  ArrowRight,
  Info,
  Loader2
} from "lucide-react";
import { cn } from "@/lib/utils";

// Validation schema for shop creation
const shopSchema = z.object({
  shopName: z.string()
    .trim()
    .min(3, "Shop name must be at least 3 characters")
    .max(100, "Shop name must be less than 100 characters"),
  description: z.string()
    .trim()
    .min(10, "Description must be at least 10 characters")
    .max(1000, "Description must be less than 1000 characters"),
  location: z.string()
    .trim()
    .min(5, "Location must be at least 5 characters")
    .max(200, "Location must be less than 200 characters"),
  category: z.enum(["food", "services", "photography", "printing", "fashion", "provisions", "store", "other"], {
    errorMap: () => ({ message: "Please select a valid category" })
  }),
  otherCategory: z.string().max(20, "Max 3 words (20 characters)").optional(),
});

const categories = [
  { id: "food", name: "Food & Restaurant", icon: "🍔" },
  { id: "services", name: "Services", icon: "✂️" },
  { id: "photography", name: "Photography", icon: "📷" },
  { id: "printing", name: "Printing & Cyber", icon: "🖨️" },
  { id: "fashion", name: "Fashion", icon: "👕" },
  { id: "provisions", name: "Provisions", icon: "🛒" },
  { id: "store", name: "Store", icon: "🏬" },
  { id: "other", name: "Other", icon: "📦" },
];

const CreateShop = () => {
  const [selectedCategory, setSelectedCategory] = useState("");
  const [otherCategory, setOtherCategory] = useState("");
  const [shopName, setShopName] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [coverImage, setCoverImage] = useState<string | null>(null);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
    }
  }, [user, loading, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationErrors({});
    
    if (!user) {
      toast({
        title: "Please sign in",
        description: "You need to be signed in to create a shop.",
        variant: "destructive",
      });
      navigate("/auth");
      return;
    }

    // Validate inputs with Zod schema
    const validationResult = shopSchema.safeParse({
      shopName: shopName.trim(),
      description: description.trim(),
      location: location.trim(),
      category: selectedCategory || undefined,
    });

    if (!validationResult.success) {
      const errors: Record<string, string> = {};
      validationResult.error.errors.forEach((err) => {
        const field = err.path[0] as string;
        errors[field] = err.message;
      });
      setValidationErrors(errors);
      toast({
        title: "Validation Error",
        description: "Please fix the highlighted fields.",
        variant: "destructive",
      });
      return;
    }

    const validatedData = validationResult.data;

    setIsSubmitting(true);

    try {
      const { data, error } = await supabase
        .from("shops")
        .insert({
          owner_id: user.id,
          name: validatedData.shopName,
          description: validatedData.description,
          category: validatedData.category,
          location: validatedData.location,
          cover_image: coverImage,
          profile_image: profileImage,
        })
        .select()
        .single();

      if (error) throw error;

      toast({
        title: "Shop created!",
        description: "Your shop has been created successfully.",
      });
      
      navigate("/dashboard");
    } catch (error: unknown) {
      console.error("Shop creation error:", error);
      toast({
        title: "Error creating shop",
        description: "Failed to create shop. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4">
              <Store className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-2">Create Your Shop</h1>
            <p className="text-muted-foreground">
              Set up your shop page and start selling to the campus community
            </p>
          </div>

          {/* Info Banner */}
          <div className="mb-8 p-4 bg-primary/10 rounded-xl flex items-start gap-3">
            <Info className="h-5 w-5 text-primary mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-foreground mb-1">What's a Shop?</p>
              <p className="text-muted-foreground">
                A shop is like your own storefront on CampNode. You can add products, 
                services, manage orders, and build your brand. Perfect for restaurants, 
                salons, printing services, and more!
              </p>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Cover Image */}
            <div className="space-y-2">
              <Label>Cover Image</Label>
              <ImageUpload
                value={coverImage || undefined}
                onChange={(url) => setCoverImage(url)}
                bucket="shops"
                folder="covers"
                aspectRatio="banner"
              />
              <p className="text-xs text-muted-foreground">
                Recommended: 1200 x 400px
              </p>
            </div>

            {/* Shop Logo */}
            <div className="space-y-2">
              <Label>Shop Logo</Label>
              <div className="flex items-center gap-4">
                <ImageUpload
                  value={profileImage || undefined}
                  onChange={(url) => setProfileImage(url)}
                  bucket="shops"
                  folder="logos"
                  aspectRatio="square"
                  className="w-24 h-24"
                />
                <div className="text-sm text-muted-foreground">
                  <p>Upload your shop logo</p>
                  <p className="text-xs">Square image works best</p>
                </div>
              </div>
            </div>

            {/* Shop Name */}
            <div className="space-y-2">
              <Label htmlFor="shopName">Shop Name *</Label>
              <Input
                id="shopName"
                placeholder="e.g., Campus Kitchen, Print Hub"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                required
                disabled={isSubmitting}
                maxLength={100}
                className={validationErrors.shopName ? "border-destructive" : ""}
              />
              {validationErrors.shopName && (
                <p className="text-sm text-destructive">{validationErrors.shopName}</p>
              )}
            </div>

            {/* Category */}
            <div className="space-y-2">
              <Label>Category *</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    type="button"
                    onClick={() => setSelectedCategory(category.id)}
                    disabled={isSubmitting}
                    className={cn(
                      "flex items-center gap-2 p-3 rounded-xl border transition-all",
                      selectedCategory === category.id
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border bg-card text-muted-foreground hover:border-primary/50",
                      validationErrors.category && "border-destructive"
                    )}
                  >
                    <span className="text-xl">{category.icon}</span>
                    <span className="text-sm font-medium">{category.name}</span>
                  </button>
                ))}
              </div>
              {validationErrors.category && (
                <p className="text-sm text-destructive">{validationErrors.category}</p>
              )}
              
              {/* Other category text field */}
              {selectedCategory === "other" && (
                <div className="mt-3">
                  <Label htmlFor="otherCategory">Specify Category (max 3 words)</Label>
                  <Input
                    id="otherCategory"
                    placeholder="e.g., Gadget Repairs"
                    value={otherCategory}
                    onChange={(e) => setOtherCategory(e.target.value)}
                    maxLength={20}
                    disabled={isSubmitting}
                    className="mt-1"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {otherCategory.length}/20 characters
                  </p>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                placeholder="Tell customers about your shop, what you offer, and your operating hours..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                required
                disabled={isSubmitting}
                maxLength={1000}
                className={validationErrors.description ? "border-destructive" : ""}
              />
              <div className="flex justify-between">
                {validationErrors.description ? (
                  <p className="text-sm text-destructive">{validationErrors.description}</p>
                ) : (
                  <span />
                )}
                <span className="text-xs text-muted-foreground">{description.length}/1000</span>
              </div>
            </div>

            {/* Location */}
            <div className="space-y-2">
              <Label htmlFor="location">Location *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="location"
                  placeholder="e.g., Near Main Library, Behind Student Center"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className={cn("pl-10", validationErrors.location && "border-destructive")}
                  required
                  disabled={isSubmitting}
                  maxLength={200}
                />
              </div>
              {validationErrors.location ? (
                <p className="text-sm text-destructive">{validationErrors.location}</p>
              ) : (
                <p className="text-xs text-muted-foreground">
                  Provide a campus landmark for easy navigation
                </p>
              )}
            </div>

            {/* Submit */}
            <div className="pt-4">
              <Button 
                type="submit" 
                size="lg" 
                className="w-full gap-2 gradient-primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Creating Shop...
                  </>
                ) : (
                  <>
                    Create Shop
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </Button>
              <p className="mt-4 text-center text-sm text-muted-foreground">
                By creating a shop, you agree to our{" "}
                <Link to="/terms" className="text-primary hover:underline">
                  Seller Terms
                </Link>
              </p>
            </div>
          </form>
        </div>
      </div>
    </MainLayout>
  );
};

export default CreateShop;
