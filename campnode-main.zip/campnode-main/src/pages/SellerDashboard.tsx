import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { 
  Loader2,
  TrendingUp,
  DollarSign,
  ShoppingCart,
  Clock,
  CheckCircle,
  XCircle,
  FileText,
  FileJson
} from "lucide-react";
import jsPDF from "jspdf";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface Transaction {
  id: string;
  transaction_reference: string;
  gross_amount: number;
  platform_fee: number;
  seller_amount: number;
  payment_status: string;
  created_at: string;
}

interface Payout {
  id: string;
  payout_reference: string;
  amount: number;
  status: string;
  account_name: string;
  created_at: string;
}

const SellerDashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalSales: 0,
    totalEarnings: 0,
    totalPayouts: 0,
    pendingPayouts: 0
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;
      
      try {
        // Fetch transactions
        const { data: txData, error: txError } = await supabase
          .from("transactions")
          .select("*")
          .eq("seller_id", user.id)
          .order("created_at", { ascending: false });

        if (txError) {
          console.error("Error fetching transactions:", txError);
        } else {
          setTransactions(txData || []);
          
          // Calculate stats
          const completedTx = txData?.filter(t => t.payment_status === 'completed') || [];
          setStats(prev => ({
            ...prev,
            totalSales: completedTx.length,
            totalEarnings: completedTx.reduce((sum, t) => sum + Number(t.seller_amount), 0)
          }));
        }

        // Fetch payouts
        const { data: payoutData, error: payoutError } = await supabase
          .from("payouts")
          .select("*")
          .eq("seller_id", user.id)
          .order("created_at", { ascending: false });

        if (payoutError) {
          console.error("Error fetching payouts:", payoutError);
        } else {
          setPayouts(payoutData || []);
          
          const completedPayouts = payoutData?.filter(p => p.status === 'completed') || [];
          const pendingPayouts = payoutData?.filter(p => ['pending', 'processing'].includes(p.status)) || [];
          
          setStats(prev => ({
            ...prev,
            totalPayouts: completedPayouts.reduce((sum, p) => sum + Number(p.amount), 0),
            pendingPayouts: pendingPayouts.reduce((sum, p) => sum + Number(p.amount), 0)
          }));
        }
      } catch (error) {
        console.error("Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN'
    }).format(amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-NG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500/10 text-green-600 border-green-500/20"><CheckCircle className="h-3 w-3 mr-1" />Completed</Badge>;
      case 'pending':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'processing':
        return <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20"><Loader2 className="h-3 w-3 mr-1 animate-spin" />Processing</Badge>;
      case 'failed':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const generateReceiptPDF = (tx: Transaction) => {
    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(20);
    doc.setFont("helvetica", "bold");
    doc.text("CAMPNODE", 105, 20, { align: "center" });
    doc.setFontSize(12);
    doc.setFont("helvetica", "normal");
    doc.text("Sales Receipt", 105, 28, { align: "center" });
    
    // Line separator
    doc.setDrawColor(200, 200, 200);
    doc.line(20, 35, 190, 35);
    
    // Transaction details
    doc.setFontSize(10);
    doc.text(`Transaction ID: ${tx.transaction_reference}`, 20, 45);
    doc.text(`Date: ${formatDate(tx.created_at)}`, 20, 52);
    doc.text(`Status: ${tx.payment_status.toUpperCase()}`, 20, 59);
    
    // Amounts section
    doc.setDrawColor(200, 200, 200);
    doc.line(20, 65, 190, 65);
    doc.setFontSize(11);
    doc.text("Payment Breakdown", 20, 73);
    doc.setFontSize(10);
    doc.text(`Gross Amount:`, 20, 82);
    doc.text(formatCurrency(tx.gross_amount), 190, 82, { align: "right" });
    doc.text(`Platform Fee:`, 20, 89);
    doc.text(`-${formatCurrency(tx.platform_fee)}`, 190, 89, { align: "right" });
    doc.line(20, 93, 190, 93);
    doc.setFont("helvetica", "bold");
    doc.text(`Your Earnings:`, 20, 100);
    doc.text(formatCurrency(tx.seller_amount), 190, 100, { align: "right" });
    
    // Footer
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(128, 128, 128);
    doc.text("Thank you for selling on CampNode!", 105, 270, { align: "center" });
    doc.text("campnode.lovable.app | support@campnode.com", 105, 276, { align: "center" });
    
    doc.save(`receipt-${tx.transaction_reference}.pdf`);
  };

  const generateReceiptJSON = (tx: Transaction) => {
    const receipt = {
      platform: "CampNode",
      type: "sales_receipt",
      transaction_reference: tx.transaction_reference,
      date: tx.created_at,
      amounts: {
        gross_amount: tx.gross_amount,
        platform_fee: tx.platform_fee,
        seller_earnings: tx.seller_amount,
        currency: "NGN"
      },
      status: tx.payment_status,
      footer: {
        website: "campnode.lovable.app",
        email: "support@campnode.com",
        message: "Thank you for selling on CampNode!"
      }
    };
    
    const blob = new Blob([JSON.stringify(receipt, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `receipt-${tx.transaction_reference}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user) return null;

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-6xl mx-auto space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Seller Dashboard</h1>
            <p className="text-muted-foreground">Track your sales, earnings, and payouts</p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <ShoppingCart className="h-5 w-5 text-primary" />
                  <span className="text-sm text-muted-foreground">Total Sales</span>
                </div>
                <p className="text-2xl font-bold">{stats.totalSales}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  <span className="text-sm text-muted-foreground">Total Earnings</span>
                </div>
                <p className="text-2xl font-bold">{formatCurrency(stats.totalEarnings)}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="h-5 w-5 text-blue-500" />
                  <span className="text-sm text-muted-foreground">Total Payouts</span>
                </div>
                <p className="text-2xl font-bold">{formatCurrency(stats.totalPayouts)}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="h-5 w-5 text-yellow-500" />
                  <span className="text-sm text-muted-foreground">Pending</span>
                </div>
                <p className="text-2xl font-bold">{formatCurrency(stats.pendingPayouts)}</p>
              </CardContent>
            </Card>
          </div>

          {/* Transactions */}
          <Card>
            <CardHeader>
              <CardTitle>Sales History</CardTitle>
              <CardDescription>Your recent sales and earnings</CardDescription>
            </CardHeader>
            <CardContent>
              {transactions.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No sales yet</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Reference</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Fee</TableHead>
                      <TableHead>Earnings</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell className="font-mono text-xs">{tx.transaction_reference.slice(0, 20)}...</TableCell>
                        <TableCell className="text-sm">{formatDate(tx.created_at)}</TableCell>
                        <TableCell>{formatCurrency(tx.gross_amount)}</TableCell>
                        <TableCell className="text-muted-foreground">{formatCurrency(tx.platform_fee)}</TableCell>
                        <TableCell className="font-medium text-green-600">{formatCurrency(tx.seller_amount)}</TableCell>
                        <TableCell>{getStatusBadge(tx.payment_status)}</TableCell>
                        <TableCell className="flex gap-1">
                          <Button variant="ghost" size="sm" onClick={() => generateReceiptPDF(tx)} title="Download PDF">
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => generateReceiptJSON(tx)} title="Download JSON">
                            <FileJson className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Payouts */}
          <Card>
            <CardHeader>
              <CardTitle>Payout History</CardTitle>
              <CardDescription>Transfers to your bank account</CardDescription>
            </CardHeader>
            <CardContent>
              {payouts.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No payouts yet</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Reference</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Account</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payouts.map((payout) => (
                      <TableRow key={payout.id}>
                        <TableCell className="font-mono text-xs">{payout.payout_reference.slice(0, 20)}...</TableCell>
                        <TableCell className="text-sm">{formatDate(payout.created_at)}</TableCell>
                        <TableCell className="font-medium">{formatCurrency(payout.amount)}</TableCell>
                        <TableCell>{payout.account_name}</TableCell>
                        <TableCell>{getStatusBadge(payout.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default SellerDashboard;
