import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Loader2,
  Package,
  CheckCircle,
  Clock,
  MessageCircle,
  XCircle,
  AlertCircle
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Order {
  id: string;
  quantity: number;
  total_amount: number;
  status: string;
  payment_status: string;
  escrow_status: string | null;
  service_fee: number | null;
  seller_amount: number | null;
  created_at: string;
  seller_id: string;
  buyer_id: string;
  products?: {
    name: string;
    image: string | null;
  } | null;
}

const Orders = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmingOrder, setConfirmingOrder] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!user) return;

      try {
        const { data, error } = await supabase
          .from("orders")
          .select("*, products(name, image)")
          .or(`buyer_id.eq.${user.id},seller_id.eq.${user.id}`)
          .order("created_at", { ascending: false });

        if (error) throw error;
        setOrders(data || []);
      } catch (error: any) {
        console.error("Error fetching orders:", error);
        toast.error("Failed to load orders");
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();

    // Show success message for new order
    const newOrderId = searchParams.get("new");
    if (newOrderId) {
      toast.success("Order placed successfully!");
    }
  }, [user, searchParams]);

  const handleConfirmDelivery = async (orderId: string) => {
    setConfirmingOrder(orderId);
    try {
      // Use edge function for escrow release
      const { data, error } = await supabase.functions.invoke("confirm-delivery", {
        body: { order_id: orderId }
      });

      if (error) throw error;
      if (data.status !== "success") throw new Error(data.message);

      toast.success("Delivery confirmed! Payment released to seller.");
      
      // Update local state
      setOrders(orders.map(o => 
        o.id === orderId ? { ...o, status: "completed", escrow_status: "released" } : o
      ));
    } catch (error: unknown) {
      console.error("Error confirming delivery:", error);
      const message = error instanceof Error ? error.message : "Failed to confirm delivery";
      toast.error(message);
    } finally {
      setConfirmingOrder(null);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN"
    }).format(price);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-NG", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  const getStatusBadge = (status: string, paymentStatus: string, escrowStatus: string | null) => {
    if (paymentStatus === "pending") {
      return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Payment Pending</Badge>;
    }
    if (escrowStatus === "held") {
      return <Badge className="bg-accent/10 text-accent border-accent/20"><Clock className="h-3 w-3 mr-1" />In Escrow</Badge>;
    }
    switch (status) {
      case "completed":
        return <Badge className="bg-primary/10 text-primary border-primary/20"><CheckCircle className="h-3 w-3 mr-1" />Completed</Badge>;
      case "confirmed":
        return <Badge className="bg-secondary/10 text-secondary border-secondary/20"><Package className="h-3 w-3 mr-1" />Confirmed</Badge>;
      case "cancelled":
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Cancelled</Badge>;
      default:
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    }
  };

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user) return null;

  const buyerOrders = orders.filter(o => o.buyer_id === user.id);
  const sellerOrders = orders.filter(o => o.seller_id === user.id);

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-4xl mx-auto space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Orders</h1>
            <p className="text-muted-foreground">Track your purchases and sales</p>
          </div>

          {/* My Purchases */}
          <Card>
            <CardHeader>
              <CardTitle>My Purchases</CardTitle>
              <CardDescription>Items you've bought</CardDescription>
            </CardHeader>
            <CardContent>
              {buyerOrders.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No purchases yet</p>
              ) : (
                <div className="space-y-4">
                  {buyerOrders.map((order) => (
                    <div
                      key={order.id}
                      className="flex items-center gap-4 p-4 rounded-xl border border-border"
                    >
                      <div className="w-16 h-16 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                        {order.products?.image ? (
                          <img
                            src={order.products.image}
                            alt={order.products.name || "Product"}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Package className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-foreground truncate">
                          {order.products?.name || "Product"}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Qty: {order.quantity} • {formatDate(order.created_at)}
                        </p>
                        <p className="font-semibold text-primary">
                          {formatPrice(order.total_amount)}
                        </p>
                      </div>

                      <div className="flex flex-col items-end gap-2">
                        {getStatusBadge(order.status, order.payment_status, order.escrow_status)}
                        
                        {(order.escrow_status === "held" || (order.status === "confirmed" && order.payment_status === "paid")) && (
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => navigate(`/chat/${order.id}`)}
                            >
                              <MessageCircle className="h-4 w-4" />
                            </Button>
                            
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="sm" disabled={confirmingOrder === order.id}>
                                  {confirmingOrder === order.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                  )}
                                  Received
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirm Item Received?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    <div className="flex items-start gap-2 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 mb-4">
                                      <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                                      <span className="text-sm text-yellow-600">
                                        This action cannot be undone. Confirming will release payment to the seller and close the chat.
                                      </span>
                                    </div>
                                    Only confirm if you have received the item/service and are satisfied with your purchase.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleConfirmDelivery(order.id)}
                                  >
                                    Yes, I've Received It
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* My Sales */}
          <Card>
            <CardHeader>
              <CardTitle>My Sales</CardTitle>
              <CardDescription>Items you've sold</CardDescription>
            </CardHeader>
            <CardContent>
              {sellerOrders.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No sales yet</p>
              ) : (
                <div className="space-y-4">
                  {sellerOrders.map((order) => (
                    <div
                      key={order.id}
                      className="flex items-center gap-4 p-4 rounded-xl border border-border"
                    >
                      <div className="w-16 h-16 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                        {order.products?.image ? (
                          <img
                            src={order.products.image}
                            alt={order.products.name || "Product"}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Package className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-foreground truncate">
                          {order.products?.name || "Product"}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Qty: {order.quantity} • {formatDate(order.created_at)}
                        </p>
                        <p className="font-semibold text-primary">
                          +{formatPrice(order.seller_amount || order.total_amount * 0.95)}
                        </p>
                      </div>

                      <div className="flex flex-col items-end gap-2">
                        {getStatusBadge(order.status, order.payment_status, order.escrow_status)}
                        
                        {(order.escrow_status === "held" || (order.status === "confirmed" && order.payment_status === "paid")) && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => navigate(`/chat/${order.id}`)}
                          >
                            <MessageCircle className="h-4 w-4 mr-1" />
                            Chat
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default Orders;
