 import { useState, useEffect } from "react";
 import { AdminLayout } from "./AdminLayout";
 import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
 import { Button } from "@/components/ui/button";
 import { Input } from "@/components/ui/input";
 import { Badge } from "@/components/ui/badge";
 import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
 import { supabase } from "@/integrations/supabase/client";
 import { toast } from "sonner";
 import {
   Table,
   TableBody,
   TableCell,
   TableHead,
   TableHeader,
   TableRow,
 } from "@/components/ui/table";
 import {
   DropdownMenu,
   DropdownMenuContent,
   DropdownMenuItem,
   DropdownMenuSeparator,
   DropdownMenuTrigger,
 } from "@/components/ui/dropdown-menu";
 import {
   Dialog,
   DialogContent,
   DialogHeader,
   DialogTitle,
   DialogFooter,
 } from "@/components/ui/dialog";
 import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
 } from "@/components/ui/select";
 import { Textarea } from "@/components/ui/textarea";
 import { Label } from "@/components/ui/label";
 import {
   Search,
   MoreVertical,
   Shield,
   Crown,
   Ban,
   Eye,
   Loader2,
   User,
 } from "lucide-react";
 import { useNavigate } from "react-router-dom";
 
 interface UserProfile {
   id: string;
   user_id: string;
   full_name: string | null;
   username: string | null;
   avatar_url: string | null;
   role: string | null;
   campus_location: string | null;
   created_at: string;
 }
 
 interface UserRole {
   user_id: string;
   role: string;
 }
 
 const AdminUsers = () => {
   const navigate = useNavigate();
   const [users, setUsers] = useState<UserProfile[]>([]);
   const [userRoles, setUserRoles] = useState<Record<string, string[]>>({});
   const [loading, setLoading] = useState(true);
   const [search, setSearch] = useState("");
   
   // Dialogs
   const [roleDialog, setRoleDialog] = useState<{ open: boolean; user: UserProfile | null }>({ open: false, user: null });
   const [restrictDialog, setRestrictDialog] = useState<{ open: boolean; user: UserProfile | null }>({ open: false, user: null });
   const [selectedRole, setSelectedRole] = useState("user");
   const [restrictReason, setRestrictReason] = useState("");
   const [restrictType, setRestrictType] = useState("suspended");
 
   useEffect(() => {
     fetchUsers();
   }, []);
 
   const fetchUsers = async () => {
     try {
       const { data: profiles, error } = await supabase
         .from("profiles")
         .select("*")
         .order("created_at", { ascending: false });
 
       if (error) throw error;
       setUsers(profiles || []);
 
       // Fetch roles
       const { data: roles } = await supabase.from("user_roles").select("user_id, role");
       const rolesMap: Record<string, string[]> = {};
       (roles || []).forEach((r: UserRole) => {
         if (!rolesMap[r.user_id]) rolesMap[r.user_id] = [];
         rolesMap[r.user_id].push(r.role);
       });
       setUserRoles(rolesMap);
     } catch (error) {
       console.error("Error fetching users:", error);
       toast.error("Failed to load users");
     } finally {
       setLoading(false);
     }
   };
 
   const handleAssignRole = async () => {
     if (!roleDialog.user) return;
     
     try {
       // Check if role already exists
       const { data: existing } = await supabase
         .from("user_roles")
         .select("*")
         .eq("user_id", roleDialog.user.user_id)
        .eq("role", selectedRole as "admin" | "moderator" | "user" | "support")
         .maybeSingle();
 
       if (existing) {
         toast.info("User already has this role");
         return;
       }
 
      const { error } = await supabase.from("user_roles").insert([
        {
          user_id: roleDialog.user.user_id,
          role: selectedRole as "admin" | "moderator" | "user" | "support",
        }
      ]);
 
       if (error) throw error;
       toast.success(`${selectedRole} role assigned`);
       setRoleDialog({ open: false, user: null });
       fetchUsers();
     } catch (error) {
       console.error("Error assigning role:", error);
       toast.error("Failed to assign role");
     }
   };
 
   const handleRestrict = async () => {
     if (!restrictDialog.user) return;
 
     try {
       const { data: { user: adminUser } } = await supabase.auth.getUser();
       if (!adminUser) throw new Error("Not authenticated");
 
       const { error } = await supabase.from("account_restrictions").insert({
         user_id: restrictDialog.user.user_id,
         restricted_by: adminUser.id,
         restriction_type: restrictType,
         reason: restrictReason,
       });
 
       if (error) throw error;
       toast.success("Account restricted");
       setRestrictDialog({ open: false, user: null });
       setRestrictReason("");
     } catch (error) {
       console.error("Error restricting account:", error);
       toast.error("Failed to restrict account");
     }
   };
 
   const filteredUsers = users.filter(
     (u) =>
       u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
       u.username?.toLowerCase().includes(search.toLowerCase()) ||
       u.user_id.includes(search)
   );
 
   const formatDate = (dateString: string) => {
     return new Date(dateString).toLocaleDateString("en-NG", {
       year: "numeric",
       month: "short",
       day: "numeric",
     });
   };
 
   return (
     <AdminLayout>
       <div className="p-6 space-y-6">
         <div className="flex items-center justify-between">
           <div>
             <h1 className="text-2xl font-bold">User Management</h1>
             <p className="text-muted-foreground">Manage user accounts and roles</p>
           </div>
         </div>
 
         {/* Search */}
         <div className="relative max-w-md">
           <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
           <Input
             placeholder="Search users..."
             value={search}
             onChange={(e) => setSearch(e.target.value)}
             className="pl-10"
           />
         </div>
 
         {/* Users Table */}
         <Card>
           <CardHeader>
             <CardTitle>All Users ({filteredUsers.length})</CardTitle>
           </CardHeader>
           <CardContent>
             {loading ? (
               <div className="flex items-center justify-center py-8">
                 <Loader2 className="h-8 w-8 animate-spin" />
               </div>
             ) : (
               <Table>
                 <TableHeader>
                   <TableRow>
                     <TableHead>User</TableHead>
                     <TableHead>Roles</TableHead>
                     <TableHead>Location</TableHead>
                     <TableHead>Joined</TableHead>
                     <TableHead className="text-right">Actions</TableHead>
                   </TableRow>
                 </TableHeader>
                 <TableBody>
                   {filteredUsers.map((user) => (
                     <TableRow key={user.id}>
                       <TableCell>
                         <div className="flex items-center gap-3">
                           <Avatar>
                             <AvatarImage src={user.avatar_url || undefined} />
                             <AvatarFallback>
                               <User className="h-4 w-4" />
                             </AvatarFallback>
                           </Avatar>
                           <div>
                             <p className="font-medium">{user.full_name || "Unnamed"}</p>
                             <p className="text-xs text-muted-foreground">
                               @{user.username || user.user_id.slice(0, 8)}
                             </p>
                           </div>
                         </div>
                       </TableCell>
                       <TableCell>
                         <div className="flex gap-1 flex-wrap">
                           {(userRoles[user.user_id] || ["user"]).map((role) => (
                             <Badge
                               key={role}
                               variant={role === "admin" ? "default" : role === "support" ? "secondary" : "outline"}
                             >
                               {role === "admin" && <Shield className="h-3 w-3 mr-1" />}
                               {role === "support" && <Crown className="h-3 w-3 mr-1" />}
                               {role}
                             </Badge>
                           ))}
                         </div>
                       </TableCell>
                       <TableCell>{user.campus_location || "—"}</TableCell>
                       <TableCell>{formatDate(user.created_at)}</TableCell>
                       <TableCell className="text-right">
                         <DropdownMenu>
                           <DropdownMenuTrigger asChild>
                             <Button variant="ghost" size="icon">
                               <MoreVertical className="h-4 w-4" />
                             </Button>
                           </DropdownMenuTrigger>
                           <DropdownMenuContent align="end">
                             <DropdownMenuItem onClick={() => navigate(`/user/${user.user_id}`)}>
                               <Eye className="h-4 w-4 mr-2" />
                               View Profile
                             </DropdownMenuItem>
                             <DropdownMenuItem onClick={() => {
                               setRoleDialog({ open: true, user });
                               setSelectedRole("user");
                             }}>
                               <Shield className="h-4 w-4 mr-2" />
                               Assign Role
                             </DropdownMenuItem>
                             <DropdownMenuSeparator />
                             <DropdownMenuItem
                               onClick={() => setRestrictDialog({ open: true, user })}
                               className="text-destructive"
                             >
                               <Ban className="h-4 w-4 mr-2" />
                               Restrict Account
                             </DropdownMenuItem>
                           </DropdownMenuContent>
                         </DropdownMenu>
                       </TableCell>
                     </TableRow>
                   ))}
                 </TableBody>
               </Table>
             )}
           </CardContent>
         </Card>
 
         {/* Assign Role Dialog */}
         <Dialog open={roleDialog.open} onOpenChange={(open) => setRoleDialog({ open, user: roleDialog.user })}>
           <DialogContent>
             <DialogHeader>
               <DialogTitle>Assign Role to {roleDialog.user?.full_name}</DialogTitle>
             </DialogHeader>
             <div className="space-y-4 py-4">
               <div className="space-y-2">
                 <Label>Select Role</Label>
                 <Select value={selectedRole} onValueChange={setSelectedRole}>
                   <SelectTrigger>
                     <SelectValue />
                   </SelectTrigger>
                   <SelectContent>
                     <SelectItem value="user">User</SelectItem>
                     <SelectItem value="moderator">Moderator</SelectItem>
                     <SelectItem value="support">Support</SelectItem>
                     <SelectItem value="admin">Admin</SelectItem>
                   </SelectContent>
                 </Select>
               </div>
             </div>
             <DialogFooter>
               <Button variant="outline" onClick={() => setRoleDialog({ open: false, user: null })}>
                 Cancel
               </Button>
               <Button onClick={handleAssignRole}>Assign Role</Button>
             </DialogFooter>
           </DialogContent>
         </Dialog>
 
         {/* Restrict Dialog */}
         <Dialog open={restrictDialog.open} onOpenChange={(open) => setRestrictDialog({ open, user: restrictDialog.user })}>
           <DialogContent>
             <DialogHeader>
               <DialogTitle>Restrict Account: {restrictDialog.user?.full_name}</DialogTitle>
             </DialogHeader>
             <div className="space-y-4 py-4">
               <div className="space-y-2">
                 <Label>Restriction Type</Label>
                 <Select value={restrictType} onValueChange={setRestrictType}>
                   <SelectTrigger>
                     <SelectValue />
                   </SelectTrigger>
                   <SelectContent>
                     <SelectItem value="suspended">Suspended</SelectItem>
                     <SelectItem value="warning">Warning</SelectItem>
                     <SelectItem value="under_review">Under Review</SelectItem>
                   </SelectContent>
                 </Select>
               </div>
               <div className="space-y-2">
                 <Label>Reason</Label>
                 <Textarea
                   value={restrictReason}
                   onChange={(e) => setRestrictReason(e.target.value)}
                   placeholder="Enter reason for restriction..."
                 />
               </div>
             </div>
             <DialogFooter>
               <Button variant="outline" onClick={() => setRestrictDialog({ open: false, user: null })}>
                 Cancel
               </Button>
               <Button variant="destructive" onClick={handleRestrict}>
                 Restrict Account
               </Button>
             </DialogFooter>
           </DialogContent>
         </Dialog>
       </div>
     </AdminLayout>
   );
 };
 
 export default AdminUsers;