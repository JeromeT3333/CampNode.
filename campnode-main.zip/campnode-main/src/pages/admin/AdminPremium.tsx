import { useState, useEffect } from "react";
import { AdminLayout } from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Search, Crown, Plus, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface PremiumMembership {
  id: string;
  user_id: string;
  tier: string;
  is_active: boolean | null;
  started_at: string | null;
  expires_at: string | null;
  profiles?: { full_name: string | null; username: string | null } | null;
}

interface Profile {
  user_id: string;
  full_name: string | null;
  username: string | null;
}

export default function AdminPremium() {
  const [memberships, setMemberships] = useState<PremiumMembership[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState("");
  const [selectedTier, setSelectedTier] = useState("basic");
  const [expiryDays, setExpiryDays] = useState("30");
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const [membershipsRes, profilesRes] = await Promise.all([
      supabase.from("premium_memberships").select("*").order("created_at", { ascending: false }),
      supabase.from("profiles").select("user_id, full_name, username"),
    ]);

    if (membershipsRes.data) {
      setMemberships(membershipsRes.data);
    }
    if (profilesRes.data) {
      setProfiles(profilesRes.data);
    }
    setLoading(false);
  };

  const addPremium = async () => {
    if (!selectedUser || !user) return;

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + parseInt(expiryDays));

    const { error } = await supabase.from("premium_memberships").insert({
      user_id: selectedUser,
      tier: selectedTier,
      is_active: true,
      started_at: new Date().toISOString(),
      expires_at: expiresAt.toISOString(),
      enabled_by: user.id,
    });

    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Success", description: "Premium membership added" });
      setDialogOpen(false);
      fetchData();
    }
  };

  const revokePremium = async (membershipId: string) => {
    const { error } = await supabase
      .from("premium_memberships")
      .update({ is_active: false })
      .eq("id", membershipId);

    if (error) {
      toast({ title: "Error", description: "Failed to revoke membership", variant: "destructive" });
    } else {
      toast({ title: "Success", description: "Membership revoked" });
      fetchData();
    }
  };

  const getProfileName = (userId: string) => {
    const profile = profiles.find((p) => p.user_id === userId);
    return profile?.full_name || profile?.username || userId.slice(0, 8);
  };

  const tierColors: Record<string, string> = {
    basic: "bg-blue-500/10 text-blue-500",
    pro: "bg-purple-500/10 text-purple-500",
    enterprise: "bg-yellow-500/10 text-yellow-500",
  };

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Premium Memberships</h1>
            <p className="text-muted-foreground">Manage user premium subscriptions</p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Premium
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Premium Membership</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Select User</Label>
                  <Select value={selectedUser} onValueChange={setSelectedUser}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a user" />
                    </SelectTrigger>
                    <SelectContent>
                      {profiles.map((profile) => (
                        <SelectItem key={profile.user_id} value={profile.user_id}>
                          {profile.full_name || profile.username || profile.user_id.slice(0, 8)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Tier</Label>
                  <Select value={selectedTier} onValueChange={setSelectedTier}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic</SelectItem>
                      <SelectItem value="pro">Pro</SelectItem>
                      <SelectItem value="enterprise">Enterprise</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Duration (days)</Label>
                  <Input
                    type="number"
                    value={expiryDays}
                    onChange={(e) => setExpiryDays(e.target.value)}
                    min="1"
                  />
                </div>
                <Button onClick={addPremium} className="w-full">
                  Add Membership
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search memberships..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : memberships.length === 0 ? (
              <div className="text-center py-12">
                <Crown className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No premium memberships yet</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Tier</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Started</TableHead>
                    <TableHead>Expires</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {memberships.map((membership) => (
                    <TableRow key={membership.id}>
                      <TableCell className="font-medium">
                        {getProfileName(membership.user_id)}
                      </TableCell>
                      <TableCell>
                        <Badge className={tierColors[membership.tier] || ""}>
                          <Crown className="h-3 w-3 mr-1" />
                          {membership.tier}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {membership.is_active ? (
                          <Badge className="bg-green-500/10 text-green-500">Active</Badge>
                        ) : (
                          <Badge variant="secondary">Inactive</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {membership.started_at
                          ? new Date(membership.started_at).toLocaleDateString()
                          : "N/A"}
                      </TableCell>
                      <TableCell>
                        {membership.expires_at
                          ? new Date(membership.expires_at).toLocaleDateString()
                          : "Never"}
                      </TableCell>
                      <TableCell className="text-right">
                        {membership.is_active && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => revokePremium(membership.id)}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Revoke
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
