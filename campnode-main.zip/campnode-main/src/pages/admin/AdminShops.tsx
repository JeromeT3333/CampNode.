import { useState, useEffect } from "react";
import { AdminLayout } from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Search,
  MoreVertical,
  Store,
  CheckCircle,
  XCircle,
  Trash2,
  Eye,
  ExternalLink,
  Package,
  Star,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useNavigate, Link } from "react-router-dom";

interface Shop {
  id: string;
  name: string;
  category: string;
  location: string | null;
  is_verified: boolean | null;
  rating: number | null;
  created_at: string;
  owner_id: string;
  profile_image: string | null;
  profiles?: { full_name: string | null; username: string | null } | null;
  product_count?: number;
}

export default function AdminShops() {
  const [shops, setShops] = useState<Shop[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    fetchShops();
  }, []);

  const fetchShops = async () => {
    const { data, error } = await supabase
      .from("shops")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error && data) {
      // Fetch profiles and product counts
      const ownerIds = [...new Set(data.map(s => s.owner_id))];
      const shopIds = data.map(s => s.id);
      
      const [profilesRes, productsRes] = await Promise.all([
        supabase.from("profiles").select("user_id, full_name, username").in("user_id", ownerIds),
        supabase.from("products").select("shop_id").in("shop_id", shopIds),
      ]);
      
      const profileMap = new Map((profilesRes.data || []).map(p => [p.user_id, p]));
      
      // Count products per shop
      const productCounts: Record<string, number> = {};
      (productsRes.data || []).forEach(p => {
        if (p.shop_id) {
          productCounts[p.shop_id] = (productCounts[p.shop_id] || 0) + 1;
        }
      });
      
      const shopsWithData = data.map(shop => ({
        ...shop,
        profiles: profileMap.get(shop.owner_id) || null,
        product_count: productCounts[shop.id] || 0,
      }));
      
      setShops(shopsWithData);
    }
    setLoading(false);
  };

  const toggleVerification = async (shopId: string, currentStatus: boolean | null) => {
    const { error } = await supabase
      .from("shops")
      .update({ is_verified: !currentStatus })
      .eq("id", shopId);

    if (error) {
      toast({ title: "Error", description: "Failed to update verification", variant: "destructive" });
    } else {
      toast({ title: "Success", description: `Shop ${!currentStatus ? "verified" : "unverified"}` });
      fetchShops();
    }
  };

  const deleteShop = async (shopId: string) => {
    const { error } = await supabase.from("shops").delete().eq("id", shopId);

    if (error) {
      toast({ title: "Error", description: "Failed to delete shop", variant: "destructive" });
    } else {
      toast({ title: "Success", description: "Shop deleted" });
      fetchShops();
    }
  };

  // Get unique categories
  const categories = [...new Set(shops.map(s => s.category))];

  const filteredShops = shops.filter((shop) => {
    const matchesSearch = 
      shop.name.toLowerCase().includes(search.toLowerCase()) ||
      shop.category.toLowerCase().includes(search.toLowerCase()) ||
      shop.profiles?.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      shop.profiles?.username?.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === "all" || shop.category === categoryFilter;
    const matchesStatus = 
      statusFilter === "all" ||
      (statusFilter === "verified" && shop.is_verified) ||
      (statusFilter === "unverified" && !shop.is_verified);
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Shops Management</h1>
            <p className="text-muted-foreground">Manage all shops on the platform</p>
          </div>
          <div className="flex gap-3">
            <Badge variant="outline" className="px-3 py-1">
              <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
              {shops.filter(s => s.is_verified).length} Verified
            </Badge>
            <Badge variant="secondary" className="text-lg px-4 py-2">
              <Store className="h-4 w-4 mr-2" />
              {shops.length} Shops
            </Badge>
          </div>
        </div>

        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search shops or owners..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="verified">Verified</SelectItem>
                  <SelectItem value="unverified">Unverified</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Shop</TableHead>
                    <TableHead>Owner</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Products</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredShops.map((shop) => (
                    <TableRow key={shop.id}>
                      <TableCell>
                        <Link
                          to={`/shop/${shop.id}`}
                          className="flex items-center gap-2 hover:text-primary transition-colors"
                        >
                          <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center overflow-hidden">
                            {shop.profile_image ? (
                              <img src={shop.profile_image} alt={shop.name} className="h-full w-full object-cover" />
                            ) : (
                              <Store className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium hover:underline">{shop.name}</p>
                            <p className="text-xs text-muted-foreground">{shop.location || "No location"}</p>
                          </div>
                          <ExternalLink className="h-3 w-3 text-muted-foreground" />
                        </Link>
                      </TableCell>
                      <TableCell>
                        <p className="text-sm">
                          {shop.profiles?.full_name || shop.profiles?.username || "Unknown"}
                        </p>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{shop.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Package className="h-3 w-3 text-muted-foreground" />
                          <span>{shop.product_count}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {shop.rating ? (
                          <div className="flex items-center gap-1">
                            <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                            <span>{shop.rating.toFixed(1)}</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-sm">N/A</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {shop.is_verified ? (
                          <Badge className="bg-green-500/10 text-green-500 border-green-500/20">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Verified
                          </Badge>
                        ) : (
                          <Badge variant="secondary">Unverified</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {new Date(shop.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => navigate(`/shop/${shop.id}`)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Shop
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => toggleVerification(shop.id, shop.is_verified)}>
                              {shop.is_verified ? (
                                <>
                                  <XCircle className="h-4 w-4 mr-2" />
                                  Remove Verification
                                </>
                              ) : (
                                <>
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Verify Shop
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => deleteShop(shop.id)}
                              className="text-destructive focus:text-destructive"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete Shop
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
            
            {!loading && filteredShops.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                No shops found matching your filters
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
