 import { useState, useEffect } from "react";
 import { AdminLayout } from "./AdminLayout";
 import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
 import { Button } from "@/components/ui/button";
 import { Input } from "@/components/ui/input";
 import { Textarea } from "@/components/ui/textarea";
 import { Label } from "@/components/ui/label";
 import { Badge } from "@/components/ui/badge";
 import { supabase } from "@/integrations/supabase/client";
 import { toast } from "sonner";
 import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
 } from "@/components/ui/select";
 import {
   Table,
   TableBody,
   TableCell,
   TableHead,
   TableHeader,
   TableRow,
 } from "@/components/ui/table";
 import { MessageSquare, Send, Clock, CheckCircle, Loader2 } from "lucide-react";
 
 interface BroadcastMessage {
   id: string;
   title: string;
   message: string;
   target_audience: string | null;
   is_sent: boolean | null;
   sent_at: string | null;
   created_at: string | null;
 }
 
 const AdminBroadcast = () => {
   const [title, setTitle] = useState("");
   const [message, setMessage] = useState("");
   const [audience, setAudience] = useState("all");
   const [sending, setSending] = useState(false);
   const [messages, setMessages] = useState<BroadcastMessage[]>([]);
   const [loading, setLoading] = useState(true);
 
   useEffect(() => {
     fetchMessages();
   }, []);
 
   const fetchMessages = async () => {
     try {
       const { data, error } = await supabase
         .from("broadcast_messages")
         .select("*")
         .order("created_at", { ascending: false });
 
       if (error) throw error;
       setMessages(data || []);
     } catch (error) {
       console.error("Error fetching messages:", error);
     } finally {
       setLoading(false);
     }
   };
 
   const handleSendBroadcast = async () => {
     if (!title.trim() || !message.trim()) {
       toast.error("Please fill in all fields");
       return;
     }
 
     setSending(true);
     try {
       const { data: { user } } = await supabase.auth.getUser();
       if (!user) throw new Error("Not authenticated");
 
       // Get all users to send notifications
       const { data: profiles, error: profilesError } = await supabase
         .from("profiles")
         .select("user_id");
 
       if (profilesError) throw profilesError;
 
       // Create notifications for all users
       const notifications = (profiles || []).map((p) => ({
         user_id: p.user_id,
         type: "broadcast",
         title: title,
         message: message,
         data: { audience, from: "CampNode Admin" },
       }));
 
       const { error: notifError } = await supabase
         .from("notifications")
         .insert(notifications);
 
       if (notifError) throw notifError;
 
       // Save broadcast record
       const { error: broadcastError } = await supabase
         .from("broadcast_messages")
         .insert({
           sent_by: user.id,
           title,
           message,
           target_audience: audience,
           is_sent: true,
           sent_at: new Date().toISOString(),
         });
 
       if (broadcastError) throw broadcastError;
 
       toast.success(`Broadcast sent to ${profiles?.length || 0} users`);
       setTitle("");
       setMessage("");
       fetchMessages();
     } catch (error) {
       console.error("Error sending broadcast:", error);
       toast.error("Failed to send broadcast");
     } finally {
       setSending(false);
     }
   };
 
   const formatDate = (dateString: string | null) => {
     if (!dateString) return "—";
     return new Date(dateString).toLocaleDateString("en-NG", {
       year: "numeric",
       month: "short",
       day: "numeric",
       hour: "2-digit",
       minute: "2-digit",
     });
   };
 
   return (
     <AdminLayout>
       <div className="p-6 space-y-6">
         <div>
           <h1 className="text-2xl font-bold">Broadcast Messages</h1>
           <p className="text-muted-foreground">Send notifications to all users</p>
         </div>
 
         {/* Send New Broadcast */}
         <Card>
           <CardHeader>
             <CardTitle className="flex items-center gap-2">
               <MessageSquare className="h-5 w-5" />
               New Broadcast
             </CardTitle>
             <CardDescription>
               Send a message to all CampNode users
             </CardDescription>
           </CardHeader>
           <CardContent className="space-y-4">
             <div className="space-y-2">
               <Label>Title</Label>
               <Input
                 value={title}
                 onChange={(e) => setTitle(e.target.value)}
                 placeholder="e.g., New Feature Announcement"
               />
             </div>
             <div className="space-y-2">
               <Label>Message</Label>
               <Textarea
                 value={message}
                 onChange={(e) => setMessage(e.target.value)}
                 placeholder="Enter your message here..."
                 rows={4}
               />
             </div>
             <div className="space-y-2">
               <Label>Target Audience</Label>
               <Select value={audience} onValueChange={setAudience}>
                 <SelectTrigger>
                   <SelectValue />
                 </SelectTrigger>
                 <SelectContent>
                   <SelectItem value="all">All Users</SelectItem>
                   <SelectItem value="sellers">Sellers Only</SelectItem>
                   <SelectItem value="buyers">Buyers Only</SelectItem>
                   <SelectItem value="premium">Premium Members</SelectItem>
                 </SelectContent>
               </Select>
             </div>
             <Button onClick={handleSendBroadcast} disabled={sending} className="gap-2">
               {sending ? (
                 <Loader2 className="h-4 w-4 animate-spin" />
               ) : (
                 <Send className="h-4 w-4" />
               )}
               Send Broadcast
             </Button>
           </CardContent>
         </Card>
 
         {/* Previous Broadcasts */}
         <Card>
           <CardHeader>
             <CardTitle>Broadcast History</CardTitle>
           </CardHeader>
           <CardContent>
             {loading ? (
               <div className="flex items-center justify-center py-8">
                 <Loader2 className="h-8 w-8 animate-spin" />
               </div>
             ) : messages.length === 0 ? (
               <div className="text-center py-8 text-muted-foreground">
                 No broadcasts sent yet
               </div>
             ) : (
               <Table>
                 <TableHeader>
                   <TableRow>
                     <TableHead>Title</TableHead>
                     <TableHead>Audience</TableHead>
                     <TableHead>Status</TableHead>
                     <TableHead>Sent At</TableHead>
                   </TableRow>
                 </TableHeader>
                 <TableBody>
                   {messages.map((msg) => (
                     <TableRow key={msg.id}>
                       <TableCell>
                         <p className="font-medium">{msg.title}</p>
                         <p className="text-sm text-muted-foreground truncate max-w-[300px]">
                           {msg.message}
                         </p>
                       </TableCell>
                       <TableCell>
                         <Badge variant="outline">{msg.target_audience || "all"}</Badge>
                       </TableCell>
                       <TableCell>
                         {msg.is_sent ? (
                          <Badge className="gap-1 bg-primary/10 text-primary">
                             <CheckCircle className="h-3 w-3" />
                             Sent
                           </Badge>
                         ) : (
                           <Badge variant="outline" className="gap-1">
                             <Clock className="h-3 w-3" />
                             Pending
                           </Badge>
                         )}
                       </TableCell>
                       <TableCell>{formatDate(msg.sent_at)}</TableCell>
                     </TableRow>
                   ))}
                 </TableBody>
               </Table>
             )}
           </CardContent>
         </Card>
       </div>
     </AdminLayout>
   );
 };
 
 export default AdminBroadcast;