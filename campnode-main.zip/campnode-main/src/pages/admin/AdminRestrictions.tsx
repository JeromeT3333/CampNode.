import { useState, useEffect } from "react";
import { AdminLayout } from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Search, Lock, Plus, Unlock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface Restriction {
  id: string;
  user_id: string;
  restriction_type: string;
  reason: string | null;
  notes: string | null;
  is_active: boolean | null;
  restricted_at: string | null;
  expires_at: string | null;
}

interface Profile {
  user_id: string;
  full_name: string | null;
  username: string | null;
}

export default function AdminRestrictions() {
  const [restrictions, setRestrictions] = useState<Restriction[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState("");
  const [restrictionType, setRestrictionType] = useState("suspended");
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState("");
  const [expiryDays, setExpiryDays] = useState("");
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const [restrictionsRes, profilesRes] = await Promise.all([
      supabase.from("account_restrictions").select("*").order("created_at", { ascending: false }),
      supabase.from("profiles").select("user_id, full_name, username"),
    ]);

    if (restrictionsRes.data) {
      setRestrictions(restrictionsRes.data);
    }
    if (profilesRes.data) {
      setProfiles(profilesRes.data);
    }
    setLoading(false);
  };

  const addRestriction = async () => {
    if (!selectedUser || !user) return;

    const expiresAt = expiryDays
      ? new Date(Date.now() + parseInt(expiryDays) * 24 * 60 * 60 * 1000).toISOString()
      : null;

    const { error } = await supabase.from("account_restrictions").insert({
      user_id: selectedUser,
      restricted_by: user.id,
      restriction_type: restrictionType,
      reason,
      notes,
      expires_at: expiresAt,
      is_active: true,
    });

    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Success", description: "Account restricted" });
      setDialogOpen(false);
      setReason("");
      setNotes("");
      setExpiryDays("");
      fetchData();
    }
  };

  const liftRestriction = async (restrictionId: string) => {
    const { error } = await supabase
      .from("account_restrictions")
      .update({ is_active: false })
      .eq("id", restrictionId);

    if (error) {
      toast({ title: "Error", description: "Failed to lift restriction", variant: "destructive" });
    } else {
      toast({ title: "Success", description: "Restriction lifted" });
      fetchData();
    }
  };

  const getProfileName = (userId: string) => {
    const profile = profiles.find((p) => p.user_id === userId);
    return profile?.full_name || profile?.username || userId.slice(0, 8);
  };

  const typeColors: Record<string, string> = {
    suspended: "bg-red-500/10 text-red-500",
    warning: "bg-yellow-500/10 text-yellow-500",
    review: "bg-blue-500/10 text-blue-500",
    limited: "bg-orange-500/10 text-orange-500",
  };

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Account Restrictions</h1>
            <p className="text-muted-foreground">Manage suspended and restricted accounts</p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive">
                <Plus className="h-4 w-4 mr-2" />
                Add Restriction
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Restrict Account</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Select User</Label>
                  <Select value={selectedUser} onValueChange={setSelectedUser}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a user" />
                    </SelectTrigger>
                    <SelectContent>
                      {profiles.map((profile) => (
                        <SelectItem key={profile.user_id} value={profile.user_id}>
                          {profile.full_name || profile.username || profile.user_id.slice(0, 8)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Restriction Type</Label>
                  <Select value={restrictionType} onValueChange={setRestrictionType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="suspended">Suspended</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="review">Under Review</SelectItem>
                      <SelectItem value="limited">Limited Access</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Reason</Label>
                  <Input
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="Reason for restriction"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Internal Notes (optional)</Label>
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Additional notes..."
                  />
                </div>
                <div className="space-y-2">
                  <Label>Duration in days (leave empty for permanent)</Label>
                  <Input
                    type="number"
                    value={expiryDays}
                    onChange={(e) => setExpiryDays(e.target.value)}
                    placeholder="e.g., 7"
                    min="1"
                  />
                </div>
                <Button onClick={addRestriction} variant="destructive" className="w-full">
                  Apply Restriction
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search restrictions..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : restrictions.length === 0 ? (
              <div className="text-center py-12">
                <Lock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No account restrictions</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Expires</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {restrictions.map((restriction) => (
                    <TableRow key={restriction.id}>
                      <TableCell className="font-medium">
                        {getProfileName(restriction.user_id)}
                      </TableCell>
                      <TableCell>
                        <Badge className={typeColors[restriction.restriction_type] || ""}>
                          {restriction.restriction_type}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate">
                        {restriction.reason || "N/A"}
                      </TableCell>
                      <TableCell>
                        {restriction.is_active ? (
                          <Badge className="bg-red-500/10 text-red-500">Active</Badge>
                        ) : (
                          <Badge variant="secondary">Lifted</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {restriction.expires_at
                          ? new Date(restriction.expires_at).toLocaleDateString()
                          : "Permanent"}
                      </TableCell>
                      <TableCell className="text-right">
                        {restriction.is_active && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => liftRestriction(restriction.id)}
                          >
                            <Unlock className="h-4 w-4 mr-1" />
                            Lift
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
