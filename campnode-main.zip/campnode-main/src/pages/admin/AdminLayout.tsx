 import { ReactNode } from "react";
 import { useNavigate, Link, useLocation } from "react-router-dom";
 import { useAdminCheck } from "@/hooks/useAdminCheck";
 import { Button } from "@/components/ui/button";
 import { Skeleton } from "@/components/ui/skeleton";
 import { cn } from "@/lib/utils";
 import {
   Shield,
   Users,
   Store,
   Package,
   ShoppingCart,
   DollarSign,
   Settings,
   BarChart3,
   MessageSquare,
   Bell,
   Crown,
   Lock,
   ArrowLeft,
   Menu,
 } from "lucide-react";
 import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
 import { useState } from "react";
 
 interface AdminLayoutProps {
   children: ReactNode;
 }
 
 const navItems = [
   { icon: BarChart3, label: "Overview", path: "/admin" },
   { icon: Users, label: "Users", path: "/admin/users" },
   { icon: Store, label: "Shops", path: "/admin/shops" },
   { icon: Package, label: "Products", path: "/admin/products" },
   { icon: ShoppingCart, label: "Orders", path: "/admin/orders" },
   { icon: DollarSign, label: "Transactions", path: "/admin/transactions" },
   { icon: Crown, label: "Premium", path: "/admin/premium" },
   { icon: Lock, label: "Restrictions", path: "/admin/restrictions" },
   { icon: MessageSquare, label: "Broadcast", path: "/admin/broadcast" },
   { icon: Settings, label: "Settings", path: "/admin/settings" },
 ];
 
 export const AdminLayout = ({ children }: AdminLayoutProps) => {
   const navigate = useNavigate();
   const location = useLocation();
   const { isAdmin, loading } = useAdminCheck();
   const [sidebarOpen, setSidebarOpen] = useState(false);
 
   if (loading) {
     return (
       <div className="min-h-screen bg-background flex items-center justify-center">
         <Skeleton className="h-8 w-48" />
       </div>
     );
   }
 
   if (!isAdmin) {
     navigate("/");
     return null;
   }
 
   const SidebarContent = () => (
     <div className="h-full flex flex-col">
       {/* Header */}
       <div className="p-4 border-b border-border">
         <div className="flex items-center gap-2">
           <Shield className="h-8 w-8 text-primary" />
           <div>
             <h1 className="font-bold text-lg">Admin Panel</h1>
             <p className="text-xs text-muted-foreground">CampNode Control</p>
           </div>
         </div>
       </div>
 
       {/* Navigation */}
       <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
         {navItems.map((item) => {
           const isActive = location.pathname === item.path;
           return (
             <Link
               key={item.path}
               to={item.path}
               onClick={() => setSidebarOpen(false)}
               className={cn(
                 "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                 isActive
                   ? "bg-primary text-primary-foreground"
                   : "text-muted-foreground hover:text-foreground hover:bg-muted"
               )}
             >
               <item.icon className="h-5 w-5" />
               {item.label}
             </Link>
           );
         })}
       </nav>
 
       {/* Footer */}
       <div className="p-3 border-t border-border">
         <Button
           variant="ghost"
           className="w-full justify-start gap-2"
           onClick={() => navigate("/")}
         >
           <ArrowLeft className="h-4 w-4" />
           Back to App
         </Button>
       </div>
     </div>
   );
 
   return (
     <div className="min-h-screen bg-background flex">
       {/* Desktop Sidebar */}
       <aside className="hidden lg:block w-64 border-r border-border bg-card">
         <SidebarContent />
       </aside>
 
       {/* Mobile Header & Content */}
       <div className="flex-1 flex flex-col">
         {/* Mobile Header */}
         <header className="lg:hidden sticky top-0 z-40 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
           <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
             <SheetTrigger asChild>
               <Button variant="ghost" size="icon">
                 <Menu className="h-5 w-5" />
               </Button>
             </SheetTrigger>
             <SheetContent side="left" className="w-64 p-0">
               <SidebarContent />
             </SheetContent>
           </Sheet>
           <div className="flex items-center gap-2">
             <Shield className="h-6 w-6 text-primary" />
             <span className="font-bold">Admin</span>
           </div>
         </header>
 
         {/* Main Content */}
         <main className="flex-1 overflow-auto">
           {children}
         </main>
       </div>
     </div>
   );
 };