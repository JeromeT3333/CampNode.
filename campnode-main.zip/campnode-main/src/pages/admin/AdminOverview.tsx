import { useState, useEffect } from "react";
import { AdminLayout } from "./AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { formatNaira } from "@/lib/formatCurrency";
import { StatCard } from "@/components/admin/StatCard";
import { QuickActions } from "@/components/admin/QuickActions";
import { RecentActivity } from "@/components/admin/RecentActivity";
import { PlatformHealthCard } from "@/components/admin/PlatformHealthCard";
import { RevenueChart } from "@/components/admin/RevenueChart";
import {
  Users,
  Store,
  Package,
  ShoppingCart,
  DollarSign,
  Crown,
  AlertTriangle,
  Wallet,
} from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

interface Stats {
  totalUsers: number;
  totalShops: number;
  verifiedShops: number;
  totalProducts: number;
  activeProducts: number;
  totalOrders: number;
  completedOrders: number;
  pendingOrders: number;
  totalRevenue: number;
  platformFees: number;
  premiumUsers: number;
  restrictedAccounts: number;
  platformBalance: number;
}

const COLORS = [
  "hsl(var(--primary))",
  "hsl(142.1 76.2% 36.3%)",
  "hsl(47.9 95.8% 53.1%)",
  "hsl(0 84.2% 60.2%)",
  "hsl(262.1 83.3% 57.8%)",
];

const AdminOverview = () => {
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    totalShops: 0,
    verifiedShops: 0,
    totalProducts: 0,
    activeProducts: 0,
    totalOrders: 0,
    completedOrders: 0,
    pendingOrders: 0,
    totalRevenue: 0,
    platformFees: 0,
    premiumUsers: 0,
    restrictedAccounts: 0,
    platformBalance: 0,
  });
  const [loading, setLoading] = useState(true);
  const [ordersByStatus, setOrdersByStatus] = useState<{ name: string; value: number }[]>([]);
  const [productsByCategory, setProductsByCategory] = useState<{ name: string; value: number }[]>([]);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const [
        usersRes,
        shopsRes,
        productsRes,
        ordersRes,
        transactionsRes,
        premiumRes,
        restrictionsRes,
        platformWalletRes,
      ] = await Promise.all([
        supabase.from("profiles").select("*", { count: "exact", head: true }),
        supabase.from("shops").select("is_verified"),
        supabase.from("products").select("is_active, category"),
        supabase.from("orders").select("status, total_amount, created_at"),
        supabase.from("transactions").select("gross_amount, platform_fee, payment_status"),
        supabase.from("premium_memberships").select("*", { count: "exact", head: true }).eq("is_active", true),
        supabase.from("account_restrictions").select("*", { count: "exact", head: true }).eq("is_active", true),
        supabase.from("platform_wallet").select("balance").limit(1).maybeSingle(),
      ]);

      const shops = shopsRes.data || [];
      const products = productsRes.data || [];
      const orders = ordersRes.data || [];
      const transactions = transactionsRes.data || [];

      // Calculate stats
      const completedOrders = orders.filter((o) => o.status === "completed");
      const pendingOrders = orders.filter((o) => o.status === "pending");
      const completedTransactions = transactions.filter((t) => t.payment_status === "completed");
      const totalRevenue = completedTransactions.reduce((sum, t) => sum + Number(t.gross_amount), 0);
      const platformFees = completedTransactions.reduce((sum, t) => sum + Number(t.platform_fee), 0);

      // Orders by status for pie chart
      const statusCounts: Record<string, number> = {};
      orders.forEach((o) => {
        const status = o.status.charAt(0).toUpperCase() + o.status.slice(1);
        statusCounts[status] = (statusCounts[status] || 0) + 1;
      });
      const statusData = Object.entries(statusCounts).map(([name, value]) => ({ name, value }));

      // Products by category
      const categoryCounts: Record<string, number> = {};
      products.forEach((p) => {
        categoryCounts[p.category] = (categoryCounts[p.category] || 0) + 1;
      });
      const categoryData = Object.entries(categoryCounts)
        .map(([name, value]) => ({ name, value }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 5);

      setStats({
        totalUsers: usersRes.count || 0,
        totalShops: shops.length,
        verifiedShops: shops.filter((s) => s.is_verified).length,
        totalProducts: products.length,
        activeProducts: products.filter((p) => p.is_active).length,
        totalOrders: orders.length,
        completedOrders: completedOrders.length,
        pendingOrders: pendingOrders.length,
        totalRevenue,
        platformFees,
        premiumUsers: premiumRes.count || 0,
        restrictedAccounts: restrictionsRes.count || 0,
        platformBalance: platformWalletRes.data?.balance || 0,
      });
      setOrdersByStatus(statusData);
      setProductsByCategory(categoryData);
    } catch (error) {
      console.error("Error fetching stats:", error);
      toast.error("Failed to load statistics");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
          <Skeleton className="h-96" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Dashboard Overview</h1>
          <p className="text-muted-foreground">Platform statistics and analytics</p>
        </div>

        {/* Quick Actions */}
        <QuickActions onRefreshData={fetchStats} />

        {/* Stats Grid - All Clickable */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            title="Total Users"
            value={stats.totalUsers}
            subtitle={`${stats.premiumUsers} premium members`}
            icon={Users}
            href="/admin/users"
            colorClass="bg-blue-500/10 text-blue-500"
          />
          <StatCard
            title="Shops"
            value={stats.totalShops}
            subtitle={`${stats.verifiedShops} verified`}
            icon={Store}
            href="/admin/shops"
            colorClass="bg-purple-500/10 text-purple-500"
          />
          <StatCard
            title="Products"
            value={stats.totalProducts}
            subtitle={`${stats.activeProducts} active`}
            icon={Package}
            href="/admin/products"
            colorClass="bg-orange-500/10 text-orange-500"
          />
          <StatCard
            title="Orders"
            value={stats.totalOrders}
            subtitle={`${stats.pendingOrders} pending`}
            icon={ShoppingCart}
            href="/admin/orders"
            colorClass="bg-cyan-500/10 text-cyan-500"
          />
          <StatCard
            title="Total Revenue"
            value={formatNaira(stats.totalRevenue)}
            subtitle={`${stats.completedOrders} completed orders`}
            icon={DollarSign}
            href="/admin/transactions"
            colorClass="bg-green-500/10 text-green-500"
          />
          <StatCard
            title="Platform Fees"
            value={formatNaira(stats.platformFees)}
            subtitle="Your earnings"
            icon={Wallet}
            href="/admin/transactions"
            colorClass="bg-emerald-500/10 text-emerald-500"
          />
          <StatCard
            title="Premium Members"
            value={stats.premiumUsers}
            icon={Crown}
            href="/admin/premium"
            colorClass="bg-yellow-500/10 text-yellow-500"
          />
          <StatCard
            title="Restrictions"
            value={stats.restrictedAccounts}
            subtitle="Active restrictions"
            icon={AlertTriangle}
            href="/admin/restrictions"
            colorClass="bg-red-500/10 text-red-500"
          />
        </div>

        {/* Revenue Chart */}
        <RevenueChart />

        {/* Charts Row */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Orders by Status Pie Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Orders by Status</CardTitle>
            </CardHeader>
            <CardContent>
              {ordersByStatus.length === 0 ? (
                <div className="h-[250px] flex items-center justify-center text-muted-foreground">
                  No order data available
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={ordersByStatus}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {ordersByStatus.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Products by Category Pie Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Top Product Categories</CardTitle>
            </CardHeader>
            <CardContent>
              {productsByCategory.length === 0 ? (
                <div className="h-[250px] flex items-center justify-center text-muted-foreground">
                  No product data available
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={productsByCategory}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {productsByCategory.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Activity and Health Row */}
        <div className="grid lg:grid-cols-2 gap-6">
          <RecentActivity />
          <PlatformHealthCard />
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminOverview;
