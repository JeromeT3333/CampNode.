import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ImageUpload } from "@/components/ImageUpload";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, User, Phone, MapPin, GraduationCap, AtSign } from "lucide-react";
import { cn } from "@/lib/utils";
import { z } from "zod";

const profileSchema = z.object({
  full_name: z.string().min(2, "Name must be at least 2 characters").max(100),
  username: z.string().min(3, "Username must be at least 3 characters").max(30).regex(/^[a-zA-Z0-9_]+$/, "Username can only contain letters, numbers, and underscores"),
  phone: z.string().min(10, "Enter a valid phone number").max(15),
  campus_location: z.string().min(2, "Enter your campus/department").max(100),
  department: z.string().min(2, "Enter your department").max(100),
  role: z.enum(["buyer", "seller", "both"]),
});

type ProfileFormData = z.infer<typeof profileSchema>;

const CompleteProfile = () => {
  const [formData, setFormData] = useState<ProfileFormData>({
    full_name: "",
    username: "",
    phone: "",
    campus_location: "",
    department: "",
    role: "buyer",
  });
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof ProfileFormData, string>>>({});
  const [isLoading, setIsLoading] = useState(true);

  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
      return;
    }

    const fetchProfile = async () => {
      if (!user) return;
      
      const { data: profile } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (profile) {
        // Check if profile is already complete
        if (profile.profile_complete) {
          navigate("/dashboard");
          return;
        }
        
        setFormData({
          full_name: profile.full_name || "",
          username: profile.username || "",
          phone: profile.phone || "",
          campus_location: profile.campus_location || "",
          department: profile.department || "",
          role: (profile.role as "buyer" | "seller" | "both") || "buyer",
        });
        setAvatarUrl(profile.avatar_url);
      }
      
      setIsLoading(false);
    };

    fetchProfile();
  }, [user, loading, navigate]);

  const handleChange = (field: keyof ProfileFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const result = profileSchema.safeParse(formData);
    if (!result.success) {
      const fieldErrors: Partial<Record<keyof ProfileFormData, string>> = {};
      result.error.errors.forEach((err) => {
        const field = err.path[0] as keyof ProfileFormData;
        fieldErrors[field] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }

    if (!user) return;

    setIsSubmitting(true);

    try {
      // Check if username is already taken
      const { data: existingUser } = await supabase
        .from("profiles")
        .select("id")
        .eq("username", formData.username)
        .neq("user_id", user.id)
        .single();

      if (existingUser) {
        setErrors({ username: "This username is already taken" });
        setIsSubmitting(false);
        return;
      }

      const { error } = await supabase
        .from("profiles")
        .update({
          ...formData,
          avatar_url: avatarUrl,
          profile_complete: true,
          updated_at: new Date().toISOString(),
        })
        .eq("user_id", user.id);

      if (error) throw error;

      toast({
        title: "Profile complete!",
        description: "Welcome to CampNode. Start exploring the marketplace!",
      });

      navigate("/dashboard");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading || isLoading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-8">
        <div className="max-w-lg mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-foreground mb-2">Complete Your Profile</h1>
            <p className="text-muted-foreground">
              Tell us a bit about yourself to get started
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Avatar */}
            <div className="flex flex-col items-center gap-4">
              <ImageUpload
                value={avatarUrl || undefined}
                onChange={setAvatarUrl}
                bucket="avatars"
                folder={user?.id}
                aspectRatio="square"
                placeholder="Upload photo"
                className="w-28 h-28 rounded-full"
              />
              <p className="text-sm text-muted-foreground">Profile Picture</p>
            </div>

            {/* Full Name */}
            <div className="space-y-2">
              <Label htmlFor="full_name">Full Name *</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="full_name"
                  value={formData.full_name}
                  onChange={(e) => handleChange("full_name", e.target.value)}
                  placeholder="John Doe"
                  className={cn("pl-10", errors.full_name && "border-destructive")}
                  disabled={isSubmitting}
                />
              </div>
              {errors.full_name && (
                <p className="text-sm text-destructive">{errors.full_name}</p>
              )}
            </div>

            {/* Username */}
            <div className="space-y-2">
              <Label htmlFor="username">Username *</Label>
              <div className="relative">
                <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="username"
                  value={formData.username}
                  onChange={(e) => handleChange("username", e.target.value.toLowerCase())}
                  placeholder="johndoe"
                  className={cn("pl-10", errors.username && "border-destructive")}
                  disabled={isSubmitting}
                />
              </div>
              {errors.username && (
                <p className="text-sm text-destructive">{errors.username}</p>
              )}
            </div>

            {/* Phone */}
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleChange("phone", e.target.value)}
                  placeholder="+234 800 000 0000"
                  className={cn("pl-10", errors.phone && "border-destructive")}
                  disabled={isSubmitting}
                />
              </div>
              {errors.phone && (
                <p className="text-sm text-destructive">{errors.phone}</p>
              )}
            </div>

            {/* Campus Location */}
            <div className="space-y-2">
              <Label htmlFor="campus_location">Campus *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="campus_location"
                  value={formData.campus_location}
                  onChange={(e) => handleChange("campus_location", e.target.value)}
                  placeholder="e.g., University of Lagos"
                  className={cn("pl-10", errors.campus_location && "border-destructive")}
                  disabled={isSubmitting}
                />
              </div>
              {errors.campus_location && (
                <p className="text-sm text-destructive">{errors.campus_location}</p>
              )}
            </div>

            {/* Department */}
            <div className="space-y-2">
              <Label htmlFor="department">Department *</Label>
              <div className="relative">
                <GraduationCap className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="department"
                  value={formData.department}
                  onChange={(e) => handleChange("department", e.target.value)}
                  placeholder="e.g., Computer Science"
                  className={cn("pl-10", errors.department && "border-destructive")}
                  disabled={isSubmitting}
                />
              </div>
              {errors.department && (
                <p className="text-sm text-destructive">{errors.department}</p>
              )}
            </div>

            {/* Role Selection */}
            <div className="space-y-2">
              <Label>I want to *</Label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: "buyer", label: "Buy", desc: "Shop on CampNode" },
                  { id: "seller", label: "Sell", desc: "List products" },
                  { id: "both", label: "Both", desc: "Buy & Sell" },
                ].map((option) => (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => handleChange("role", option.id)}
                    className={cn(
                      "p-3 rounded-xl border text-center transition-all",
                      formData.role === option.id
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    )}
                  >
                    <span className="block font-medium text-foreground">{option.label}</span>
                    <span className="text-xs text-muted-foreground">{option.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full gradient-primary"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Saving...
                </>
              ) : (
                "Complete Profile"
              )}
            </Button>
          </form>
        </div>
      </div>
    </MainLayout>
  );
};

export default CompleteProfile;
