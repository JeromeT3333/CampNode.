import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { MultiImageUpload } from "@/components/MultiImageUpload";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { 
  Package, 
  MapPin, 
  Loader2,
  ArrowRight,
  Eye,
  EyeOff,
  HelpCircle,
  X,
  Plus,
  Wand2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { z } from "zod";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { GifMaker } from "@/components/product/GifMaker";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

const productSchema = z.object({
  name: z.string().min(3, "Name must be at least 3 characters").max(100),
  description: z.string().min(10, "Description must be at least 10 characters").max(1000),
  price: z.number().min(100, "Price must be at least ₦100"),
  category: z.string().min(1, "Please select a category"),
  location: z.string().min(3, "Location must be at least 3 characters").max(200),
});

const categories = [
  { id: "food", name: "Food & Drinks" },
  { id: "electronics", name: "Electronics" },
  { id: "fashion", name: "Fashion" },
  { id: "books", name: "Books & Notes" },
  { id: "services", name: "Services" },
  { id: "photography", name: "Photography" },
  { id: "printing", name: "Printing" },
  { id: "provisions", name: "Provisions" },
];

const commonColors = [
  "Black", "White", "Red", "Blue", "Green", "Yellow", "Pink", "Purple", 
  "Orange", "Brown", "Gray", "Navy", "Beige", "Gold", "Silver"
];

const commonSizes = [
  "XS", "S", "M", "L", "XL", "XXL", "XXXL",
  "36", "37", "38", "39", "40", "41", "42", "43", "44", "45"
];

const AddProduct = () => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [isService, setIsService] = useState(false);
  const [hasDelivery, setHasDelivery] = useState(false);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [shopId, setShopId] = useState<string | null>(null);
  const [shops, setShops] = useState<{ id: string; name: string }[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [availableColors, setAvailableColors] = useState<string[]>([]);
  const [availableSizes, setAvailableSizes] = useState<string[]>([]);
  const [customColor, setCustomColor] = useState("");
  const [customSize, setCustomSize] = useState("");
  const [gifUrl, setGifUrl] = useState<string | null>(null);
  const [gifInterval, setGifInterval] = useState(3000);
  const [showGifMaker, setShowGifMaker] = useState(false);

  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();

  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
      return;
    }

    const fetchShops = async () => {
      if (!user) return;
      
      const { data } = await supabase
        .from("shops")
        .select("id, name")
        .eq("owner_id", user.id);

      if (data) {
        setShops(data);
        
        const shopParam = searchParams.get("shop");
        if (shopParam && data.some(s => s.id === shopParam)) {
          setShopId(shopParam);
        } else if (data.length === 1) {
          setShopId(data[0].id);
        }
      }
    };

    fetchShops();
  }, [user, loading, navigate, searchParams]);

  const addColor = (color: string) => {
    if (color && !availableColors.includes(color)) {
      setAvailableColors([...availableColors, color]);
    }
    setCustomColor("");
  };

  const removeColor = (color: string) => {
    setAvailableColors(availableColors.filter(c => c !== color));
  };

  const addSize = (size: string) => {
    if (size && !availableSizes.includes(size)) {
      setAvailableSizes([...availableSizes, size]);
    }
    setCustomSize("");
  };

  const removeSize = (size: string) => {
    setAvailableSizes(availableSizes.filter(s => s !== size));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    const priceNum = parseFloat(price);
    
    const result = productSchema.safeParse({
      name: name.trim(),
      description: description.trim(),
      price: priceNum,
      category,
      location: location.trim(),
    });

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        fieldErrors[err.path[0] as string] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }

    if (images.length === 0) {
      setErrors({ images: "Please upload at least one image" });
      return;
    }

    if (!user) return;

    setIsSubmitting(true);

    try {
      const { error } = await supabase.from("products").insert({
        seller_id: user.id,
        shop_id: shopId,
        name: name.trim(),
        description: description.trim(),
        price: priceNum,
        category,
        location: location.trim(),
        image: images[0],
        additional_images: images.slice(1),
        is_service: isService,
        has_delivery: hasDelivery,
        is_anonymous: isAnonymous,
        is_active: true,
        available_colors: availableColors,
        available_sizes: availableSizes,
        gif_url: gifUrl,
        gif_interval: gifInterval,
      });

      if (error) throw error;

      toast({
        title: "Product listed!",
        description: "Your product is now live on CampNode.",
      });

      navigate("/seller-dashboard");
    } catch (error: unknown) {
      console.error("Product creation error:", error);
      toast({
        title: "Error",
        description: "Failed to create product. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4">
              <Package className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-2">List a Product</h1>
            <p className="text-muted-foreground">
              Add a new product or service to sell on CampNode
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Images */}
            <div className="space-y-2">
              <Label>Product Images *</Label>
              <MultiImageUpload
                value={images}
                onChange={setImages}
                bucket="products"
                folder={user?.id}
                maxImages={5}
              />
              {errors.images && (
                <p className="text-sm text-destructive">{errors.images}</p>
              )}
            </div>

            {/* GIF Maker */}
            <Collapsible open={showGifMaker} onOpenChange={setShowGifMaker}>
              <CollapsibleTrigger asChild>
                <Button type="button" variant="outline" className="w-full gap-2">
                  <Wand2 className="h-4 w-4" />
                  {gifUrl ? "GIF Added ✓" : "Add Product GIF (Optional)"}
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="mt-4">
                {gifUrl ? (
                  <div className="space-y-4">
                    <div className="relative aspect-square max-w-[200px] mx-auto rounded-lg overflow-hidden bg-muted">
                      <img src={gifUrl} alt="Product GIF" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setGifUrl(null)}
                        className="absolute top-2 right-2 p-1 rounded-full bg-background/80"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="space-y-2">
                      <Label>GIF/Photo Switch Interval: {gifInterval / 1000}s</Label>
                      <input
                        type="range"
                        min={1000}
                        max={10000}
                        step={500}
                        value={gifInterval}
                        onChange={(e) => setGifInterval(parseInt(e.target.value))}
                        className="w-full"
                      />
                    </div>
                  </div>
                ) : (
                  <GifMaker
                    onGifCreated={(url) => {
                      setGifUrl(url);
                      setShowGifMaker(false);
                    }}
                    userId={user?.id}
                  />
                )}
              </CollapsibleContent>
            </Collapsible>

            {/* Name */}
            <div className="space-y-2">
              <Label htmlFor="name">Product Name *</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Wireless Earbuds, Haircut Service"
                className={errors.name ? "border-destructive" : ""}
                disabled={isSubmitting}
                maxLength={100}
              />
              {errors.name && (
                <p className="text-sm text-destructive">{errors.name}</p>
              )}
            </div>

            {/* Category */}
            <div className="space-y-2">
              <Label>Category *</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className={errors.category ? "border-destructive" : ""}>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.category && (
                <p className="text-sm text-destructive">{errors.category}</p>
              )}
            </div>

            {/* Shop (optional) */}
            {shops.length > 0 && (
              <div className="space-y-2">
                <Label>Link to Shop (optional)</Label>
                <Select value={shopId || "none"} onValueChange={(val) => setShopId(val === "none" ? null : val)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a shop" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No shop</SelectItem>
                    {shops.map((shop) => (
                      <SelectItem key={shop.id} value={shop.id}>
                        {shop.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your product, condition, features..."
                rows={4}
                className={errors.description ? "border-destructive" : ""}
                disabled={isSubmitting}
                maxLength={1000}
              />
              <div className="flex justify-between">
                {errors.description ? (
                  <p className="text-sm text-destructive">{errors.description}</p>
                ) : (
                  <span />
                )}
                <span className="text-xs text-muted-foreground">{description.length}/1000</span>
              </div>
            </div>

            {/* Price */}
            <div className="space-y-2">
              <Label htmlFor="price">Price (₦) *</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">₦</span>
                <Input
                  id="price"
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="0"
                  className={cn("pl-8", errors.price && "border-destructive")}
                  disabled={isSubmitting}
                  min={100}
                />
              </div>
              {errors.price && (
                <p className="text-sm text-destructive">{errors.price}</p>
              )}
            </div>

            {/* Available Colors */}
            <div className="space-y-2">
              <Label>Available Colors (optional)</Label>
              <div className="flex flex-wrap gap-2 mb-2">
                {availableColors.map(color => (
                  <Badge key={color} variant="secondary" className="gap-1">
                    {color}
                    <X 
                      className="h-3 w-3 cursor-pointer hover:text-destructive" 
                      onClick={() => removeColor(color)}
                    />
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Select onValueChange={addColor}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select a color" />
                  </SelectTrigger>
                  <SelectContent>
                    {commonColors.filter(c => !availableColors.includes(c)).map((color) => (
                      <SelectItem key={color} value={color}>
                        {color}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex gap-1">
                  <Input
                    placeholder="Custom"
                    value={customColor}
                    onChange={(e) => setCustomColor(e.target.value)}
                    className="w-24"
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="icon"
                    onClick={() => addColor(customColor)}
                    disabled={!customColor}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Available Sizes */}
            <div className="space-y-2">
              <Label>Available Sizes (optional)</Label>
              <div className="flex flex-wrap gap-2 mb-2">
                {availableSizes.map(size => (
                  <Badge key={size} variant="secondary" className="gap-1">
                    {size}
                    <X 
                      className="h-3 w-3 cursor-pointer hover:text-destructive" 
                      onClick={() => removeSize(size)}
                    />
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Select onValueChange={addSize}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select a size" />
                  </SelectTrigger>
                  <SelectContent>
                    {commonSizes.filter(s => !availableSizes.includes(s)).map((size) => (
                      <SelectItem key={size} value={size}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex gap-1">
                  <Input
                    placeholder="Custom"
                    value={customSize}
                    onChange={(e) => setCustomSize(e.target.value)}
                    className="w-24"
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="icon"
                    onClick={() => addSize(customSize)}
                    disabled={!customSize}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Location */}
            <div className="space-y-2">
              <Label htmlFor="location">Location *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g., Engineering Block, Main Gate"
                  className={cn("pl-10", errors.location && "border-destructive")}
                  disabled={isSubmitting}
                  maxLength={200}
                />
              </div>
              {errors.location && (
                <p className="text-sm text-destructive">{errors.location}</p>
              )}
            </div>

            {/* Toggles */}
            <div className="space-y-4 p-4 bg-muted/50 rounded-xl">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="isService">This is a service</Label>
                  <p className="text-xs text-muted-foreground">Not a physical product</p>
                </div>
                <Switch
                  id="isService"
                  checked={isService}
                  onCheckedChange={setIsService}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="hasDelivery">Delivery available</Label>
                  <p className="text-xs text-muted-foreground">Can deliver to buyer</p>
                </div>
                <Switch
                  id="hasDelivery"
                  checked={hasDelivery}
                  onCheckedChange={setHasDelivery}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isAnonymous ? (
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <Eye className="h-4 w-4 text-muted-foreground" />
                  )}
                  <div>
                    <div className="flex items-center gap-1">
                      <Label htmlFor="isAnonymous">Sell anonymously</Label>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <HelpCircle className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="text-sm">
                            <strong>Anonymous selling</strong> hides your name and profile from buyers. 
                            Only verified users can contact you. Your identity is revealed only after 
                            a successful transaction for safety purposes.
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {isAnonymous 
                        ? "Your name will be hidden" 
                        : "Your name will be visible"}
                    </p>
                  </div>
                </div>
                <Switch
                  id="isAnonymous"
                  checked={isAnonymous}
                  onCheckedChange={setIsAnonymous}
                />
              </div>
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full gap-2 gradient-primary"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Listing Product...
                </>
              ) : (
                <>
                  List Product
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </form>
        </div>
      </div>
    </MainLayout>
  );
};

export default AddProduct;
