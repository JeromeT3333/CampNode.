import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useFlutterwavePayment } from "@/hooks/useFlutterwavePayment";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Loader2,
  ShoppingBag,
  MapPin,
  CreditCard,
  Building2,
  Smartphone,
  Truck,
  Shield,
  ChevronLeft,
  Package,
  Info,
  Lock,
  Clock
} from "lucide-react";

interface Product {
  id: string;
  name: string;
  price: number;
  image: string | null;
  seller_id: string;
  has_delivery: boolean | null;
  is_service: boolean | null;
}

interface UserProfile {
  full_name: string | null;
  phone: string | null;
  campus_location: string | null;
}

const PLATFORM_FEE_PERCENT = 5;
const MIN_ESCROW_PRICE = 500;

const Checkout = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, loading: authLoading } = useAuth();
  const { initializePayment, loading: paymentLoading } = useFlutterwavePayment();

  const [product, setProduct] = useState<Product | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Form state
  const productId = searchParams.get("product");
  const initialQty = parseInt(searchParams.get("qty") || "1", 10);
  const initialColor = searchParams.get("color") || "";
  const initialSize = searchParams.get("size") || "";

  const [quantity] = useState(initialQty);
  const [deliveryLocation, setDeliveryLocation] = useState("");
  const [notes, setNotes] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"card" | "transfer" | "ussd">("card");

  useEffect(() => {
    if (!authLoading && !user) {
      const redirectUrl = encodeURIComponent(`/checkout?product=${productId}&qty=${quantity}`);
      navigate(`/auth?redirect=${redirectUrl}`);
    }
  }, [user, authLoading, navigate, productId, quantity]);

  useEffect(() => {
    if (!productId) {
      toast.error("No product selected");
      navigate("/products");
    }
  }, [productId, navigate]);

  useEffect(() => {
    const fetchData = async () => {
      if (!productId || !user) return;

      try {
        const { data: productData, error: productError } = await supabase
          .from("products")
          .select("id, name, price, image, seller_id, has_delivery, is_service")
          .eq("id", productId)
          .single();

        if (productError) throw productError;
        
        if (productData.seller_id === user.id) {
          toast.error("You cannot buy your own product");
          navigate(-1);
          return;
        }

        setProduct(productData);

        const { data: profileData } = await supabase
          .from("profiles")
          .select("full_name, phone, campus_location")
          .eq("user_id", user.id)
          .single();

        if (profileData) {
          setProfile(profileData);
          setDeliveryLocation(profileData.campus_location || "");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        toast.error("Failed to load checkout");
        navigate(-1);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [productId, user, navigate]);

  // Price calculations
  const productPrice = product ? product.price * quantity : 0;
  const serviceFee = productPrice * (PLATFORM_FEE_PERCENT / 100);
  const totalAmount = productPrice + serviceFee; // Buyer pays P × 1.05
  const useEscrow = productPrice >= MIN_ESCROW_PRICE;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(price);
  };

  const handlePay = async () => {
    if (!product || !user || !profile?.full_name) {
      toast.error("Please complete your profile first");
      navigate("/complete-profile");
      return;
    }

    const { data: { user: authUser } } = await supabase.auth.getUser();
    if (!authUser?.email) {
      toast.error("Email not found. Please sign in again.");
      return;
    }

    await initializePayment({
      product_id: product.id,
      quantity,
      buyer_email: authUser.email,
      buyer_name: profile.full_name,
      buyer_phone: profile.phone || undefined,
      redirect_url: `${window.location.origin}/payment-complete`,
      onSuccess: () => {
        navigate("/payment-complete?status=successful");
      },
      onClose: () => {
        toast.info("Payment cancelled");
      }
    });
  };

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user || !product) return null;

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="rounded-full"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Checkout</h1>
              <p className="text-sm text-muted-foreground">Complete your purchase</p>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Forms */}
            <div className="lg:col-span-2 space-y-6">
              {/* Order Items */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <ShoppingBag className="h-5 w-5" />
                    Order Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4">
                    <div className="w-20 h-20 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                      {product.image ? (
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="h-8 w-8 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground">{product.name}</h3>
                      <div className="flex flex-wrap gap-2 mt-1 mb-2">
                        {initialColor && (
                          <Badge variant="outline" className="text-xs">Color: {initialColor}</Badge>
                        )}
                        {initialSize && (
                          <Badge variant="outline" className="text-xs">Size: {initialSize}</Badge>
                        )}
                        <Badge variant="outline" className="text-xs">Qty: {quantity}</Badge>
                      </div>
                      <p className="font-semibold text-primary">{formatPrice(product.price)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Delivery Location */}
              {product.has_delivery && !product.is_service && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Truck className="h-5 w-5" />
                      Delivery Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="location">Delivery Location</Label>
                      <div className="relative mt-1.5">
                        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="location"
                          value={deliveryLocation}
                          onChange={(e) => setDeliveryLocation(e.target.value)}
                          placeholder="Enter your delivery address"
                          className="pl-10"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="notes">Additional Notes (optional)</Label>
                      <Textarea
                        id="notes"
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Any special instructions for delivery..."
                        className="mt-1.5"
                        rows={3}
                      />
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Payment Method */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Payment Method
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={paymentMethod}
                    onValueChange={(v) => setPaymentMethod(v as "card" | "transfer" | "ussd")}
                    className="space-y-3"
                  >
                    <label
                      htmlFor="card"
                      className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                        paymentMethod === "card"
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <RadioGroupItem value="card" id="card" />
                      <CreditCard className="h-5 w-5 text-muted-foreground" />
                      <div className="flex-1">
                        <p className="font-medium">Card Payment</p>
                        <p className="text-sm text-muted-foreground">Pay with debit/credit card</p>
                      </div>
                      <div className="flex gap-1">
                        <div className="w-8 h-5 rounded bg-secondary text-secondary-foreground text-[8px] font-bold flex items-center justify-center">VISA</div>
                        <div className="w-8 h-5 rounded bg-destructive text-destructive-foreground text-[8px] font-bold flex items-center justify-center">MC</div>
                      </div>
                    </label>

                    <label
                      htmlFor="transfer"
                      className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                        paymentMethod === "transfer"
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <RadioGroupItem value="transfer" id="transfer" />
                      <Building2 className="h-5 w-5 text-muted-foreground" />
                      <div className="flex-1">
                        <p className="font-medium">Bank Transfer</p>
                        <p className="text-sm text-muted-foreground">Pay via bank transfer</p>
                      </div>
                    </label>

                    <label
                      htmlFor="ussd"
                      className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                        paymentMethod === "ussd"
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <RadioGroupItem value="ussd" id="ussd" />
                      <Smartphone className="h-5 w-5 text-muted-foreground" />
                      <div className="flex-1">
                        <p className="font-medium">USSD</p>
                        <p className="text-sm text-muted-foreground">Pay with USSD code</p>
                      </div>
                    </label>
                  </RadioGroup>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Order Total */}
            <div className="lg:col-span-1">
              <div className="sticky top-6 space-y-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Payment Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Subtotal ({quantity} item{quantity > 1 ? "s" : ""})</span>
                        <span>{formatPrice(productPrice)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Service Fee (5%)</span>
                        <span>{formatPrice(serviceFee)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Delivery</span>
                        <span className="text-primary">Free</span>
                      </div>
                    </div>

                    <Separator />

                    <div className="flex justify-between">
                      <span className="font-semibold text-foreground">Total</span>
                      <span className="text-xl font-bold text-primary">{formatPrice(totalAmount)}</span>
                    </div>

                    <Button
                      className="w-full gap-2"
                      size="lg"
                      onClick={handlePay}
                      disabled={paymentLoading}
                    >
                      {paymentLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Lock className="h-4 w-4" />
                      )}
                      Pay {formatPrice(totalAmount)}
                    </Button>

                    {/* Escrow Note */}
                    {useEscrow ? (
                      <div className="flex items-start gap-2 p-3 rounded-lg bg-primary/10 border border-primary/20">
                        <Shield className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <div className="text-xs text-foreground">
                          <p className="font-medium mb-0.5">Protected by Escrow</p>
                          <p className="text-muted-foreground">Your payment is held safely until you confirm delivery.</p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start gap-2 p-3 rounded-lg bg-muted">
                        <Clock className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                        <div className="text-xs text-muted-foreground">
                          <p className="font-medium text-foreground mb-0.5">Instant Settlement</p>
                          <p>Orders under {formatPrice(MIN_ESCROW_PRICE)} are settled instantly without escrow protection.</p>
                        </div>
                      </div>
                    )}

                    {/* Info Note */}
                    <div className="flex items-start gap-2 text-xs text-muted-foreground">
                      <Info className="h-4 w-4 flex-shrink-0" />
                      <p>By completing this purchase, you agree to our terms and conditions.</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Checkout;
