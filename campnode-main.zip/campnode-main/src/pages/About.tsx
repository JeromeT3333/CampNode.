import { MainLayout } from "@/components/layout/MainLayout";
import { 
  Users, 
  Store, 
  ShieldCheck, 
  MapPin, 
  CreditCard, 
  MessageCircle,
  ArrowRight,
  CheckCircle2
} from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import logo from "@/assets/logo.png";
import connectImage from "@/assets/connect.png";
import marketImage from "@/assets/market.png";

const features = [
  {
    icon: Users,
    title: "Campus Community",
    description: "Connect with students, lecturers, and local businesses within your campus ecosystem.",
    color: "bg-primary/10 text-primary",
  },
  {
    icon: Store,
    title: "Create Your Shop",
    description: "Build your own shop page with products, services, branding, and manage multiple admins.",
    color: "bg-secondary/10 text-secondary",
  },
  {
    icon: ShieldCheck,
    title: "Secure Transactions",
    description: "Escrow payment system ensures your money is safe until you receive your order.",
    color: "bg-campus-green/10 text-campus-green",
  },
  {
    icon: MapPin,
    title: "Campus Navigation",
    description: "Find sellers and shops easily with integrated campus maps and location pins.",
    color: "bg-accent/10 text-accent",
  },
  {
    icon: CreditCard,
    title: "Easy Payments",
    description: "Pay seamlessly with bank transfers, cards, and mobile money via Flutterwave.",
    color: "bg-campus-blue/10 text-campus-blue",
  },
  {
    icon: MessageCircle,
    title: "In-App Messaging",
    description: "Chat with buyers and sellers directly within the platform. No external contacts needed.",
    color: "bg-campus-purple/10 text-campus-purple",
  },
];

const howItWorks = [
  {
    step: "01",
    title: "Sign Up",
    description: "Create your account with Google, GitHub, or email in seconds.",
  },
  {
    step: "02",
    title: "Browse or List",
    description: "Explore products/services or start selling by creating listings.",
  },
  {
    step: "03",
    title: "Secure Payment",
    description: "Pay through CampNode. Funds are held until order completion.",
  },
  {
    step: "04",
    title: "Meet & Exchange",
    description: "Use campus maps to meet at convenient locations for pickup.",
  },
];

const About = () => {
  return (
    <MainLayout>
      <div className="min-h-screen">
        {/* Hero Section */}
        <section className="relative px-4 py-12 md:py-20 overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute top-20 right-20 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
            <div className="absolute bottom-20 left-20 w-72 h-72 bg-secondary/10 rounded-full blur-3xl" />
          </div>

          <div className="relative max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                  <img src={logo} alt="CampNode" className="h-5 w-5" />
                  <span>About CampNode</span>
                </div>

                <h1 className="text-3xl md:text-5xl font-bold text-foreground mb-6 leading-tight">
                  The Campus Marketplace
                  <span className="block text-gradient-primary">Built for Students</span>
                </h1>

                <p className="text-lg text-muted-foreground mb-8">
                  CampNode is a digital hub that brings together the entire campus community. 
                  Whether you're a student selling textbooks, a restaurant serving fresh meals, 
                  or a photography studio capturing memories — CampNode connects you all.
                </p>

                <div className="flex flex-wrap gap-4">
                  <Link to="/auth">
                    <Button size="lg" className="gap-2 gradient-primary shadow-lg">
                      Get Started
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link to="/shops">
                    <Button size="lg" variant="outline">
                      Explore Shops
                    </Button>
                  </Link>
                </div>
              </div>

              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-3xl blur-2xl" />
                <img 
                  src={connectImage} 
                  alt="Campus Connection" 
                  className="relative w-full max-w-md mx-auto animate-float"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="px-4 py-16 bg-muted/30">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-2xl md:text-4xl font-bold text-foreground mb-4">
                Everything You Need
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                From buying textbooks to booking haircuts, CampNode has all the features 
                to make campus life easier.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => (
                <div 
                  key={feature.title}
                  className="bg-card rounded-xl p-6 border border-border hover:shadow-card-hover transition-all duration-300 animate-fade-in"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className={`w-12 h-12 rounded-xl ${feature.color} flex items-center justify-center mb-4`}>
                    <feature.icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-card-foreground mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="px-4 py-16">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-2xl md:text-4xl font-bold text-foreground mb-4">
                  How It Works
                </h2>
                <p className="text-muted-foreground mb-8">
                  Getting started with CampNode is simple. Follow these steps to start 
                  buying or selling within your campus community.
                </p>

                <div className="space-y-6">
                  {howItWorks.map((item, index) => (
                    <div 
                      key={item.step}
                      className="flex gap-4 items-start animate-fade-in"
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      <div className="flex-shrink-0 w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                        {item.step}
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">
                          {item.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-secondary/20 to-accent/20 rounded-3xl blur-2xl" />
                <img 
                  src={marketImage} 
                  alt="Campus Marketplace" 
                  className="relative w-full max-w-md mx-auto"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Who Uses Section */}
        <section className="px-4 py-16 bg-muted/30">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-2xl md:text-4xl font-bold text-foreground mb-4">
                Who Uses CampNode?
              </h2>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-card rounded-xl p-6 border border-border text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">👨‍🎓</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Students</h3>
                <p className="text-muted-foreground text-sm">
                  Sell textbooks, notes, electronics, and more. Buy what you need from fellow students.
                </p>
              </div>

              <div className="bg-card rounded-xl p-6 border border-border text-center">
                <div className="w-16 h-16 rounded-full bg-secondary/10 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🏪</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Campus Businesses</h3>
                <p className="text-muted-foreground text-sm">
                  Restaurants, salons, printing services, and more can create shops and reach students.
                </p>
              </div>

              <div className="bg-card rounded-xl p-6 border border-border text-center">
                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">👩‍🏫</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Lecturers & Staff</h3>
                <p className="text-muted-foreground text-sm">
                  Access campus services, buy from local vendors, and support the campus economy.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="gradient-hero rounded-2xl p-8 md:p-12 text-center">
              <h2 className="text-2xl md:text-3xl font-bold text-primary-foreground mb-8">
                Growing Every Day
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                <div>
                  <p className="text-3xl md:text-4xl font-bold text-white">500+</p>
                  <p className="text-primary-foreground/80 text-sm">Active Users</p>
                </div>
                <div>
                  <p className="text-3xl md:text-4xl font-bold text-white">50+</p>
                  <p className="text-primary-foreground/80 text-sm">Shops</p>
                </div>
                <div>
                  <p className="text-3xl md:text-4xl font-bold text-white">1000+</p>
                  <p className="text-primary-foreground/80 text-sm">Products</p>
                </div>
                <div>
                  <p className="text-3xl md:text-4xl font-bold text-white">₦2M+</p>
                  <p className="text-primary-foreground/80 text-sm">Transactions</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="px-4 py-12 border-t border-border">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Ready to Join?
            </h2>
            <p className="text-muted-foreground mb-6">
              Create your account now and start exploring the campus marketplace.
            </p>
            <Link to="/auth">
              <Button size="lg" className="gap-2 gradient-primary shadow-lg">
                Sign Up Free
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </MainLayout>
  );
};

export default About;
