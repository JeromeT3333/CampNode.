import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Sparkles, TrendingUp, Store } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { SearchBar } from "@/components/SearchBar";
import { CategoryFilter } from "@/components/CategoryFilter";
import { ProductCard } from "@/components/ProductCard";
import { ShopCard } from "@/components/ShopCard";
import { categories } from "@/data/mockData";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import logo from "@/assets/logo.png";

interface Product {
  id: string;
  name: string;
  price: number;
  image: string | null;
  description: string | null;
  category: string;
  is_sponsored: boolean | null;
  shop_id: string | null;
  location: string | null;
  is_service: boolean | null;
  has_delivery: boolean | null;
  additional_images: string[] | null;
  shops?: { name: string } | null;
}

interface Shop {
  id: string;
  name: string;
  description: string | null;
  cover_image: string | null;
  profile_image: string | null;
  category: string;
  location: string | null;
  rating: number | null;
  is_verified: boolean | null;
  opening_time: string | null;
  closing_time: string | null;
  is_open_24hrs: boolean | null;
}

const Index = () => {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [products, setProducts] = useState<Product[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  const [productCounts, setProductCounts] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch products
        const { data: productsData, error: productsError } = await supabase
          .from("products")
          .select(`
            id, name, price, image, description, category, 
            is_sponsored, shop_id, location, is_service, has_delivery,
            additional_images,
            shops (name)
          `)
          .eq("is_active", true)
          .order("created_at", { ascending: false })
          .limit(12);

        if (productsError) throw productsError;
        setProducts(productsData || []);

        // Fetch shops
        const { data: shopsData, error: shopsError } = await supabase
          .from("shops")
          .select("id, name, description, cover_image, profile_image, category, location, rating, is_verified, opening_time, closing_time, is_open_24hrs")
          .order("rating", { ascending: false })
          .limit(4);

        if (shopsError) throw shopsError;
        setShops(shopsData || []);

        // Get product counts for shops
        if (shopsData && shopsData.length > 0) {
          const shopIds = shopsData.map(s => s.id);
          const { data: countData } = await supabase
            .from("products")
            .select("shop_id")
            .in("shop_id", shopIds)
            .eq("is_active", true);

          const counts: Record<string, number> = {};
          countData?.forEach(p => {
            if (p.shop_id) {
              counts[p.shop_id] = (counts[p.shop_id] || 0) + 1;
            }
          });
          setProductCounts(counts);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const filteredProducts = selectedCategory === "all" 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  const sponsoredProducts = products.filter(p => p.is_sponsored);


  // Map products to ProductCard format
  const mapProduct = (product: Product) => ({
    id: product.id,
    name: product.name,
    price: product.price,
    image: product.image || "/placeholder.svg",
    description: product.description || "",
    category: product.category,
    isSponsored: product.is_sponsored || false,
    shopId: product.shop_id || undefined,
    shopName: product.shops?.name,
    location: product.location || undefined,
    isService: product.is_service || false,
    hasDelivery: product.has_delivery || false,
    additionalImages: product.additional_images || [],
  });

  // Map shops to ShopCard format
  const mapShop = (shop: Shop) => ({
    id: shop.id,
    name: shop.name,
    description: shop.description || "",
    coverImage: shop.cover_image || "/placeholder.svg",
    profileImage: shop.profile_image || "/placeholder.svg",
    category: shop.category,
    location: shop.location || "Unknown",
    rating: shop.rating || 0,
    productCount: productCounts[shop.id] || 0,
    isVerified: shop.is_verified || false,
    openingTime: shop.opening_time,
    closingTime: shop.closing_time,
    isOpen24hrs: shop.is_open_24hrs,
  });

  return (
    <MainLayout>
      <div className="min-h-screen">
        {/* Hero Section */}
        <section className="relative px-4 py-8 md:py-12 bg-gradient-to-br from-primary/10 via-secondary/5 to-background overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-30">
            <div className="absolute top-10 right-10 w-64 h-64 bg-primary/20 rounded-full blur-3xl" />
            <div className="absolute bottom-10 left-10 w-48 h-48 bg-secondary/20 rounded-full blur-3xl" />
          </div>

          <div className="relative max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              <img src={logo} alt="CampNode" className="h-5 w-5" />
              <span>Your Campus Marketplace</span>
            </div>
            
            <h1 className="text-3xl md:text-5xl font-bold text-foreground mb-4 leading-tight">
              Buy, Sell & Connect
              <span className="block text-gradient-primary">Within Your Campus</span>
            </h1>
            
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
              Discover products, services, and shops from students, lecturers, and local businesses. 
              Everything you need, right on campus.
            </p>

            <SearchBar className="max-w-xl mx-auto" />

            <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse-soft" />
                {products.length}+ Products
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-secondary animate-pulse-soft" />
                {shops.length}+ Shops
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-accent animate-pulse-soft" />
                500+ Users
              </span>
            </div>
          </div>
        </section>

        {/* Sponsored Section */}
        {sponsoredProducts.length > 0 && (
          <section className="px-4 py-8">
            <div className="max-w-6xl mx-auto">
              <div className="flex items-center gap-2 mb-6">
                <Sparkles className="h-5 w-5 text-accent" />
                <h2 className="text-xl font-bold text-foreground">Sponsored</h2>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {sponsoredProducts.slice(0, 4).map((product, index) => (
                  <ProductCard key={product.id} product={mapProduct(product)} index={index} />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Featured Shops */}
        {shops.length > 0 && (
          <section className="px-4 py-8 bg-muted/30">
            <div className="max-w-6xl mx-auto">
              <div className="flex items-center gap-2 mb-6">
                <Store className="h-5 w-5 text-secondary" />
                <h2 className="text-xl font-bold text-foreground">Featured Shops</h2>
              </div>

              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[...Array(4)].map((_, i) => (
                    <Skeleton key={i} className="h-48 rounded-xl" />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {shops.map((shop, index) => (
                    <ShopCard key={shop.id} shop={mapShop(shop)} index={index} />
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        {/* Suggestions - Dynamic Masonry Grid */}
        <section className="px-4 py-8">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold text-foreground">Suggestions</h2>
            </div>

            <CategoryFilter 
              selected={selectedCategory} 
              onSelect={setSelectedCategory} 
            />

            {loading ? (
              <div className="mt-6 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {[...Array(8)].map((_, i) => (
                  <Skeleton key={i} className="h-64 rounded-xl" />
                ))}
              </div>
            ) : (
              <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {filteredProducts.map((product, index) => (
                  <ProductCard 
                    key={product.id}
                    product={mapProduct(product)} 
                    index={index} 
                  />
                ))}
              </div>
            )}

            {!loading && filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No products found in this category</p>
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="px-4 py-12 bg-gradient-to-r from-primary to-campus-green">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-primary-foreground mb-4">
              Start Selling Today
            </h2>
            <p className="text-primary-foreground/80 mb-6 max-w-2xl mx-auto">
              Join thousands of students and businesses selling on CampNode. 
              Create your shop or list products in minutes.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/create-shop">
                <button className="px-6 py-3 rounded-lg bg-secondary text-secondary-foreground font-medium shadow-lg hover:opacity-90 transition-opacity flex items-center gap-2">
                  <Store className="h-5 w-5" />
                  Create a Shop
                </button>
              </Link>
              <Link to="/add-product">
                <button className="px-6 py-3 rounded-lg bg-transparent border border-primary-foreground/30 text-primary-foreground font-medium hover:bg-primary-foreground/10 transition-colors">
                  List a Product
                </button>
              </Link>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="px-4 py-8 border-t border-border">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <img src={logo} alt="CampNode" className="h-8 w-8" />
                <span className="font-bold text-primary">CampNode</span>
              </div>
              <p className="text-sm text-muted-foreground">
                © 2024 CampNode. Your Campus, Your Marketplace.
              </p>
              <div className="flex items-center gap-6 text-sm text-muted-foreground">
                <Link to="/about" className="hover:text-primary transition-colors">About</Link>
                <Link to="/contact" className="hover:text-primary transition-colors">Contact</Link>
                <Link to="/privacy" className="hover:text-primary transition-colors">Privacy</Link>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </MainLayout>
  );
};

export default Index;
