import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { 
  Bell, 
  BellOff,
  CheckCheck,
  Package,
  MessageSquare,
  CreditCard,
  Store,
  Loader2,
  ShoppingBag
} from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  created_at: string;
  data: any;
}

const Notifications = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [markingAll, setMarkingAll] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchNotifications = async () => {
      if (!user) return;

      try {
        const { data, error } = await supabase
          .from("notifications")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false });

        if (error) throw error;
        setNotifications(data || []);
      } catch (error) {
        console.error("Error fetching notifications:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, [user]);

  const getNavigationPath = (notification: Notification): string => {
    const data = notification.data || {};
    
    switch (notification.type) {
      case "order":
        // Order chats go to /chat/:orderId (order-based chat)
        return data.order_id ? `/chat/${data.order_id}` : "/orders";
      case "message":
        // Message notifications use conversation_id to go directly to existing chat
        if (data.conversation_id) return `/conversation/${data.conversation_id}`;
        if (data.sender_id) return `/dm/${data.sender_id}`;
        return "/conversations";
      case "payout":
      case "payment":
        return "/seller-dashboard";
      case "shop":
        return data.shop_id ? `/shop/${data.shop_id}` : "/my-shops";
      case "product":
        return data.product_id ? `/product/${data.product_id}` : "/products";
      default:
        return "/notifications";
    }
  };

  const handleNotificationClick = async (notification: Notification) => {
    // Mark as read if not already
    if (!notification.is_read) {
      try {
        await supabase
          .from("notifications")
          .update({ is_read: true })
          .eq("id", notification.id);

        setNotifications(notifications.map(n => 
          n.id === notification.id ? { ...n, is_read: true } : n
        ));
      } catch (error) {
        console.error("Error marking notification as read:", error);
      }
    }

    // Navigate to relevant page
    const path = getNavigationPath(notification);
    navigate(path);
  };

  const markAllAsRead = async () => {
    setMarkingAll(true);
    try {
      const { error } = await supabase
        .from("notifications")
        .update({ is_read: true })
        .eq("user_id", user?.id)
        .eq("is_read", false);

      if (error) throw error;

      setNotifications(notifications.map(n => ({ ...n, is_read: true })));
      toast.success("All notifications marked as read");
    } catch (error) {
      toast.error("Failed to mark all as read");
    } finally {
      setMarkingAll(false);
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case "order":
        return <Package className="h-5 w-5" />;
      case "message":
        return <MessageSquare className="h-5 w-5" />;
      case "payment":
      case "payout":
        return <CreditCard className="h-5 w-5" />;
      case "shop":
        return <Store className="h-5 w-5" />;
      case "product":
        return <ShoppingBag className="h-5 w-5" />;
      default:
        return <Bell className="h-5 w-5" />;
    }
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case "order":
        return "text-blue-500 bg-blue-500/10";
      case "message":
        return "text-green-500 bg-green-500/10";
      case "payment":
      case "payout":
        return "text-yellow-500 bg-yellow-500/10";
      case "shop":
        return "text-purple-500 bg-purple-500/10";
      case "product":
        return "text-orange-500 bg-orange-500/10";
      default:
        return "text-primary bg-primary/10";
    }
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen px-4 py-6">
          <div className="max-w-2xl mx-auto space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-20 rounded-xl" />
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!user) return null;

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Bell className="h-6 w-6 text-primary" />
                <h1 className="text-2xl font-bold text-foreground">Notifications</h1>
                {unreadCount > 0 && (
                  <span className="px-2 py-0.5 text-xs font-medium bg-red-500 text-white rounded-full">
                    {unreadCount}
                  </span>
                )}
              </div>
              <p className="text-muted-foreground">
                Stay updated with your orders and messages
              </p>
            </div>
            {unreadCount > 0 && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={markAllAsRead}
                disabled={markingAll}
                className="gap-1"
              >
                {markingAll ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <CheckCheck className="h-4 w-4" />
                )}
                Mark all read
              </Button>
            )}
          </div>

          {/* Notifications */}
          {notifications.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <BellOff className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="font-semibold text-foreground mb-2">No notifications</h3>
                <p className="text-muted-foreground text-sm">
                  You're all caught up! Check back later.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {notifications.map((notification) => (
                <Card 
                  key={notification.id}
                  className={cn(
                    "cursor-pointer transition-all hover:bg-muted/50 hover:shadow-md",
                    !notification.is_read && "border-primary/50 bg-primary/5"
                  )}
                  onClick={() => handleNotificationClick(notification)}
                >
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
                        getIconColor(notification.type)
                      )}>
                        {getIcon(notification.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h3 className={cn(
                              "font-medium text-foreground",
                              !notification.is_read && "font-semibold"
                            )}>
                              {notification.title}
                            </h3>
                            <p className="text-sm text-muted-foreground line-clamp-2">
                              {notification.message}
                            </p>
                          </div>
                          {!notification.is_read && (
                            <div className="w-2.5 h-2.5 rounded-full bg-red-500 flex-shrink-0 mt-2" />
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default Notifications;