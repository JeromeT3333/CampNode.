import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Loader2,
  Store,
  Package,
  Plus,
  Trash2,
  Users,
  Settings,
  TrendingUp,
  ShoppingCart,
  UserPlus,
  Star,
  Share2,
  ExternalLink,
  Bell,
  MessageCircle
} from "lucide-react";

interface Shop {
  id: string;
  name: string;
  description: string | null;
  profile_image: string | null;
  cover_image: string | null;
  category: string;
  location: string | null;
  rating: number | null;
  is_verified: boolean | null;
  owner_id: string;
}

interface Product {
  id: string;
  name: string;
  price: number;
  image: string | null;
  is_active: boolean | null;
}

interface ShopAdmin {
  id: string;
  user_id: string;
  created_at: string;
  profile?: {
    full_name: string | null;
    avatar_url: string | null;
    username: string | null;
  };
}

interface Review {
  id: string;
  rating: number;
  comment: string | null;
  created_at: string;
}

const ShopDashboard = () => {
  const { shopId } = useParams<{ shopId: string }>();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [shop, setShop] = useState<Shop | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [admins, setAdmins] = useState<ShopAdmin[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [isOwner, setIsOwner] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const [newAdminEmail, setNewAdminEmail] = useState("");
  const [addingAdmin, setAddingAdmin] = useState(false);
  const [adminToRemove, setAdminToRemove] = useState<ShopAdmin | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchShopData = async () => {
      if (!shopId || !user) return;

      try {
        // Fetch shop
        const { data: shopData, error: shopError } = await supabase
          .from("shops")
          .select("*")
          .eq("id", shopId)
          .single();

        if (shopError) throw shopError;

        // Check if user is owner
        const userIsOwner = shopData.owner_id === user.id;
        setIsOwner(userIsOwner);

        // Check if user is admin
        const { data: adminCheck } = await supabase
          .from("shop_admins")
          .select("id")
          .eq("shop_id", shopId)
          .eq("user_id", user.id)
          .single();

        const userIsAdmin = !!adminCheck;
        setIsAdmin(userIsAdmin);

        // If neither owner nor admin, redirect
        if (!userIsOwner && !userIsAdmin) {
          toast.error("You don't have access to this shop dashboard");
          navigate("/dashboard");
          return;
        }

        setShop(shopData);

        // Fetch products
        const { data: productsData } = await supabase
          .from("products")
          .select("id, name, price, image, is_active")
          .eq("shop_id", shopId)
          .order("created_at", { ascending: false });

        setProducts(productsData || []);

        // Fetch admins with profiles (only for owner)
        if (userIsOwner) {
          const { data: adminsData } = await supabase
            .from("shop_admins")
            .select("id, user_id, created_at")
            .eq("shop_id", shopId);

          if (adminsData && adminsData.length > 0) {
            const userIds = adminsData.map((a) => a.user_id);
            const { data: profilesData } = await supabase
              .from("profiles")
              .select("user_id, full_name, avatar_url, username")
              .in("user_id", userIds);

            const profilesMap = new Map(
              profilesData?.map((p) => [p.user_id, p]) || []
            );

            const adminsWithProfiles = adminsData.map((admin) => ({
              ...admin,
              profile: profilesMap.get(admin.user_id) || undefined,
            }));

            setAdmins(adminsWithProfiles);
          }
        }

        // Fetch reviews
        const { data: reviewsData } = await supabase
          .from("reviews")
          .select("id, rating, comment, created_at")
          .eq("shop_id", shopId)
          .order("created_at", { ascending: false })
          .limit(10);

        setReviews(reviewsData || []);
      } catch (error) {
        console.error("Error fetching shop data:", error);
        toast.error("Failed to load shop data");
      } finally {
        setLoading(false);
      }
    };

    fetchShopData();
  }, [shopId, user, navigate]);

  const handleAddAdmin = async () => {
    if (!newAdminEmail.trim() || !shop) return;

    setAddingAdmin(true);
    try {
      // Find user by username or email-like pattern
      const { data: profiles, error: searchError } = await supabase
        .from("profiles")
        .select("user_id, full_name, username")
        .or(`username.eq.${newAdminEmail.trim()},full_name.ilike.%${newAdminEmail.trim()}%`)
        .limit(1);

      if (searchError) throw searchError;

      if (!profiles || profiles.length === 0) {
        toast.error("User not found. Please enter a valid username.");
        setAddingAdmin(false);
        return;
      }

      const targetUser = profiles[0];

      // Check if already admin
      const { data: existingAdmin } = await supabase
        .from("shop_admins")
        .select("id")
        .eq("shop_id", shop.id)
        .eq("user_id", targetUser.user_id)
        .single();

      if (existingAdmin) {
        toast.error("This user is already an admin");
        setAddingAdmin(false);
        return;
      }

      // Add admin
      const { error: insertError } = await supabase.from("shop_admins").insert({
        shop_id: shop.id,
        user_id: targetUser.user_id,
      });

      if (insertError) throw insertError;

      toast.success(`${targetUser.full_name || targetUser.username} added as admin`);
      setNewAdminEmail("");

      // Refresh admins list
      const { data: adminsData } = await supabase
        .from("shop_admins")
        .select("id, user_id, created_at")
        .eq("shop_id", shop.id);

      if (adminsData && adminsData.length > 0) {
        const userIds = adminsData.map((a) => a.user_id);
        const { data: profilesData } = await supabase
          .from("profiles")
          .select("user_id, full_name, avatar_url, username")
          .in("user_id", userIds);

        const profilesMap = new Map(
          profilesData?.map((p) => [p.user_id, p]) || []
        );

        const adminsWithProfiles = adminsData.map((admin) => ({
          ...admin,
          profile: profilesMap.get(admin.user_id) || undefined,
        }));

        setAdmins(adminsWithProfiles);
      }
    } catch (error) {
      console.error("Error adding admin:", error);
      toast.error("Failed to add admin");
    } finally {
      setAddingAdmin(false);
    }
  };

  const handleRemoveAdmin = async () => {
    if (!adminToRemove) return;

    try {
      const { error } = await supabase
        .from("shop_admins")
        .delete()
        .eq("id", adminToRemove.id);

      if (error) throw error;

      toast.success("Admin removed");
      setAdmins(admins.filter((a) => a.id !== adminToRemove.id));
    } catch (error) {
      console.error("Error removing admin:", error);
      toast.error("Failed to remove admin");
    } finally {
      setAdminToRemove(null);
    }
  };

  const handleShare = async () => {
    const shopUrl = `${window.location.origin}/shop/${shop?.id}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: shop?.name,
          text: shop?.description || `Check out ${shop?.name} on CampNode!`,
          url: shopUrl,
        });
      } catch (error) {
        // User cancelled or error
        navigator.clipboard.writeText(shopUrl);
        toast.success("Link copied to clipboard!");
      }
    } else {
      navigator.clipboard.writeText(shopUrl);
      toast.success("Link copied to clipboard!");
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!user || !shop) return null;

  const activeProducts = products.filter((p) => p.is_active);
  const avgRating = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : "N/A";

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={shop.profile_image || undefined} />
                <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                  {shop.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-bold text-foreground">{shop.name}</h1>
                  {shop.is_verified && (
                    <Badge className="bg-primary/10 text-primary">Verified</Badge>
                  )}
                </div>
                <p className="text-muted-foreground">Shop Dashboard</p>
              </div>
            </div>
            
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="h-4 w-4 mr-1" />
                Share
              </Button>
              <Link to={`/shop/${shop.id}`}>
                <Button variant="outline" size="sm">
                  <ExternalLink className="h-4 w-4 mr-1" />
                  View Shop
                </Button>
              </Link>
              <Link to="/conversations">
                <Button variant="outline" size="sm">
                  <MessageCircle className="h-4 w-4 mr-1" />
                  Messages
                </Button>
              </Link>
              <Link to="/notifications">
                <Button variant="outline" size="sm">
                  <Bell className="h-4 w-4 mr-1" />
                  Notifications
                </Button>
              </Link>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <Package className="h-5 w-5 text-primary" />
                  <span className="text-sm text-muted-foreground">Products</span>
                </div>
                <p className="text-2xl font-bold">{activeProducts.length}</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="h-5 w-5 text-yellow-500" />
                  <span className="text-sm text-muted-foreground">Rating</span>
                </div>
                <p className="text-2xl font-bold">{avgRating}</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  <span className="text-sm text-muted-foreground">Reviews</span>
                </div>
                <p className="text-2xl font-bold">{reviews.length}</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="h-5 w-5 text-blue-500" />
                  <span className="text-sm text-muted-foreground">Admins</span>
                </div>
                <p className="text-2xl font-bold">{admins.length + 1}</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Products */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Products</CardTitle>
                  <CardDescription>Manage your shop products</CardDescription>
                </div>
                <Link to={`/add-product?shop=${shop.id}`}>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-1" />
                    Add Product
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                {products.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    No products yet
                  </p>
                ) : (
                  <div className="space-y-3 max-h-80 overflow-y-auto">
                    {products.slice(0, 10).map((product) => (
                      <div
                        key={product.id}
                        className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50"
                      >
                        <div className="w-10 h-10 rounded bg-muted overflow-hidden">
                          {product.image ? (
                            <img
                              src={product.image}
                              alt={product.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Package className="h-4 w-4 text-muted-foreground" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{product.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {formatCurrency(product.price)}
                          </p>
                        </div>
                        <Badge variant={product.is_active ? "default" : "secondary"}>
                          {product.is_active ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Admins (Owner only) */}
            {isOwner && (
              <Card>
                <CardHeader>
                  <CardTitle>Shop Admins</CardTitle>
                  <CardDescription>
                    Add users who can manage this shop
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Add Admin Form */}
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <Label htmlFor="adminUsername" className="sr-only">
                        Username
                      </Label>
                      <Input
                        id="adminUsername"
                        placeholder="Enter username"
                        value={newAdminEmail}
                        onChange={(e) => setNewAdminEmail(e.target.value)}
                        disabled={addingAdmin}
                      />
                    </div>
                    <Button
                      onClick={handleAddAdmin}
                      disabled={addingAdmin || !newAdminEmail.trim()}
                    >
                      {addingAdmin ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <UserPlus className="h-4 w-4" />
                      )}
                    </Button>
                  </div>

                  {/* Owner */}
                  <div className="flex items-center gap-3 p-2 rounded-lg bg-primary/5">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        You
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium text-sm">You (Owner)</p>
                    </div>
                    <Badge>Owner</Badge>
                  </div>

                  {/* Admins List */}
                  {admins.map((admin) => (
                    <div
                      key={admin.id}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50"
                    >
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={admin.profile?.avatar_url || undefined} />
                        <AvatarFallback>
                          {admin.profile?.full_name?.charAt(0) ||
                            admin.profile?.username?.charAt(0) ||
                            "A"}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">
                          {admin.profile?.full_name || "User"}
                        </p>
                        {admin.profile?.username && (
                          <p className="text-xs text-muted-foreground">
                            @{admin.profile.username}
                          </p>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        onClick={() => setAdminToRemove(admin)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}

                  {admins.length === 0 && (
                    <p className="text-center text-muted-foreground text-sm py-4">
                      No admins added yet
                    </p>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Recent Reviews */}
            <Card className={isOwner ? "" : "md:col-span-2"}>
              <CardHeader>
                <CardTitle>Recent Reviews</CardTitle>
                <CardDescription>What customers are saying</CardDescription>
              </CardHeader>
              <CardContent>
                {reviews.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    No reviews yet
                  </p>
                ) : (
                  <div className="space-y-3 max-h-60 overflow-y-auto">
                    {reviews.map((review) => (
                      <div key={review.id} className="p-3 rounded-lg bg-muted/50">
                        <div className="flex items-center gap-1 mb-1">
                          {Array.from({ length: 5 }, (_, i) => (
                            <Star
                              key={i}
                              className={`h-3 w-3 ${
                                i < review.rating
                                  ? "fill-yellow-400 text-yellow-400"
                                  : "text-muted"
                              }`}
                            />
                          ))}
                        </div>
                        {review.comment && (
                          <p className="text-sm text-foreground">{review.comment}</p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Remove Admin Confirmation */}
      <AlertDialog open={!!adminToRemove} onOpenChange={() => setAdminToRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Admin?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove {adminToRemove?.profile?.full_name || "this user"} from
              your shop admins. They will no longer be able to manage this shop.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleRemoveAdmin}>
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
};

export default ShopDashboard;
