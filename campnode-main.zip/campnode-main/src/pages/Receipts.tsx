import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { 
  Receipt, 
  Download,
  FileText,
  Calendar,
  CreditCard,
  ChevronDown,
  Printer,
  FileCode,
  Eye,
  CheckCircle,
  Clock,
  XCircle,
  Braces
} from "lucide-react";
import { format } from "date-fns";
import {
  downloadReceiptAsPDF,
  downloadReceiptAsText,
  downloadReceiptAsHTML,
  downloadReceiptAsJSON,
  generateReceiptHTML,
} from "@/lib/receiptGenerator";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface Transaction {
  id: string;
  transaction_reference: string;
  gross_amount: number;
  platform_fee: number;
  seller_amount: number;
  payment_status: string;
  created_at: string;
  product_id: string | null;
  order_id: string | null;
  seller_id: string;
  buyer_id: string;
  products?: {
    name: string;
    image: string | null;
  } | null;
}

interface Profile {
  full_name: string | null;
}

const Receipts = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [buyerProfile, setBuyerProfile] = useState<Profile | null>(null);
  const [previewHtml, setPreviewHtml] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        // Fetch buyer profile
        const { data: profile } = await supabase
          .from("profiles")
          .select("full_name")
          .eq("user_id", user.id)
          .single();

        setBuyerProfile(profile);

        // Fetch transactions
        const { data, error } = await supabase
          .from("transactions")
          .select(`
            *,
            products (name, image)
          `)
          .eq("buyer_id", user.id)
          .order("created_at", { ascending: false });

        if (error) throw error;
        setTransactions(data || []);
      } catch (error) {
        console.error("Error fetching transactions:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(price);
  };

  const getReceiptData = (tx: Transaction) => ({
    transactionReference: tx.transaction_reference,
    date: new Date(tx.created_at),
    productName: tx.products?.name || "Product Purchase",
    totalAmount: tx.gross_amount,
    buyerName: buyerProfile?.full_name || "Customer",
    status: tx.payment_status,
    type: "buyer" as const,
  });

  const handlePreview = (tx: Transaction) => {
    const html = generateReceiptHTML(getReceiptData(tx));
    setPreviewHtml(html);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-green-500/10 text-green-600 border-green-500/20 gap-1">
            <CheckCircle className="h-3 w-3" />
            Paid
          </Badge>
        );
      case "pending":
        return (
          <Badge variant="secondary" className="gap-1">
            <Clock className="h-3 w-3" />
            Pending
          </Badge>
        );
      case "failed":
        return (
          <Badge variant="destructive" className="gap-1">
            <XCircle className="h-3 w-3" />
            Failed
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (authLoading || loading) {
    return (
      <MainLayout>
        <div className="min-h-screen px-4 py-6">
          <div className="max-w-3xl mx-auto space-y-4">
            <div className="mb-6">
              <Skeleton className="h-8 w-32 mb-2" />
              <Skeleton className="h-4 w-48" />
            </div>
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-32 rounded-xl" />
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!user) return null;

  const completedTransactions = transactions.filter(tx => tx.payment_status === "completed");
  const pendingTransactions = transactions.filter(tx => tx.payment_status === "pending");

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-1">
              <div className="p-2 rounded-lg bg-primary/10">
                <Receipt className="h-5 w-5 text-primary" />
              </div>
              <h1 className="text-2xl font-bold text-foreground">Receipts</h1>
            </div>
            <p className="text-muted-foreground">
              View and download your payment receipts
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-green-500/10">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{completedTransactions.length}</p>
                    <p className="text-sm text-muted-foreground">Completed</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-yellow-500/10">
                    <Clock className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{pendingTransactions.length}</p>
                    <p className="text-sm text-muted-foreground">Pending</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Receipts List */}
          {transactions.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                  <FileText className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">No receipts yet</h3>
                <p className="text-muted-foreground text-sm text-center max-w-sm">
                  Your payment receipts will appear here after you make purchases
                </p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => navigate("/products")}
                >
                  Browse Products
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {transactions.map((tx) => (
                <Card key={tx.id} className="overflow-hidden hover:shadow-md transition-shadow">
                  <CardContent className="p-0">
                    <div className="flex items-center gap-4 p-4">
                      {/* Product Image */}
                      <div className="w-14 h-14 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                        {tx.products?.image ? (
                          <img
                            src={tx.products.image}
                            alt={tx.products.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <CreditCard className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-foreground truncate">
                            {tx.products?.name || "Product Purchase"}
                          </h3>
                          {getStatusBadge(tx.payment_status)}
                        </div>

                        <div className="flex items-center gap-3 text-sm text-muted-foreground">
                          <span className="font-mono text-xs bg-muted px-2 py-0.5 rounded">
                            {tx.transaction_reference.slice(0, 16)}...
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(tx.created_at), "MMM d, yyyy")}
                          </span>
                        </div>
                      </div>

                      {/* Amount & Actions */}
                      <div className="flex flex-col items-end gap-2">
                        <p className="text-lg font-bold text-foreground">
                          {formatPrice(tx.gross_amount)}
                        </p>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="outline" size="sm" className="gap-1">
                              <Download className="h-4 w-4" />
                              Download
                              <ChevronDown className="h-3 w-3" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48">
                            <DropdownMenuItem onClick={() => handlePreview(tx)}>
                              <Eye className="h-4 w-4 mr-2" />
                              Preview Receipt
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => downloadReceiptAsPDF(getReceiptData(tx))}>
                              <Printer className="h-4 w-4 mr-2" />
                              Print / Save PDF
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => downloadReceiptAsHTML(getReceiptData(tx))}>
                              <FileCode className="h-4 w-4 mr-2" />
                              Download HTML
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => downloadReceiptAsText(getReceiptData(tx))}>
                              <FileText className="h-4 w-4 mr-2" />
                              Download Text
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => downloadReceiptAsJSON(getReceiptData(tx))}>
                              <Braces className="h-4 w-4 mr-2" />
                              Download JSON
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Receipt Preview Dialog */}
      <Dialog open={!!previewHtml} onOpenChange={() => setPreviewHtml(null)}>
        <DialogContent className="max-w-lg p-0 overflow-hidden">
          <DialogHeader className="p-4 pb-0">
            <DialogTitle>Receipt Preview</DialogTitle>
          </DialogHeader>
          <div className="p-4">
            <div
              className="rounded-lg overflow-hidden"
              dangerouslySetInnerHTML={{ __html: previewHtml || "" }}
            />
          </div>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default Receipts;
