import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Search, SlidersHorizontal, X, User, Loader2, ShoppingBag, Store } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { ProductCard } from "@/components/ProductCard";
import { ShopCard } from "@/components/ShopCard";
import { CategoryFilter } from "@/components/CategoryFilter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";

interface Product {
  id: string;
  name: string;
  price: number;
  image: string | null;
  description: string | null;
  category: string;
  location: string | null;
  is_service: boolean | null;
  is_sponsored: boolean | null;
  shops?: { name: string } | null;
}

interface Shop {
  id: string;
  name: string;
  description: string | null;
  cover_image: string | null;
  profile_image: string | null;
  category: string;
  location: string | null;
  rating: number | null;
  is_verified: boolean | null;
}

interface UserProfile {
  id: string;
  user_id: string;
  full_name: string | null;
  username: string | null;
  avatar_url: string | null;
  department: string | null;
  campus_location: string | null;
}

const SearchPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const initialQuery = searchParams.get("q") || "";
  const [query, setQuery] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [activeTab, setActiveTab] = useState<"products" | "shops" | "users">("products");
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(true);

  const [products, setProducts] = useState<Product[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [productCounts, setProductCounts] = useState<Record<string, number>>({});

  // Fetch data from database
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Fetch products with search
        let productQuery = supabase
          .from("products")
          .select("*, shops(name)")
          .eq("is_active", true);

        if (query) {
          productQuery = productQuery.or(`name.ilike.%${query}%,description.ilike.%${query}%`);
        }

        if (selectedCategory !== "all") {
          productQuery = productQuery.eq("category", selectedCategory);
        }

        const { data: productsData, error: productsError } = await productQuery.limit(100);
        if (productsError) throw productsError;
        setProducts(productsData || []);

        // Fetch shops with search
        let shopQuery = supabase.from("shops").select("*");

        if (query) {
          shopQuery = shopQuery.or(`name.ilike.%${query}%,description.ilike.%${query}%`);
        }

        if (selectedCategory !== "all") {
          shopQuery = shopQuery.eq("category", selectedCategory);
        }

        const { data: shopsData, error: shopsError } = await shopQuery.limit(100);
        if (shopsError) throw shopsError;
        setShops(shopsData || []);

        // Fetch product counts for shops
        if (shopsData && shopsData.length > 0) {
          const shopIds = shopsData.map((s) => s.id);
          const { data: countData } = await supabase
            .from("products")
            .select("shop_id")
            .in("shop_id", shopIds)
            .eq("is_active", true);

          if (countData) {
            const counts: Record<string, number> = {};
            countData.forEach((p) => {
              if (p.shop_id) {
                counts[p.shop_id] = (counts[p.shop_id] || 0) + 1;
              }
            });
            setProductCounts(counts);
          }
        }

        // Fetch users with search
        let userQuery = supabase.from("profiles").select("*");

        if (query) {
          userQuery = userQuery.or(`full_name.ilike.%${query}%,username.ilike.%${query}%,department.ilike.%${query}%`);
        }

        const { data: usersData, error: usersError } = await userQuery.limit(50);
        if (usersError) throw usersError;
        setUsers(usersData || []);
      } catch (error) {
        console.error("Search error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [query, selectedCategory]);

  const mapProduct = (product: Product) => ({
    id: product.id,
    name: product.name,
    price: product.price,
    image: product.image || "/placeholder.svg",
    description: product.description || "",
    category: product.category,
    location: product.location || undefined,
    isService: product.is_service || false,
    isSponsored: product.is_sponsored || false,
    shopName: product.shops?.name,
  });

  const mapShop = (shop: Shop) => ({
    id: shop.id,
    name: shop.name,
    description: shop.description || "",
    coverImage: shop.cover_image || "/placeholder.svg",
    profileImage: shop.profile_image || "/placeholder.svg",
    category: shop.category,
    location: shop.location || "Campus",
    rating: shop.rating || 0,
    productCount: productCounts[shop.id] || 0,
    isVerified: shop.is_verified || false,
  });

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {/* Search Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-foreground mb-4">Search</h1>
            
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search products, shops, users..."
                className={cn(
                  "w-full pl-12 pr-24 py-3 rounded-xl",
                  "bg-muted/50 border border-border",
                  "text-foreground placeholder:text-muted-foreground",
                  "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary",
                  "transition-all duration-200"
                )}
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {query && (
                  <button
                    onClick={() => setQuery("")}
                    className="p-2 rounded-lg hover:bg-muted transition-colors"
                  >
                    <X className="h-4 w-4 text-muted-foreground" />
                  </button>
                )}
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className={cn(
                    "p-2 rounded-lg transition-colors",
                    showFilters ? "bg-primary text-primary-foreground" : "hover:bg-muted"
                  )}
                >
                  <SlidersHorizontal className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="mb-6 p-4 bg-card rounded-xl border border-border animate-fade-in">
              <p className="text-sm font-medium text-foreground mb-3">Filter by Category</p>
              <CategoryFilter 
                selected={selectedCategory} 
                onSelect={setSelectedCategory} 
              />
            </div>
          )}

          {/* Tabs */}
          <div className="flex gap-2 mb-6">
            <Button
              variant={activeTab === "products" ? "default" : "outline"}
              onClick={() => setActiveTab("products")}
              className="gap-2"
            >
              <ShoppingBag className="h-4 w-4" />
              Products
              <span className="px-2 py-0.5 rounded-full bg-primary-foreground/20 text-xs">
                {products.length}
              </span>
            </Button>
            <Button
              variant={activeTab === "shops" ? "default" : "outline"}
              onClick={() => setActiveTab("shops")}
              className="gap-2"
            >
              <Store className="h-4 w-4" />
              Shops
              <span className="px-2 py-0.5 rounded-full bg-primary-foreground/20 text-xs">
                {shops.length}
              </span>
            </Button>
            <Button
              variant={activeTab === "users" ? "default" : "outline"}
              onClick={() => setActiveTab("users")}
              className="gap-2"
            >
              <User className="h-4 w-4" />
              Users
              <span className="px-2 py-0.5 rounded-full bg-primary-foreground/20 text-xs">
                {users.length}
              </span>
            </Button>
          </div>

          {/* Loading */}
          {loading && (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}

          {/* Results */}
          {!loading && activeTab === "products" && (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {products.map((product, index) => (
                <ProductCard key={product.id} product={mapProduct(product)} index={index} />
              ))}
            </div>
          )}

          {!loading && activeTab === "shops" && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {shops.map((shop, index) => (
                <ShopCard key={shop.id} shop={mapShop(shop)} index={index} />
              ))}
            </div>
          )}

          {!loading && activeTab === "users" && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {users.map((user) => (
                <div
                  key={user.id}
                  className="bg-card rounded-xl border border-border p-4 hover:shadow-lg hover:border-primary/50 transition-all cursor-pointer"
                  onClick={() => navigate(`/user/${user.user_id}`)}
                >
                  <div className="flex items-center gap-4">
                    <Avatar className="h-14 w-14">
                      <AvatarImage src={user.avatar_url || undefined} />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {user.full_name?.charAt(0) || user.username?.charAt(0) || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-foreground truncate">
                        {user.full_name || "Anonymous"}
                      </h3>
                      {user.username && (
                        <p className="text-sm text-primary truncate">@{user.username}</p>
                      )}
                      {user.department && (
                        <p className="text-xs text-muted-foreground truncate">{user.department}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Empty State */}
          {!loading && (
            (activeTab === "products" && products.length === 0) ||
            (activeTab === "shops" && shops.length === 0) ||
            (activeTab === "users" && users.length === 0)
          ) && (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">No results found</h3>
              <p className="text-muted-foreground text-sm">
                Try adjusting your search or filters
              </p>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default SearchPage;
