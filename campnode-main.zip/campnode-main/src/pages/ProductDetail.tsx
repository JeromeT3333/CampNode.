import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Loader2,
  ShoppingCart,
  MapPin,
  Store,
  User,
  Minus,
  Plus,
  MessageCircle,
  Shield,
  Truck,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { cn } from "@/lib/utils";

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image: string | null;
  category: string;
  location: string | null;
  is_anonymous: boolean | null;
  has_delivery: boolean | null;
  is_service: boolean | null;
  seller_id: string;
  shop_id: string | null;
  shops?: { name: string; id: string } | null;
  available_colors: string[] | null;
  available_sizes: string[] | null;
  additional_images: string[] | null;
}

interface SellerProfile {
  full_name: string | null;
  avatar_url: string | null;
}

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [product, setProduct] = useState<Product | null>(null);
  const [seller, setSeller] = useState<SellerProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;

      try {
        const { data: productData, error: productError } = await supabase
          .from("products")
          .select("*, shops(name, id)")
          .eq("id", id)
          .single();

        if (productError) throw productError;
        setProduct(productData);

        // Set default selections
        if (productData.available_colors?.length) {
          setSelectedColor(productData.available_colors[0]);
        }
        if (productData.available_sizes?.length) {
          setSelectedSize(productData.available_sizes[0]);
        }

        // Fetch seller profile if not anonymous
        if (!productData.is_anonymous) {
          const { data: profileData } = await supabase
            .from("profiles")
            .select("full_name, avatar_url")
            .eq("user_id", productData.seller_id)
            .single();

          if (profileData) {
            setSeller(profileData);
          }
        }
      } catch (error: any) {
        console.error("Error fetching product:", error);
        toast.error("Product not found");
        navigate("/products");
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id, navigate]);

  const handleContactSeller = async () => {
    if (!user) {
      toast.error("Please sign in to contact the seller");
      navigate("/auth");
      return;
    }

    if (!product) return;

    if (user.id === product.seller_id) {
      toast.error("This is your own product");
      return;
    }

    // Navigate to DM with the seller
    navigate(`/dm/${product.seller_id}`);
  };

  const handleBuyNow = () => {
    if (!user) {
      toast.error("Please sign in to purchase");
      navigate("/auth");
      return;
    }

    if (!product) return;

    if (user.id === product.seller_id) {
      toast.error("You cannot buy your own product");
      return;
    }

    // Navigate to checkout with product details
    const params = new URLSearchParams({
      product: product.id,
      qty: quantity.toString(),
    });
    
    if (selectedColor) params.append("color", selectedColor);
    if (selectedSize) params.append("size", selectedSize);

    navigate(`/checkout?${params.toString()}`);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN"
    }).format(price);
  };

  // Combine main image with additional images for carousel
  const allImages = product ? [
    product.image,
    ...(product.additional_images || [])
  ].filter(Boolean) as string[] : [];

  if (loading) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!product) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <p className="text-muted-foreground">Product not found</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="min-h-screen px-4 py-6">
        <div className="max-w-4xl mx-auto">
          {/* Product Images Carousel */}
          <div className="mb-6">
            {allImages.length > 1 ? (
              <Carousel className="w-full">
                <CarouselContent>
                  {allImages.map((img, index) => (
                    <CarouselItem key={index}>
                      <div className="aspect-square md:aspect-video rounded-2xl overflow-hidden bg-muted">
                        <img
                          src={img}
                          alt={`${product.name} - Image ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <CarouselPrevious className="left-2" />
                <CarouselNext className="right-2" />
              </Carousel>
            ) : (
              <div className="aspect-square md:aspect-video rounded-2xl overflow-hidden bg-muted">
                {product.image ? (
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <ShoppingCart className="h-16 w-16 text-muted-foreground" />
                  </div>
                )}
              </div>
            )}

            {/* Thumbnail indicators */}
            {allImages.length > 1 && (
              <div className="flex justify-center gap-2 mt-3">
                {allImages.map((img, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 rounded-lg overflow-hidden border-2 border-muted hover:border-primary transition-colors cursor-pointer"
                  >
                    <img
                      src={img}
                      alt={`Thumbnail ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Product Info */}
            <div className="md:col-span-2 space-y-4">
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">{product.category}</Badge>
                {product.is_service && <Badge>Service</Badge>}
                {product.has_delivery && (
                  <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
                    <Truck className="h-3 w-3 mr-1" />
                    Delivery
                  </Badge>
                )}
              </div>

              <h1 className="text-2xl md:text-3xl font-bold text-foreground">
                {product.name}
              </h1>

              <p className="text-3xl font-bold text-primary">
                {formatPrice(product.price)}
              </p>

              {product.description && (
                <p className="text-muted-foreground leading-relaxed">
                  {product.description}
                </p>
              )}

              {/* Available Colors */}
              {product.available_colors && product.available_colors.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-foreground">Available Colors</p>
                  <div className="flex flex-wrap gap-2">
                    {product.available_colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={cn(
                          "px-3 py-1.5 rounded-full text-sm border transition-all",
                          selectedColor === color
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border text-muted-foreground hover:border-primary/50"
                        )}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Available Sizes */}
              {product.available_sizes && product.available_sizes.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-foreground">Available Sizes</p>
                  <div className="flex flex-wrap gap-2">
                    {product.available_sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={cn(
                          "w-10 h-10 rounded-lg text-sm font-medium border transition-all",
                          selectedSize === size
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-border text-muted-foreground hover:border-primary/50"
                        )}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {product.location && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{product.location}</span>
                </div>
              )}

              {/* Seller Info */}
              <div className="p-4 rounded-xl bg-muted/50 border border-border">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                    {product.is_anonymous ? (
                      <Shield className="h-6 w-6 text-muted-foreground" />
                    ) : seller?.avatar_url ? (
                      <img
                        src={seller.avatar_url}
                        alt="Seller"
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <User className="h-6 w-6 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-foreground">
                      {product.is_anonymous
                        ? "Anonymous Seller (Verified)"
                        : seller?.full_name || "Seller"}
                    </p>
                    {product.shops && (
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <Store className="h-3 w-3" />
                        {product.shops.name}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Purchase Card */}
            <div className="md:col-span-1">
              <div className="sticky top-6 p-6 rounded-xl border border-border bg-card space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Quantity</span>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-8 text-center font-medium">{quantity}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(quantity + 1)}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {selectedColor && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Color</span>
                    <span className="font-medium">{selectedColor}</span>
                  </div>
                )}

                {selectedSize && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Size</span>
                    <span className="font-medium">{selectedSize}</span>
                  </div>
                )}

                <div className="border-t border-border pt-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-semibold">
                      {formatPrice(product.price * quantity)}
                    </span>
                  </div>
                </div>

                <Button
                  className="w-full gap-2"
                  size="lg"
                  onClick={handleBuyNow}
                  disabled={user?.id === product.seller_id}
                >
                  <ShoppingCart className="h-4 w-4" />
                  Buy Now
                </Button>

                {user?.id === product.seller_id && (
                  <p className="text-xs text-center text-muted-foreground">
                    This is your product
                  </p>
                )}

                <Button 
                  variant="outline" 
                  className="w-full gap-2"
                  onClick={handleContactSeller}
                >
                  <MessageCircle className="h-4 w-4" />
                  Contact Seller
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default ProductDetail;
