export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      account_restrictions: {
        Row: {
          created_at: string | null
          expires_at: string | null
          id: string
          is_active: boolean | null
          notes: string | null
          reason: string | null
          restricted_at: string | null
          restricted_by: string
          restriction_type: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          notes?: string | null
          reason?: string | null
          restricted_at?: string | null
          restricted_by: string
          restriction_type?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          notes?: string | null
          reason?: string | null
          restricted_at?: string | null
          restricted_by?: string
          restriction_type?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      broadcast_messages: {
        Row: {
          created_at: string | null
          id: string
          is_sent: boolean | null
          message: string
          scheduled_at: string | null
          sent_at: string | null
          sent_by: string
          target_audience: string | null
          title: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_sent?: boolean | null
          message: string
          scheduled_at?: string | null
          sent_at?: string | null
          sent_by: string
          target_audience?: string | null
          title: string
        }
        Update: {
          created_at?: string | null
          id?: string
          is_sent?: boolean | null
          message?: string
          scheduled_at?: string | null
          sent_at?: string | null
          sent_by?: string
          target_audience?: string | null
          title?: string
        }
        Relationships: []
      }
      conversations: {
        Row: {
          buyer_id: string
          chat_theme: string | null
          closed_at: string | null
          created_at: string
          id: string
          is_active: boolean | null
          order_id: string | null
          seller_id: string
          updated_at: string
        }
        Insert: {
          buyer_id: string
          chat_theme?: string | null
          closed_at?: string | null
          created_at?: string
          id?: string
          is_active?: boolean | null
          order_id?: string | null
          seller_id: string
          updated_at?: string
        }
        Update: {
          buyer_id?: string
          chat_theme?: string | null
          closed_at?: string | null
          created_at?: string
          id?: string
          is_active?: boolean | null
          order_id?: string | null
          seller_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversations_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      escrow_orders: {
        Row: {
          buyer_id: string
          confirmed_at: string | null
          confirmed_by: string | null
          created_at: string
          escrow_status: string
          flutterwave_fee: number | null
          held_at: string
          id: string
          order_id: string
          platform_amount: number
          product_price: number
          released_at: string | null
          seller_amount: number
          seller_id: string
          service_fee: number
          updated_at: string
          vat_amount: number | null
        }
        Insert: {
          buyer_id: string
          confirmed_at?: string | null
          confirmed_by?: string | null
          created_at?: string
          escrow_status?: string
          flutterwave_fee?: number | null
          held_at?: string
          id?: string
          order_id: string
          platform_amount: number
          product_price: number
          released_at?: string | null
          seller_amount: number
          seller_id: string
          service_fee: number
          updated_at?: string
          vat_amount?: number | null
        }
        Update: {
          buyer_id?: string
          confirmed_at?: string | null
          confirmed_by?: string | null
          created_at?: string
          escrow_status?: string
          flutterwave_fee?: number | null
          held_at?: string
          id?: string
          order_id?: string
          platform_amount?: number
          product_price?: number
          released_at?: string | null
          seller_amount?: number
          seller_id?: string
          service_fee?: number
          updated_at?: string
          vat_amount?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "escrow_orders_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      message_reactions: {
        Row: {
          created_at: string
          emoji: string
          id: string
          message_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji: string
          id?: string
          message_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          id?: string
          message_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_reactions_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          attachment_url: string | null
          content: string | null
          conversation_id: string
          created_at: string
          id: string
          is_deleted: boolean | null
          is_pinned: boolean | null
          is_read: boolean | null
          message_type: string
          sender_id: string
        }
        Insert: {
          attachment_url?: string | null
          content?: string | null
          conversation_id: string
          created_at?: string
          id?: string
          is_deleted?: boolean | null
          is_pinned?: boolean | null
          is_read?: boolean | null
          message_type?: string
          sender_id: string
        }
        Update: {
          attachment_url?: string | null
          content?: string | null
          conversation_id?: string
          created_at?: string
          id?: string
          is_deleted?: boolean | null
          is_pinned?: boolean | null
          is_read?: boolean | null
          message_type?: string
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          data: Json | null
          id: string
          is_read: boolean | null
          message: string
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          data?: Json | null
          id?: string
          is_read?: boolean | null
          message: string
          title: string
          type: string
          user_id: string
        }
        Update: {
          created_at?: string
          data?: Json | null
          id?: string
          is_read?: boolean | null
          message?: string
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      orders: {
        Row: {
          buyer_confirmed_at: string | null
          buyer_id: string
          created_at: string
          delivery_location: string | null
          escrow_status: string | null
          id: string
          notes: string | null
          payment_reference: string | null
          payment_status: string
          product_id: string | null
          quantity: number
          seller_amount: number | null
          seller_id: string
          service_fee: number | null
          status: string
          total_amount: number
          updated_at: string
        }
        Insert: {
          buyer_confirmed_at?: string | null
          buyer_id: string
          created_at?: string
          delivery_location?: string | null
          escrow_status?: string | null
          id?: string
          notes?: string | null
          payment_reference?: string | null
          payment_status?: string
          product_id?: string | null
          quantity?: number
          seller_amount?: number | null
          seller_id: string
          service_fee?: number | null
          status?: string
          total_amount: number
          updated_at?: string
        }
        Update: {
          buyer_confirmed_at?: string | null
          buyer_id?: string
          created_at?: string
          delivery_location?: string | null
          escrow_status?: string | null
          id?: string
          notes?: string | null
          payment_reference?: string | null
          payment_status?: string
          product_id?: string | null
          quantity?: number
          seller_amount?: number | null
          seller_id?: string
          service_fee?: number | null
          status?: string
          total_amount?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "orders_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      payouts: {
        Row: {
          account_name: string
          account_number: string
          amount: number
          bank_code: string
          created_at: string
          currency: string
          failure_reason: string | null
          flutterwave_reference: string | null
          id: string
          payout_reference: string
          retry_count: number
          seller_id: string
          status: string
          transaction_id: string | null
          updated_at: string
        }
        Insert: {
          account_name: string
          account_number: string
          amount: number
          bank_code: string
          created_at?: string
          currency?: string
          failure_reason?: string | null
          flutterwave_reference?: string | null
          id?: string
          payout_reference: string
          retry_count?: number
          seller_id: string
          status?: string
          transaction_id?: string | null
          updated_at?: string
        }
        Update: {
          account_name?: string
          account_number?: string
          amount?: number
          bank_code?: string
          created_at?: string
          currency?: string
          failure_reason?: string | null
          flutterwave_reference?: string | null
          id?: string
          payout_reference?: string
          retry_count?: number
          seller_id?: string
          status?: string
          transaction_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payouts_transaction_id_fkey"
            columns: ["transaction_id"]
            isOneToOne: false
            referencedRelation: "transactions"
            referencedColumns: ["id"]
          },
        ]
      }
      platform_settings: {
        Row: {
          created_at: string
          id: string
          setting_key: string
          setting_value: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          setting_key: string
          setting_value: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          setting_key?: string
          setting_value?: string
          updated_at?: string
        }
        Relationships: []
      }
      platform_wallet: {
        Row: {
          balance: number
          currency: string
          id: string
          total_earnings: number
          total_withdrawn: number
          updated_at: string
        }
        Insert: {
          balance?: number
          currency?: string
          id?: string
          total_earnings?: number
          total_withdrawn?: number
          updated_at?: string
        }
        Update: {
          balance?: number
          currency?: string
          id?: string
          total_earnings?: number
          total_withdrawn?: number
          updated_at?: string
        }
        Relationships: []
      }
      platform_wallet_transactions: {
        Row: {
          amount: number
          balance_after: number
          balance_before: number
          created_at: string
          description: string | null
          id: string
          order_id: string | null
          reference: string | null
          transaction_type: string
        }
        Insert: {
          amount: number
          balance_after: number
          balance_before: number
          created_at?: string
          description?: string | null
          id?: string
          order_id?: string | null
          reference?: string | null
          transaction_type: string
        }
        Update: {
          amount?: number
          balance_after?: number
          balance_before?: number
          created_at?: string
          description?: string | null
          id?: string
          order_id?: string | null
          reference?: string | null
          transaction_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "platform_wallet_transactions_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      premium_memberships: {
        Row: {
          created_at: string | null
          enabled_by: string | null
          expires_at: string | null
          id: string
          is_active: boolean | null
          started_at: string | null
          tier: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          enabled_by?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          started_at?: string | null
          tier?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          enabled_by?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          started_at?: string | null
          tier?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      products: {
        Row: {
          additional_images: string[] | null
          available_colors: string[] | null
          available_sizes: string[] | null
          category: string
          created_at: string
          description: string | null
          gif_interval: number | null
          gif_url: string | null
          has_delivery: boolean | null
          id: string
          image: string | null
          is_active: boolean | null
          is_anonymous: boolean | null
          is_service: boolean | null
          is_sponsored: boolean | null
          location: string | null
          name: string
          price: number
          seller_id: string
          shop_id: string | null
          updated_at: string
        }
        Insert: {
          additional_images?: string[] | null
          available_colors?: string[] | null
          available_sizes?: string[] | null
          category: string
          created_at?: string
          description?: string | null
          gif_interval?: number | null
          gif_url?: string | null
          has_delivery?: boolean | null
          id?: string
          image?: string | null
          is_active?: boolean | null
          is_anonymous?: boolean | null
          is_service?: boolean | null
          is_sponsored?: boolean | null
          location?: string | null
          name: string
          price: number
          seller_id: string
          shop_id?: string | null
          updated_at?: string
        }
        Update: {
          additional_images?: string[] | null
          available_colors?: string[] | null
          available_sizes?: string[] | null
          category?: string
          created_at?: string
          description?: string | null
          gif_interval?: number | null
          gif_url?: string | null
          has_delivery?: boolean | null
          id?: string
          image?: string | null
          is_active?: boolean | null
          is_anonymous?: boolean | null
          is_service?: boolean | null
          is_sponsored?: boolean | null
          location?: string | null
          name?: string
          price?: number
          seller_id?: string
          shop_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "products_shop_id_fkey"
            columns: ["shop_id"]
            isOneToOne: false
            referencedRelation: "shops"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          campus_location: string | null
          created_at: string
          department: string | null
          full_name: string | null
          id: string
          phone: string | null
          profile_complete: boolean | null
          role: string | null
          updated_at: string
          user_id: string
          username: string | null
        }
        Insert: {
          avatar_url?: string | null
          campus_location?: string | null
          created_at?: string
          department?: string | null
          full_name?: string | null
          id?: string
          phone?: string | null
          profile_complete?: boolean | null
          role?: string | null
          updated_at?: string
          user_id: string
          username?: string | null
        }
        Update: {
          avatar_url?: string | null
          campus_location?: string | null
          created_at?: string
          department?: string | null
          full_name?: string | null
          id?: string
          phone?: string | null
          profile_complete?: boolean | null
          role?: string | null
          updated_at?: string
          user_id?: string
          username?: string | null
        }
        Relationships: []
      }
      reservations: {
        Row: {
          created_at: string
          customer_id: string
          id: string
          notes: string | null
          reservation_date: string
          reservation_time: string
          service_name: string
          shop_id: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_id: string
          id?: string
          notes?: string | null
          reservation_date: string
          reservation_time: string
          service_name: string
          shop_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_id?: string
          id?: string
          notes?: string | null
          reservation_date?: string
          reservation_time?: string
          service_name?: string
          shop_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "reservations_shop_id_fkey"
            columns: ["shop_id"]
            isOneToOne: false
            referencedRelation: "shops"
            referencedColumns: ["id"]
          },
        ]
      }
      reviews: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          order_id: string
          product_id: string | null
          rating: number
          reviewer_id: string
          seller_id: string
          shop_id: string | null
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          order_id: string
          product_id?: string | null
          rating: number
          reviewer_id: string
          seller_id: string
          shop_id?: string | null
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          order_id?: string
          product_id?: string | null
          rating?: number
          reviewer_id?: string
          seller_id?: string
          shop_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "reviews_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_shop_id_fkey"
            columns: ["shop_id"]
            isOneToOne: false
            referencedRelation: "shops"
            referencedColumns: ["id"]
          },
        ]
      }
      seller_bank_details: {
        Row: {
          account_name: string
          account_number: string
          bank_code: string
          bank_name: string
          created_at: string
          id: string
          seller_id: string
          updated_at: string
          verification_status: string
        }
        Insert: {
          account_name: string
          account_number: string
          bank_code: string
          bank_name: string
          created_at?: string
          id?: string
          seller_id: string
          updated_at?: string
          verification_status?: string
        }
        Update: {
          account_name?: string
          account_number?: string
          bank_code?: string
          bank_name?: string
          created_at?: string
          id?: string
          seller_id?: string
          updated_at?: string
          verification_status?: string
        }
        Relationships: []
      }
      seller_subaccounts: {
        Row: {
          business_name: string | null
          created_at: string
          id: string
          is_active: boolean
          seller_id: string
          split_type: string
          split_value: number
          subaccount_id: string
          updated_at: string
        }
        Insert: {
          business_name?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          seller_id: string
          split_type?: string
          split_value?: number
          subaccount_id: string
          updated_at?: string
        }
        Update: {
          business_name?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          seller_id?: string
          split_type?: string
          split_value?: number
          subaccount_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      seller_wallets: {
        Row: {
          available_balance: number
          created_at: string
          currency: string
          id: string
          pending_balance: number
          seller_id: string
          total_earnings: number
          total_withdrawn: number
          updated_at: string
        }
        Insert: {
          available_balance?: number
          created_at?: string
          currency?: string
          id?: string
          pending_balance?: number
          seller_id: string
          total_earnings?: number
          total_withdrawn?: number
          updated_at?: string
        }
        Update: {
          available_balance?: number
          created_at?: string
          currency?: string
          id?: string
          pending_balance?: number
          seller_id?: string
          total_earnings?: number
          total_withdrawn?: number
          updated_at?: string
        }
        Relationships: []
      }
      shop_admins: {
        Row: {
          created_at: string
          id: string
          shop_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          shop_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          shop_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "shop_admins_shop_id_fkey"
            columns: ["shop_id"]
            isOneToOne: false
            referencedRelation: "shops"
            referencedColumns: ["id"]
          },
        ]
      }
      shops: {
        Row: {
          category: string
          closing_time: string | null
          cover_image: string | null
          created_at: string
          description: string | null
          has_delivery: boolean | null
          id: string
          is_open_24hrs: boolean | null
          is_verified: boolean | null
          location: string | null
          name: string
          opening_time: string | null
          owner_id: string
          profile_image: string | null
          rating: number | null
          updated_at: string
        }
        Insert: {
          category: string
          closing_time?: string | null
          cover_image?: string | null
          created_at?: string
          description?: string | null
          has_delivery?: boolean | null
          id?: string
          is_open_24hrs?: boolean | null
          is_verified?: boolean | null
          location?: string | null
          name: string
          opening_time?: string | null
          owner_id: string
          profile_image?: string | null
          rating?: number | null
          updated_at?: string
        }
        Update: {
          category?: string
          closing_time?: string | null
          cover_image?: string | null
          created_at?: string
          description?: string | null
          has_delivery?: boolean | null
          id?: string
          is_open_24hrs?: boolean | null
          is_verified?: boolean | null
          location?: string | null
          name?: string
          opening_time?: string | null
          owner_id?: string
          profile_image?: string | null
          rating?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      sticker_packs: {
        Row: {
          created_at: string
          id: string
          name: string
          preview_url: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          preview_url: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          preview_url?: string
        }
        Relationships: []
      }
      stickers: {
        Row: {
          created_at: string
          emoji: string | null
          id: string
          pack_id: string
          url: string
        }
        Insert: {
          created_at?: string
          emoji?: string | null
          id?: string
          pack_id: string
          url: string
        }
        Update: {
          created_at?: string
          emoji?: string | null
          id?: string
          pack_id?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "stickers_pack_id_fkey"
            columns: ["pack_id"]
            isOneToOne: false
            referencedRelation: "sticker_packs"
            referencedColumns: ["id"]
          },
        ]
      }
      support_auth_tokens: {
        Row: {
          authorized_scope: string[] | null
          created_at: string | null
          expires_at: string
          id: string
          token: string
          used_at: string | null
          used_by: string | null
          user_id: string
        }
        Insert: {
          authorized_scope?: string[] | null
          created_at?: string | null
          expires_at: string
          id?: string
          token: string
          used_at?: string | null
          used_by?: string | null
          user_id: string
        }
        Update: {
          authorized_scope?: string[] | null
          created_at?: string | null
          expires_at?: string
          id?: string
          token?: string
          used_at?: string | null
          used_by?: string | null
          user_id?: string
        }
        Relationships: []
      }
      system_accounts: {
        Row: {
          account_type: string
          avatar_url: string | null
          created_at: string | null
          display_name: string
          id: string
          is_verified: boolean | null
        }
        Insert: {
          account_type: string
          avatar_url?: string | null
          created_at?: string | null
          display_name: string
          id?: string
          is_verified?: boolean | null
        }
        Update: {
          account_type?: string
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string
          id?: string
          is_verified?: boolean | null
        }
        Relationships: []
      }
      transactions: {
        Row: {
          buyer_id: string
          created_at: string
          currency: string
          flutterwave_reference: string | null
          gross_amount: number
          id: string
          order_id: string | null
          payment_status: string
          platform_fee: number
          product_id: string | null
          seller_amount: number
          seller_id: string
          transaction_reference: string
          updated_at: string
        }
        Insert: {
          buyer_id: string
          created_at?: string
          currency?: string
          flutterwave_reference?: string | null
          gross_amount: number
          id?: string
          order_id?: string | null
          payment_status?: string
          platform_fee: number
          product_id?: string | null
          seller_amount: number
          seller_id: string
          transaction_reference: string
          updated_at?: string
        }
        Update: {
          buyer_id?: string
          created_at?: string
          currency?: string
          flutterwave_reference?: string | null
          gross_amount?: number
          id?: string
          order_id?: string | null
          payment_status?: string
          platform_fee?: number
          product_id?: string | null
          seller_amount?: number
          seller_id?: string
          transaction_reference?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "transactions_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      typing_status: {
        Row: {
          conversation_id: string
          id: string
          is_typing: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          conversation_id: string
          id?: string
          is_typing?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          conversation_id?: string
          id?: string
          is_typing?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "typing_status_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      user_presence: {
        Row: {
          id: string
          is_online: boolean
          last_seen: string
          updated_at: string
          user_id: string
        }
        Insert: {
          id?: string
          is_online?: boolean
          last_seen?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          id?: string
          is_online?: boolean
          last_seen?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      wallet_transactions: {
        Row: {
          amount: number
          balance_after: number
          balance_before: number
          balance_type: string
          created_at: string
          description: string | null
          id: string
          metadata: Json | null
          order_id: string | null
          reference: string | null
          transaction_type: string
          wallet_id: string
        }
        Insert: {
          amount: number
          balance_after: number
          balance_before: number
          balance_type: string
          created_at?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          order_id?: string | null
          reference?: string | null
          transaction_type: string
          wallet_id: string
        }
        Update: {
          amount?: number
          balance_after?: number
          balance_before?: number
          balance_type?: string
          created_at?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          order_id?: string | null
          reference?: string | null
          transaction_type?: string
          wallet_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wallet_transactions_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wallet_transactions_wallet_id_fkey"
            columns: ["wallet_id"]
            isOneToOne: false
            referencedRelation: "seller_wallets"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_logs: {
        Row: {
          created_at: string
          error_message: string | null
          event_type: string
          id: string
          payload: Json
          processed_at: string | null
          status: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          event_type: string
          id?: string
          payload: Json
          processed_at?: string | null
          status?: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          event_type?: string
          id?: string
          payload?: Json
          processed_at?: string | null
          status?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      close_order_chat: { Args: { p_order_id: string }; Returns: undefined }
      confirm_order_delivery: {
        Args: { p_order_id: string }
        Returns: undefined
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      initialize_seller_wallet: {
        Args: { p_seller_id: string }
        Returns: string
      }
      release_escrow: {
        Args: { p_buyer_id: string; p_order_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user" | "support"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user", "support"],
    },
  },
} as const
