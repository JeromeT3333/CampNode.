import { useEffect, useState, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

export const useTypingIndicator = (
  conversationId: string | undefined,
  userId: string | undefined
) => {
  const [isOtherUserTyping, setIsOtherUserTyping] = useState(false);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastTypingUpdateRef = useRef<number>(0);

  // Update typing status
  const setTyping = useCallback(
    async (isTyping: boolean) => {
      if (!conversationId || !userId) return;

      const now = Date.now();
      // Throttle updates to once per second
      if (isTyping && now - lastTypingUpdateRef.current < 1000) return;
      lastTypingUpdateRef.current = now;

      try {
        // Upsert typing status
        await supabase.from("typing_status").upsert(
          {
            conversation_id: conversationId,
            user_id: userId,
            is_typing: isTyping,
            updated_at: new Date().toISOString(),
          },
          {
            onConflict: "conversation_id,user_id",
          }
        );
      } catch (error) {
        console.error("Failed to update typing status:", error);
      }
    },
    [conversationId, userId]
  );

  // Handle input change - set typing to true
  const handleTypingStart = useCallback(() => {
    setTyping(true);

    // Clear existing timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    // Set timeout to stop typing after 3 seconds of inactivity
    typingTimeoutRef.current = setTimeout(() => {
      setTyping(false);
    }, 3000);
  }, [setTyping]);

  // Stop typing immediately (e.g., when sending message)
  const stopTyping = useCallback(() => {
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    setTyping(false);
  }, [setTyping]);

  // Subscribe to typing status changes
  useEffect(() => {
    if (!conversationId || !userId) return;

    const channel = supabase
      .channel(`typing-${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "typing_status",
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          const data = payload.new as {
            user_id: string;
            is_typing: boolean;
          };

          // Only show typing indicator for the other user
          if (data.user_id !== userId) {
            setIsOtherUserTyping(data.is_typing);

            // Auto-hide after 5 seconds (in case update is missed)
            if (data.is_typing) {
              setTimeout(() => {
                setIsOtherUserTyping(false);
              }, 5000);
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      // Clean up typing status when leaving
      setTyping(false);
    };
  }, [conversationId, userId, setTyping]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, []);

  return {
    isOtherUserTyping,
    handleTypingStart,
    stopTyping,
  };
};