import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface PendingMessage {
  id: string;
  conversationId: string;
  content: string | null;
  messageType: "text" | "sticker" | "image" | "voice" | "file";
  attachmentUrl: string | null;
  createdAt: string;
  senderId: string;
  status: "pending" | "sending" | "failed";
  retryCount: number;
}

const STORAGE_KEY = "campnode_pending_messages";
const MAX_RETRIES = 3;

export const useOfflineMessages = (conversationId: string | undefined, userId: string | undefined) => {
  const [pendingMessages, setPendingMessages] = useState<PendingMessage[]>([]);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Load pending messages from localStorage
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const allPending: PendingMessage[] = JSON.parse(stored);
        setPendingMessages(allPending.filter(m => m.conversationId === conversationId));
      } catch {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
  }, [conversationId]);

  // Monitor online status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      toast.success("You're back online!");
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      toast.warning("You're offline. Messages will be sent when connection is restored.");
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Try to send pending messages when online
  useEffect(() => {
    if (!isOnline || !userId || pendingMessages.length === 0) return;

    const sendPendingMessages = async () => {
      for (const msg of pendingMessages) {
        if (msg.status === "sending") continue;
        
        // Update status to sending
        updateMessageStatus(msg.id, "sending");

        try {
          const { error } = await supabase.from("messages").insert({
            conversation_id: msg.conversationId,
            sender_id: msg.senderId,
            content: msg.content,
            message_type: msg.messageType,
            attachment_url: msg.attachmentUrl
          });

          if (error) throw error;

          // Remove from pending
          removeMessage(msg.id);
        } catch (error) {
          console.error("Failed to send pending message:", error);
          
          if (msg.retryCount >= MAX_RETRIES) {
            updateMessageStatus(msg.id, "failed");
          } else {
            incrementRetry(msg.id);
            updateMessageStatus(msg.id, "pending");
          }
        }
      }
    };

    const timeout = setTimeout(sendPendingMessages, 1000);
    return () => clearTimeout(timeout);
  }, [isOnline, pendingMessages, userId]);

  const savePendingMessages = (messages: PendingMessage[]) => {
    const stored = localStorage.getItem(STORAGE_KEY);
    let allPending: PendingMessage[] = [];
    
    if (stored) {
      try {
        allPending = JSON.parse(stored);
        // Remove old messages for this conversation
        allPending = allPending.filter(m => m.conversationId !== conversationId);
      } catch {
        allPending = [];
      }
    }
    
    allPending = [...allPending, ...messages];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(allPending));
  };

  const addPendingMessage = useCallback((
    content: string | null,
    messageType: PendingMessage["messageType"],
    attachmentUrl: string | null = null
  ): PendingMessage | null => {
    if (!conversationId || !userId) return null;

    const newMessage: PendingMessage = {
      id: `pending_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      conversationId,
      content,
      messageType,
      attachmentUrl,
      createdAt: new Date().toISOString(),
      senderId: userId,
      status: "pending",
      retryCount: 0
    };

    setPendingMessages(prev => {
      const updated = [...prev, newMessage];
      savePendingMessages(updated);
      return updated;
    });

    return newMessage;
  }, [conversationId, userId]);

  const removeMessage = useCallback((messageId: string) => {
    setPendingMessages(prev => {
      const updated = prev.filter(m => m.id !== messageId);
      savePendingMessages(updated);
      return updated;
    });
  }, [conversationId]);

  const updateMessageStatus = useCallback((messageId: string, status: PendingMessage["status"]) => {
    setPendingMessages(prev => {
      const updated = prev.map(m => 
        m.id === messageId ? { ...m, status } : m
      );
      savePendingMessages(updated);
      return updated;
    });
  }, [conversationId]);

  const incrementRetry = useCallback((messageId: string) => {
    setPendingMessages(prev => {
      const updated = prev.map(m => 
        m.id === messageId ? { ...m, retryCount: m.retryCount + 1 } : m
      );
      savePendingMessages(updated);
      return updated;
    });
  }, [conversationId]);

  const retryMessage = useCallback(async (messageId: string) => {
    const msg = pendingMessages.find(m => m.id === messageId);
    if (!msg) return;

    updateMessageStatus(messageId, "sending");

    try {
      const { error } = await supabase.from("messages").insert({
        conversation_id: msg.conversationId,
        sender_id: msg.senderId,
        content: msg.content,
        message_type: msg.messageType,
        attachment_url: msg.attachmentUrl
      });

      if (error) throw error;
      removeMessage(messageId);
      toast.success("Message sent!");
    } catch (error) {
      toast.error("Failed to send message");
      updateMessageStatus(messageId, "failed");
    }
  }, [pendingMessages, removeMessage, updateMessageStatus]);

  return {
    pendingMessages,
    isOnline,
    addPendingMessage,
    removeMessage,
    retryMessage
  };
};
