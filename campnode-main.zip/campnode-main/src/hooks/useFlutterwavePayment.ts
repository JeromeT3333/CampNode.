import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

declare global {
  interface Window {
    FlutterwaveCheckout: (config: FlutterwaveConfig) => void;
  }
}

interface FlutterwaveConfig {
  public_key: string;
  tx_ref: string;
  amount: number;
  currency: string;
  payment_options?: string;
  customer: {
    email: string;
    name: string;
    phone_number?: string;
  };
  customizations: {
    title: string;
    description: string;
    logo: string;
    theme?: {
      primary_color?: string;
      secondary_color?: string;
    };
  };
  subaccounts?: Array<{
    id: string;
    transaction_split_ratio: number;
  }>;
  callback: (response: FlutterwaveResponse) => void;
  onclose: () => void;
}

interface FlutterwaveResponse {
  status: string;
  transaction_id: number;
  tx_ref: string;
  flw_ref: string;
}

interface PaymentConfig {
  product_id: string;
  quantity?: number;
  buyer_email: string;
  buyer_name?: string;
  buyer_phone?: string;
  currency?: string;
  redirect_url?: string;
  onSuccess?: (response: FlutterwaveResponse) => void;
  onClose?: () => void;
}

interface PaymentBreakdown {
  product_price: number;
  service_fee: number;
  total_amount: number;
  seller_receives: number;
  vat_estimate: number;
  platform_estimate: number;
}

export const useFlutterwavePayment = () => {
  const [loading, setLoading] = useState(false);
  const [breakdown, setBreakdown] = useState<PaymentBreakdown | null>(null);

  const loadFlutterwaveScript = (): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (window.FlutterwaveCheckout) {
        resolve();
        return;
      }

      const existingScript = document.querySelector('script[src*="flutterwave"]');
      if (existingScript) {
        existingScript.addEventListener('load', () => resolve());
        existingScript.addEventListener('error', reject);
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://checkout.flutterwave.com/v3.js';
      script.async = true;
      script.onload = () => resolve();
      script.onerror = reject;
      document.body.appendChild(script);
    });
  };

  const initializePayment = async (config: PaymentConfig) => {
    setLoading(true);

    try {
      await loadFlutterwaveScript();

      // Initialize payment via edge function
      const { data, error } = await supabase.functions.invoke("process-payment", {
        body: {
          product_id: config.product_id,
          quantity: config.quantity || 1,
          buyer_email: config.buyer_email,
          buyer_name: config.buyer_name,
          buyer_phone: config.buyer_phone,
          currency: config.currency || 'NGN',
          redirect_url: config.redirect_url || `${window.location.origin}/payment-complete`
        }
      });

      if (error) throw error;
      if (data.status !== "success") throw new Error(data.message || "Failed to initialize payment");

      const paymentData = data.data;
      setBreakdown(paymentData.breakdown);

      // Open Flutterwave checkout with CampNode theming
      // Brand colors matching site theme
      const brandTheme = {
        primary: "#2D9769", // Primary teal
        secondary: "#7C5CD6", // Secondary purple
      };

      window.FlutterwaveCheckout({
        public_key: paymentData.public_key,
        tx_ref: paymentData.tx_ref,
        amount: paymentData.amount,
        currency: paymentData.currency,
        payment_options: "card,banktransfer,ussd",
        customer: paymentData.customer,
        customizations: {
          title: "CampNode",
          description: paymentData.customizations.description,
          logo: paymentData.customizations.logo,
          // Apply brand colors to Flutterwave modal
          theme: {
            primary_color: brandTheme.primary,
            secondary_color: brandTheme.secondary,
          }
        },
        subaccounts: paymentData.subaccounts,
        callback: (response: FlutterwaveResponse) => {
          console.log("Payment response:", response);
          if (response.status === "successful" || response.status === "completed") {
            toast.success("Payment successful!");
            config.onSuccess?.(response);
          } else {
            toast.error("Payment was not completed");
          }
          setLoading(false);
        },
        onclose: () => {
          console.log("Payment modal closed");
          config.onClose?.();
          setLoading(false);
        }
      });
    } catch (error: unknown) {
      console.error("Payment error:", error);
      const message = error instanceof Error ? error.message : "Failed to initialize payment";
      toast.error(message);
      setLoading(false);
    }
  };

  const getPaymentBreakdown = async (productId: string, quantity: number = 1) => {
    const PLATFORM_FEE_PERCENT = 5;
    
    try {
      const { data: product } = await supabase
        .from('products')
        .select('price')
        .eq('id', productId)
        .single();

      if (!product) return null;

      const productPrice = parseFloat(String(product.price)) * quantity;
      const serviceFee = productPrice * (PLATFORM_FEE_PERCENT / 100);
      const totalAmount = productPrice + serviceFee;
      const sellerReceives = productPrice * 0.95;

      return {
        product_price: productPrice,
        service_fee: serviceFee,
        total_amount: totalAmount,
        seller_receives: sellerReceives,
        vat_estimate: totalAmount * 0.015,
        platform_estimate: serviceFee - (totalAmount * 0.015) - ((totalAmount * 0.014) + 100)
      };
    } catch {
      return null;
    }
  };

  return { initializePayment, loading, breakdown, getPaymentBreakdown };
};
