import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface TypingStatus {
  conversationId: string;
  userId: string;
  isTyping: boolean;
}

export const useConversationStatus = (userId: string | undefined) => {
  const [typingStatuses, setTypingStatuses] = useState<Map<string, TypingStatus>>(new Map());

  useEffect(() => {
    if (!userId) return;

    // Subscribe to all typing status changes
    const channel = supabase
      .channel(`all-typing-${userId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "typing_status",
        },
        (payload) => {
          const data = payload.new as {
            conversation_id: string;
            user_id: string;
            is_typing: boolean;
          } | null;
          
          if (!data) {
            // Delete event
            const oldData = payload.old as { conversation_id: string; user_id: string };
            if (oldData.user_id !== userId) {
              setTypingStatuses(prev => {
                const next = new Map(prev);
                next.delete(`${oldData.conversation_id}-${oldData.user_id}`);
                return next;
              });
            }
            return;
          }

          // Only track other users' typing
          if (data.user_id !== userId) {
            setTypingStatuses(prev => {
              const next = new Map(prev);
              const key = `${data.conversation_id}-${data.user_id}`;
              
              if (data.is_typing) {
                next.set(key, {
                  conversationId: data.conversation_id,
                  userId: data.user_id,
                  isTyping: true
                });
              } else {
                next.delete(key);
              }
              return next;
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  const isTypingInConversation = (conversationId: string): boolean => {
    return Array.from(typingStatuses.values()).some(
      status => status.conversationId === conversationId && status.isTyping
    );
  };

  return { typingStatuses, isTypingInConversation };
};