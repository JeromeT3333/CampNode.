import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export const useOnlineStatus = (userId?: string) => {
  const [isOnline, setIsOnline] = useState(false);
  const [lastSeen, setLastSeen] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) return;

    const fetchStatus = async () => {
      const { data } = await supabase
        .from("user_presence")
        .select("is_online, last_seen")
        .eq("user_id", userId)
        .single();

      if (data) {
        setIsOnline(data.is_online);
        setLastSeen(data.last_seen);
      }
    };

    fetchStatus();

    // Subscribe to realtime updates
    const channel = supabase
      .channel(`presence-${userId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "user_presence",
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          if (payload.new) {
            const data = payload.new as { is_online: boolean; last_seen: string };
            setIsOnline(data.is_online);
            setLastSeen(data.last_seen);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  return { isOnline, lastSeen };
};

// Hook for managing current user's online status
export const usePresence = (currentUserId?: string) => {
  const updatePresence = useCallback(async (online: boolean) => {
    if (!currentUserId) return;

    const { data: existing } = await supabase
      .from("user_presence")
      .select("id")
      .eq("user_id", currentUserId)
      .single();

    if (existing) {
      await supabase
        .from("user_presence")
        .update({ is_online: online, last_seen: new Date().toISOString() })
        .eq("user_id", currentUserId);
    } else {
      await supabase.from("user_presence").insert({
        user_id: currentUserId,
        is_online: online,
        last_seen: new Date().toISOString()
      });
    }
  }, [currentUserId]);

  useEffect(() => {
    if (!currentUserId) return;

    // Set online when component mounts
    updatePresence(true);

    // Set offline when page closes
    const handleBeforeUnload = () => {
      navigator.sendBeacon && updatePresence(false);
    };

    const handleVisibilityChange = () => {
      updatePresence(!document.hidden);
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    document.addEventListener("visibilitychange", handleVisibilityChange);

    // Heartbeat every 30 seconds
    const interval = setInterval(() => {
      updatePresence(true);
    }, 30000);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      clearInterval(interval);
      updatePresence(false);
    };
  }, [currentUserId, updatePresence]);
};

export const formatLastSeen = (lastSeen: string | null): string => {
  if (!lastSeen) return "Never";
  
  const date = new Date(lastSeen);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 1) return "Just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays === 1) return "Yesterday";
  return date.toLocaleDateString();
};