export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  category: string;
  isSponsored?: boolean;
  shopId?: string;
  shopName?: string;
  location?: string;
  isService?: boolean;
  hasDelivery?: boolean;
  additionalImages?: string[];
}

export interface Shop {
  id: string;
  name: string;
  description: string;
  coverImage: string;
  profileImage: string;
  category: string;
  location: string;
  rating: number;
  productCount: number;
  isVerified?: boolean;
}

export const categories = [
  { id: "all", name: "All", icon: "🏪" },
  { id: "food", name: "Food & Drinks", icon: "🍔" },
  { id: "electronics", name: "Electronics", icon: "💻" },
  { id: "fashion", name: "Fashion", icon: "👕" },
  { id: "books", name: "Books & Notes", icon: "📚" },
  { id: "services", name: "Services", icon: "✂️" },
  { id: "photography", name: "Photography", icon: "📷" },
  { id: "printing", name: "Printing", icon: "🖨️" },
  { id: "provisions", name: "Provisions", icon: "🛒" },
  { id: "store", name: "Store", icon: "🏬" },
  { id: "other", name: "Other", icon: "📦" },
];

// Empty arrays - data now comes from database
export const products: Product[] = [];
export const shops: Shop[] = [];
