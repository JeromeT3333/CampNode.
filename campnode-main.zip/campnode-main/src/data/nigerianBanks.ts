export interface NigerianBank {
  code: string;
  name: string;
}

// Complete list of Nigerian banks with correct Flutterwave/NIBSS bank codes
// Source: Flutterwave API and NIBSS documentation
export const nigerianBanks: NigerianBank[] = [
  { code: "120001", name: "9mobile 9Payment Service Bank" },
  { code: "000014", name: "Access Bank" },
  { code: "000005", name: "Access Bank (Diamond)" },
  { code: "120004", name: "Airtel Smartcash PSB" },
  { code: "035A", name: "ALAT by WEMA" },
  { code: "090001", name: "ASO Savings and Loans" },
  { code: "090148", name: "Bowen Microfinance Bank" },
  { code: "100026", name: "Carbon" },
  { code: "000009", name: "Citibank Nigeria" },
  { code: "060001", name: "Coronation Merchant Bank" },
  { code: "000010", name: "Ecobank Nigeria" },
  { code: "090097", name: "Ekondo Microfinance Bank" },
  { code: "100551", name: "FairMoney Microfinance Bank" },
  { code: "000007", name: "Fidelity Bank" },
  { code: "000016", name: "First Bank of Nigeria" },
  { code: "000003", name: "First City Monument Bank" },
  { code: "400001", name: "FSDH Merchant Bank" },
  { code: "000027", name: "Globus Bank" },
  { code: "000013", name: "Guaranty Trust Bank" },
  { code: "000020", name: "Heritage Bank" },
  { code: "120002", name: "HopePSB" },
  { code: "000006", name: "Jaiz Bank" },
  { code: "000002", name: "Keystone Bank" },
  { code: "090267", name: "Kuda Microfinance Bank" },
  { code: "070007", name: "Living Trust Mortgage Bank" },
  { code: "000029", name: "Lotus Bank" },
  { code: "070019", name: "Mayfresh Mortgage Bank" },
  { code: "090405", name: "Moniepoint Microfinance Bank" },
  { code: "120003", name: "MTN Momo PSB" },
  { code: "100004", name: "OPay" },
  { code: "100002", name: "Paga" },
  { code: "100033", name: "PalmPay" },
  { code: "000030", name: "Parallex Bank" },
  { code: "100003", name: "Parkway - ReadyCash" },
  { code: "100039", name: "Paystack-Titan MFB" },
  { code: "090165", name: "Petra Microfinance Bank" },
  { code: "000008", name: "Polaris Bank" },
  { code: "000031", name: "PremiumTrust Bank" },
  { code: "000023", name: "Providus Bank" },
  { code: "000024", name: "Rand Merchant Bank" },
  { code: "090125", name: "Rubies MFB" },
  { code: "090286", name: "Safe Haven Microfinance Bank" },
  { code: "090325", name: "Sparkle Microfinance Bank" },
  { code: "000012", name: "Stanbic IBTC Bank" },
  { code: "000021", name: "Standard Chartered Bank" },
  { code: "000001", name: "Sterling Bank" },
  { code: "000022", name: "SunTrust Bank" },
  { code: "000026", name: "TAJ Bank" },
  { code: "090426", name: "Tangerine Money" },
  { code: "090115", name: "TCF MFB" },
  { code: "000025", name: "Titan Trust Bank" },
  { code: "000018", name: "Union Bank of Nigeria" },
  { code: "000004", name: "United Bank For Africa" },
  { code: "000011", name: "Unity Bank" },
  { code: "090110", name: "VFD Microfinance Bank" },
  { code: "000017", name: "Wema Bank" },
  { code: "000015", name: "Zenith Bank" },
].sort((a, b) => a.name.localeCompare(b.name));

export const getBankNameByCode = (code: string): string => {
  const bank = nigerianBanks.find(b => b.code === code);
  return bank?.name || "Unknown Bank";
};
