 import { useState, useRef, useCallback } from "react";
 import { Button } from "@/components/ui/button";
 import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
 import { Input } from "@/components/ui/input";
 import { Label } from "@/components/ui/label";
 import { Slider } from "@/components/ui/slider";
 import { toast } from "sonner";
 import { supabase } from "@/integrations/supabase/client";
 import { Loader2, Upload, Video, Image as ImageIcon, Wand2, X } from "lucide-react";
 
 interface GifMakerProps {
   onGifCreated: (gifUrl: string) => void;
   userId?: string;
   productId?: string;
 }
 
 export const GifMaker = ({ onGifCreated, userId, productId }: GifMakerProps) => {
   const [mode, setMode] = useState<"video" | "images" | null>(null);
   const [images, setImages] = useState<string[]>([]);
   const [videoFile, setVideoFile] = useState<File | null>(null);
   const [gifPreview, setGifPreview] = useState<string | null>(null);
   const [creating, setCreating] = useState(false);
   const [interval, setIntervalTime] = useState(500);
   const fileInputRef = useRef<HTMLInputElement>(null);
   const videoInputRef = useRef<HTMLInputElement>(null);
 
   const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
     const files = e.target.files;
     if (!files) return;
 
     const newImages: string[] = [];
     for (let i = 0; i < Math.min(files.length, 10); i++) {
       const file = files[i];
       const reader = new FileReader();
       reader.onload = () => {
         if (typeof reader.result === "string") {
           newImages.push(reader.result);
           if (newImages.length === Math.min(files.length, 10)) {
             setImages((prev) => [...prev, ...newImages].slice(0, 10));
           }
         }
       };
       reader.readAsDataURL(file);
     }
   };
 
   const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
     const file = e.target.files?.[0];
     if (file) {
       if (file.size > 10 * 1024 * 1024) {
         toast.error("Video must be less than 10MB");
         return;
       }
       setVideoFile(file);
     }
   };
 
   const createGifFromImages = useCallback(async () => {
     if (images.length < 2) {
       toast.error("Please add at least 2 images");
       return;
     }
 
     setCreating(true);
     try {
       // Import gifshot dynamically
       const gifshot = await import("gifshot");
       
       gifshot.createGIF(
         {
           images,
           gifWidth: 400,
           gifHeight: 400,
           interval: interval / 1000,
           numFrames: images.length,
         },
         async (obj: { error: string | false; image: string }) => {
           if (obj.error) {
             toast.error("Failed to create GIF");
             setCreating(false);
             return;
           }
 
           // Upload GIF to storage
           const blob = await fetch(obj.image).then((r) => r.blob());
           const fileName = `${userId || "anon"}/${productId || "new"}/${Date.now()}.gif`;
 
           const { error: uploadError } = await supabase.storage
             .from("products")
             .upload(fileName, blob, { contentType: "image/gif" });
 
           if (uploadError) {
             toast.error("Failed to upload GIF");
             setCreating(false);
             return;
           }
 
           const { data: urlData } = supabase.storage
             .from("products")
             .getPublicUrl(fileName);
 
           setGifPreview(urlData.publicUrl);
           onGifCreated(urlData.publicUrl);
           toast.success("GIF created successfully!");
           setCreating(false);
         }
       );
     } catch (error) {
       console.error("GIF creation error:", error);
       toast.error("Failed to create GIF");
       setCreating(false);
     }
   }, [images, interval, userId, productId, onGifCreated]);
 
   const createGifFromVideo = useCallback(async () => {
     if (!videoFile) {
       toast.error("Please select a video");
       return;
     }
 
     setCreating(true);
     try {
       const gifshot = await import("gifshot");
       const videoUrl = URL.createObjectURL(videoFile);
 
       gifshot.createGIF(
         {
           video: [videoUrl],
           gifWidth: 400,
           gifHeight: 400,
           numFrames: 10,
           interval: 0.1,
         },
         async (obj: { error: string | false; image: string }) => {
           URL.revokeObjectURL(videoUrl);
 
           if (obj.error) {
             toast.error("Failed to create GIF from video");
             setCreating(false);
             return;
           }
 
           const blob = await fetch(obj.image).then((r) => r.blob());
           const fileName = `${userId || "anon"}/${productId || "new"}/${Date.now()}.gif`;
 
           const { error: uploadError } = await supabase.storage
             .from("products")
             .upload(fileName, blob, { contentType: "image/gif" });
 
           if (uploadError) {
             toast.error("Failed to upload GIF");
             setCreating(false);
             return;
           }
 
           const { data: urlData } = supabase.storage
             .from("products")
             .getPublicUrl(fileName);
 
           setGifPreview(urlData.publicUrl);
           onGifCreated(urlData.publicUrl);
           toast.success("GIF created from video!");
           setCreating(false);
         }
       );
     } catch (error) {
       console.error("GIF from video error:", error);
       toast.error("Failed to process video");
       setCreating(false);
     }
   }, [videoFile, userId, productId, onGifCreated]);
 
   const reset = () => {
     setMode(null);
     setImages([]);
     setVideoFile(null);
     setGifPreview(null);
   };
 
   if (gifPreview) {
     return (
       <Card>
         <CardHeader>
           <CardTitle className="flex items-center gap-2">
             <Wand2 className="h-5 w-5" />
             GIF Created
           </CardTitle>
         </CardHeader>
         <CardContent className="space-y-4">
           <div className="relative aspect-square max-w-[300px] mx-auto rounded-lg overflow-hidden bg-muted">
             <img src={gifPreview} alt="Created GIF" className="w-full h-full object-cover" />
           </div>
           <Button variant="outline" onClick={reset} className="w-full">
             Create Another
           </Button>
         </CardContent>
       </Card>
     );
   }
 
   if (!mode) {
     return (
       <Card>
         <CardHeader>
           <CardTitle className="flex items-center gap-2">
             <Wand2 className="h-5 w-5" />
             Create Product GIF
           </CardTitle>
         </CardHeader>
         <CardContent>
           <div className="grid grid-cols-2 gap-4">
             <Button
               variant="outline"
               className="h-24 flex-col gap-2"
               onClick={() => setMode("images")}
             >
               <ImageIcon className="h-8 w-8" />
               <span>From Images</span>
             </Button>
             <Button
               variant="outline"
               className="h-24 flex-col gap-2"
               onClick={() => setMode("video")}
             >
               <Video className="h-8 w-8" />
               <span>From Video</span>
             </Button>
           </div>
         </CardContent>
       </Card>
     );
   }
 
   return (
     <Card>
       <CardHeader>
         <CardTitle className="flex items-center justify-between">
           <span className="flex items-center gap-2">
             <Wand2 className="h-5 w-5" />
             {mode === "images" ? "Create from Images" : "Create from Video"}
           </span>
           <Button variant="ghost" size="icon" onClick={reset}>
             <X className="h-4 w-4" />
           </Button>
         </CardTitle>
       </CardHeader>
       <CardContent className="space-y-4">
         {mode === "images" && (
           <>
             <div className="grid grid-cols-5 gap-2">
               {images.map((img, i) => (
                 <div key={i} className="relative aspect-square rounded-lg overflow-hidden bg-muted">
                   <img src={img} alt="" className="w-full h-full object-cover" />
                   <button
                     onClick={() => setImages(images.filter((_, idx) => idx !== i))}
                     className="absolute top-1 right-1 p-1 rounded-full bg-background/80"
                   >
                     <X className="h-3 w-3" />
                   </button>
                 </div>
               ))}
               {images.length < 10 && (
                 <button
                   onClick={() => fileInputRef.current?.click()}
                   className="aspect-square rounded-lg border-2 border-dashed border-muted-foreground/30 flex items-center justify-center hover:border-primary transition-colors"
                 >
                   <Upload className="h-5 w-5 text-muted-foreground" />
                 </button>
               )}
             </div>
             <input
               ref={fileInputRef}
               type="file"
               accept="image/*"
               multiple
               className="hidden"
               onChange={handleImageUpload}
             />
 
             <div className="space-y-2">
               <Label>Frame Interval: {interval}ms</Label>
               <Slider
                 value={[interval]}
                 onValueChange={(v) => setIntervalTime(v[0])}
                 min={100}
                 max={2000}
                 step={100}
               />
             </div>
 
             <Button
               onClick={createGifFromImages}
               disabled={creating || images.length < 2}
               className="w-full gap-2"
             >
               {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
               Create GIF
             </Button>
           </>
         )}
 
         {mode === "video" && (
           <>
             {videoFile ? (
               <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
                 <video
                   src={URL.createObjectURL(videoFile)}
                   className="w-full h-full object-cover"
                   controls
                 />
                 <button
                   onClick={() => setVideoFile(null)}
                   className="absolute top-2 right-2 p-1 rounded-full bg-background/80"
                 >
                   <X className="h-4 w-4" />
                 </button>
               </div>
             ) : (
               <button
                 onClick={() => videoInputRef.current?.click()}
                 className="w-full aspect-video rounded-lg border-2 border-dashed border-muted-foreground/30 flex flex-col items-center justify-center gap-2 hover:border-primary transition-colors"
               >
                 <Video className="h-8 w-8 text-muted-foreground" />
                 <span className="text-sm text-muted-foreground">Upload video (max 10MB)</span>
               </button>
             )}
             <input
               ref={videoInputRef}
               type="file"
               accept="video/*"
               className="hidden"
               onChange={handleVideoUpload}
             />
 
             <Button
               onClick={createGifFromVideo}
               disabled={creating || !videoFile}
               className="w-full gap-2"
             >
               {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
               Create GIF from Video
             </Button>
           </>
         )}
       </CardContent>
     </Card>
   );
 };