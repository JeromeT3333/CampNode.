 import { useState, useEffect, useCallback } from "react";
 import { ImageOff } from "lucide-react";
 import { cn } from "@/lib/utils";
 
 interface ProductImageWithGifProps {
   mainImage: string | null;
   gifUrl?: string | null;
   name: string;
   className?: string;
   interval?: number; // milliseconds to show each
 }
 
 export const ProductImageWithGif = ({
   mainImage,
   gifUrl,
   name,
   className,
   interval = 3000,
 }: ProductImageWithGifProps) => {
   const [showGif, setShowGif] = useState(false);
   const [imageError, setImageError] = useState(false);
   const [gifError, setGifError] = useState(false);
 
   useEffect(() => {
     if (!gifUrl || gifError) return;
 
     const timer = setInterval(() => {
       setShowGif((prev) => !prev);
     }, interval);
 
     return () => clearInterval(timer);
   }, [gifUrl, interval, gifError]);
 
   const handleMainError = () => setImageError(true);
   const handleGifError = () => {
     setGifError(true);
     setShowGif(false);
   };
 
   const currentSrc = showGif && gifUrl && !gifError ? gifUrl : mainImage;
 
   if (!currentSrc || (imageError && (!gifUrl || gifError))) {
     return (
       <div className={cn("flex items-center justify-center bg-muted", className)}>
         <ImageOff className="h-8 w-8 text-muted-foreground" />
       </div>
     );
   }
 
   return (
     <div className={cn("relative overflow-hidden", className)}>
       <img
         src={currentSrc}
         alt={name}
         className="w-full h-full object-cover transition-opacity duration-300"
         onError={showGif ? handleGifError : handleMainError}
       />
       {gifUrl && !gifError && (
         <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-full bg-background/80 text-xs font-medium">
           {showGif ? "GIF" : "Photo"}
         </div>
       )}
     </div>
   );
 };