import { useState, useRef } from "react";
import { cn } from "@/lib/utils";
import { 
  Play, Pause, Check, CheckCheck, FileIcon, Download, 
  Pin, Clock, AlertCircle, RotateCcw, Reply as ReplyIcon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { WhatsAppContextMenu, MessageReactions } from "./MessageContextMenu";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Reaction {
  emoji: string;
  user_id: string;
  message_id: string;
}

interface ModernChatBubbleProps {
  id: string;
  content: string | null;
  messageType: "text" | "image" | "voice" | "sticker" | "file";
  attachmentUrl: string | null;
  isOwnMessage: boolean;
  createdAt: string;
  isRead?: boolean | null;
  isPinned?: boolean | null;
  isDeleted?: boolean | null;
  reactions?: Reaction[];
  currentUserId: string;
  conversationId?: string;
  isPending?: boolean;
  isFailed?: boolean;
  onRetry?: () => void;
  onReply?: (messageId: string, content: string) => void;
  onForward?: (content: string, attachmentUrl: string | null) => void;
  replyToContent?: string;
  replyToSender?: string;
  searchQuery?: string;
}

export const ModernChatBubble = ({
  id,
  content,
  messageType,
  attachmentUrl,
  isOwnMessage,
  createdAt,
  isRead,
  isPinned,
  isDeleted,
  reactions = [],
  currentUserId,
  conversationId,
  isPending,
  isFailed,
  onRetry,
  onReply,
  onForward,
  replyToContent,
  replyToSender,
  searchQuery = "",
}: ModernChatBubbleProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioDuration, setAudioDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString("en-NG", {
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const isEditable = isOwnMessage && 
    messageType === "text" && 
    (new Date().getTime() - new Date(createdAt).getTime()) < 15 * 60 * 1000;

  const handlePlayPause = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleReact = async (emoji: string) => {
    if (!conversationId) return;
    try {
      const existingReaction = reactions.find(
        r => r.user_id === currentUserId && r.emoji === emoji
      );

      if (existingReaction) {
        await supabase
          .from("message_reactions")
          .delete()
          .eq("message_id", id)
          .eq("user_id", currentUserId)
          .eq("emoji", emoji);
      } else {
        await supabase.from("message_reactions").insert({
          message_id: id,
          user_id: currentUserId,
          emoji
        });
      }
    } catch (error) {
      console.error("Failed to react:", error);
    }
  };

  const handlePin = async () => {
    try {
      await supabase
        .from("messages")
        .update({ is_pinned: !isPinned })
        .eq("id", id);
      toast.success(isPinned ? "Message unpinned" : "Message pinned");
    } catch (error) {
      toast.error("Failed to update message");
    }
  };

  const handleDelete = async () => {
    try {
      await supabase
        .from("messages")
        .update({ is_deleted: true, content: "This message was deleted" })
        .eq("id", id);
      toast.success("Message deleted");
    } catch (error) {
      toast.error("Failed to delete message");
    }
  };

  const handleCopy = () => {
    if (content) {
      navigator.clipboard.writeText(content);
      toast.success("Copied to clipboard");
    }
  };

  const handleEdit = async (newContent: string) => {
    try {
      await supabase
        .from("messages")
        .update({ content: newContent })
        .eq("id", id);
      toast.success("Message edited");
    } catch (error) {
      toast.error("Failed to edit message");
    }
  };

  const handleSaveMedia = () => {
    if (attachmentUrl) {
      const link = document.createElement("a");
      link.href = attachmentUrl;
      link.download = content || "download";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success("Download started");
    }
  };

  const handleReply = () => {
    if (onReply) {
      onReply(id, content || "");
    }
  };

  const handleForward = () => {
    if (onForward) {
      onForward(content || "", attachmentUrl);
    }
  };

  const groupedReactions = reactions.reduce((acc, r) => {
    const existing = acc.find(a => a.emoji === r.emoji);
    if (existing) {
      existing.count++;
      if (r.user_id === currentUserId) existing.hasReacted = true;
    } else {
      acc.push({
        emoji: r.emoji,
        count: 1,
        hasReacted: r.user_id === currentUserId
      });
    }
    return acc;
  }, [] as Array<{ emoji: string; count: number; hasReacted: boolean }>);

  const parseFormatting = (text: string) => {
    let formatted = text
      .replace(/\*([^*]+)\*/g, '<strong>$1</strong>')
      .replace(/_([^_]+)_/g, '<em>$1</em>');
    
    // Highlight search matches
    if (searchQuery.trim()) {
      const regex = new RegExp(`(${searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      formatted = formatted.replace(regex, '<mark class="bg-yellow-300 dark:bg-yellow-600 text-foreground rounded px-0.5">$1</mark>');
    }
    
    return formatted;
  };

  if (isDeleted) {
    return (
      <div className={cn("flex", isOwnMessage ? "justify-end" : "justify-start")}>
        <div className={cn(
          "px-3 py-1.5 rounded-lg text-xs italic",
          isOwnMessage 
            ? "bg-muted/50 text-muted-foreground" 
            : "bg-muted/30 text-muted-foreground"
        )}>
          🚫 This message was deleted
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (messageType) {
      case "image":
        return (
          <div className="space-y-1">
            {attachmentUrl && (
              <div className="rounded-lg overflow-hidden max-w-[220px]">
                <img
                  src={attachmentUrl}
                  alt="Shared image"
                  className="w-full h-auto object-cover cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={() => window.open(attachmentUrl, "_blank")}
                />
              </div>
            )}
            {content && (
              <p 
                className="break-words text-[13px]"
                dangerouslySetInnerHTML={{ __html: parseFormatting(content) }}
              />
            )}
          </div>
        );

      case "voice":
        return (
          <div className="flex items-center gap-2 min-w-[160px]">
            <audio
              ref={audioRef}
              src={attachmentUrl || ""}
              onEnded={() => { setIsPlaying(false); setCurrentTime(0); }}
              onTimeUpdate={() => audioRef.current && setCurrentTime(audioRef.current.currentTime)}
              onLoadedMetadata={() => audioRef.current && setAudioDuration(audioRef.current.duration)}
              className="hidden"
            />
            <Button
              size="icon"
              variant="ghost"
              className={cn(
                "h-8 w-8 rounded-full flex-shrink-0",
                isOwnMessage
                  ? "bg-white/20 hover:bg-white/30 text-white"
                  : "bg-foreground/10 hover:bg-foreground/20"
              )}
              onClick={handlePlayPause}
            >
              {isPlaying ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3 ml-0.5" />}
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-[2px] h-5">
                {Array.from({ length: 25 }).map((_, i) => (
                  <div
                    key={i}
                    className={cn(
                      "w-[2px] rounded-full transition-all",
                      isOwnMessage ? "bg-white/40" : "bg-foreground/30",
                      i < (currentTime / audioDuration) * 25 && (isOwnMessage ? "bg-white" : "bg-foreground")
                    )}
                    style={{ height: `${Math.random() * 12 + 6}px` }}
                  />
                ))}
              </div>
              <span className={cn(
                "text-[10px]",
                isOwnMessage ? "text-white/70" : "text-muted-foreground"
              )}>
                {formatDuration(isPlaying ? currentTime : audioDuration || 0)}
              </span>
            </div>
          </div>
        );

      case "sticker":
        return <span className="text-4xl">{content}</span>;

      case "file":
        const fileName = content || attachmentUrl?.split("/").pop() || "Document";
        return (
          <a
            href={attachmentUrl || "#"}
            target="_blank"
            rel="noopener noreferrer"
            className={cn(
              "flex items-center gap-2 p-2 rounded-lg transition-colors min-w-[150px]",
              isOwnMessage
                ? "bg-white/10 hover:bg-white/20"
                : "bg-foreground/5 hover:bg-foreground/10"
            )}
          >
            <div className={cn(
              "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
              isOwnMessage ? "bg-white/20" : "bg-foreground/10"
            )}>
              <FileIcon className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium truncate">{fileName}</p>
              <p className="text-[10px] opacity-70">Document</p>
            </div>
            <Download className="h-3 w-3 opacity-70 flex-shrink-0" />
          </a>
        );

      default:
        return (
          <p 
            className="break-words text-[13px] leading-[1.4]"
            dangerouslySetInnerHTML={{ __html: parseFormatting(content || "") }}
          />
        );
    }
  };

  if (messageType === "sticker") {
    return (
      <WhatsAppContextMenu
        messageId={id}
        content={content}
        messageType={messageType}
        attachmentUrl={attachmentUrl}
        isOwnMessage={isOwnMessage}
        isPinned={!!isPinned}
        isEditable={false}
        onReact={handleReact}
        onPin={handlePin}
        onDelete={handleDelete}
        onCopy={handleCopy}
        onReply={onReply ? handleReply : undefined}
        onForward={onForward ? handleForward : undefined}
      >
        <div className={cn("flex flex-col", isOwnMessage ? "items-end" : "items-start")}>
          {isPinned && (
            <div className="flex items-center gap-1 text-[10px] text-primary mb-0.5">
              <Pin className="h-2.5 w-2.5" />
              <span>Pinned</span>
            </div>
          )}
          {renderContent()}
          <MessageReactions reactions={groupedReactions} onReact={handleReact} />
          <div className="flex items-center gap-1 mt-0.5 px-1">
            <span className="text-[10px] text-muted-foreground">{formatTime(createdAt)}</span>
            {isOwnMessage && (
              isPending ? (
                <Clock className="h-3 w-3 text-muted-foreground" />
              ) : isFailed ? (
                <AlertCircle className="h-3 w-3 text-destructive" />
              ) : isRead ? (
                <CheckCheck className="h-3 w-3 text-blue-500" />
              ) : (
                <Check className="h-3 w-3 text-muted-foreground" />
              )
            )}
          </div>
        </div>
      </WhatsAppContextMenu>
    );
  }

  return (
    <WhatsAppContextMenu
      messageId={id}
      content={content}
      messageType={messageType}
      attachmentUrl={attachmentUrl}
      isOwnMessage={isOwnMessage}
      isPinned={!!isPinned}
      isEditable={isEditable}
      onReact={handleReact}
      onPin={handlePin}
      onDelete={handleDelete}
      onCopy={handleCopy}
      onReply={onReply ? handleReply : undefined}
      onForward={onForward ? handleForward : undefined}
      onEdit={isEditable ? handleEdit : undefined}
      onSaveMedia={attachmentUrl ? handleSaveMedia : undefined}
    >
      <div className={cn("flex", isOwnMessage ? "justify-end" : "justify-start")}>
        <div className={cn("max-w-[75%] relative group", isOwnMessage ? "order-2" : "order-1")}>
          {isPinned && (
            <div className="flex items-center gap-1 text-[10px] text-primary mb-0.5">
              <Pin className="h-2.5 w-2.5" />
              <span>Pinned</span>
            </div>
          )}

          <div
            className={cn(
              "px-2.5 py-1.5 rounded-xl shadow-sm",
              isOwnMessage
                ? "bg-[#005c4b] dark:bg-[#005c4b] text-white rounded-tr-sm"
                : "bg-card dark:bg-[#1f2c33] text-foreground rounded-tl-sm",
              isFailed && "opacity-70"
            )}
          >
            {replyToContent && (
              <div className={cn(
                "flex items-start gap-1.5 mb-1 px-2 py-1 rounded border-l-2",
                isOwnMessage 
                  ? "bg-white/10 border-white/50" 
                  : "bg-muted/50 border-primary"
              )}>
                <ReplyIcon className="h-3 w-3 mt-0.5 flex-shrink-0 opacity-70" />
                <div className="min-w-0">
                  {replyToSender && (
                    <span className="text-[10px] font-medium block opacity-80">{replyToSender}</span>
                  )}
                  <span className="text-[11px] opacity-70 line-clamp-1">{replyToContent}</span>
                </div>
              </div>
            )}

            {renderContent()}

            <div className={cn(
              "flex items-center gap-1 mt-0.5",
              isOwnMessage ? "justify-end" : "justify-start"
            )}>
              <span className={cn(
                "text-[10px]",
                isOwnMessage ? "text-white/60" : "text-muted-foreground"
              )}>
                {formatTime(createdAt)}
              </span>
              {isOwnMessage && (
                isPending ? (
                  <Clock className="h-3 w-3 text-white/60" />
                ) : isFailed ? (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0"
                    onClick={onRetry}
                  >
                    <RotateCcw className="h-3 w-3 text-destructive" />
                  </Button>
                ) : isRead ? (
                  <CheckCheck className="h-3 w-3 text-blue-400" />
                ) : (
                  <Check className="h-3 w-3 text-white/60" />
                )
              )}
            </div>
          </div>

          <MessageReactions reactions={groupedReactions} onReact={handleReact} />
        </div>
      </div>
    </WhatsAppContextMenu>
  );
};