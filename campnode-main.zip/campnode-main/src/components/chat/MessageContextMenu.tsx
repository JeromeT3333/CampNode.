import { useState } from "react";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Copy, Pin, Trash2, Reply, SmilePlus, Forward, Edit3, 
  Download, Share2
} from "lucide-react";
import { toast } from "sonner";
import { EmojiPicker } from "./EmojiPicker";

// WhatsApp-style quick reactions
const QUICK_REACTIONS = ["👍", "❤️", "😂", "😮", "😢", "🙏"];

interface WhatsAppContextMenuProps {
  children: React.ReactNode;
  messageId: string;
  content: string | null;
  messageType: "text" | "image" | "voice" | "sticker" | "file";
  attachmentUrl: string | null;
  isOwnMessage: boolean;
  isPinned?: boolean;
  isEditable?: boolean;
  onReact: (emoji: string) => void;
  onPin: () => void;
  onDelete: () => void;
  onCopy: () => void;
  onReply?: () => void;
  onForward?: () => void;
  onEdit?: (newContent: string) => void;
  onSaveMedia?: () => void;
}

export const WhatsAppContextMenu = ({
  children,
  messageId,
  content,
  messageType,
  attachmentUrl,
  isOwnMessage,
  isPinned,
  isEditable,
  onReact,
  onPin,
  onDelete,
  onCopy,
  onReply,
  onForward,
  onEdit,
  onSaveMedia,
}: WhatsAppContextMenuProps) => {
  const [showAllEmojis, setShowAllEmojis] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editedContent, setEditedContent] = useState(content || "");

  const handleShare = async () => {
    if (navigator.share && content) {
      try {
        await navigator.share({
          text: content,
        });
      } catch {
        // User cancelled or share failed
      }
    } else {
      onCopy();
    }
  };

  const handleEditSubmit = () => {
    if (editedContent.trim() && onEdit) {
      onEdit(editedContent.trim());
      setShowEditDialog(false);
      toast.success("Message edited");
    }
  };

  const canSaveMedia = messageType === "image" || messageType === "file" || messageType === "voice";

  return (
    <>
      <ContextMenu>
        <ContextMenuTrigger asChild>{children}</ContextMenuTrigger>
        <ContextMenuContent className="w-52 bg-popover/95 backdrop-blur-sm border-border rounded-xl shadow-xl">
          {/* Quick reactions bar - WhatsApp style */}
          <div className="flex items-center justify-between px-2 py-2 border-b border-border">
            {QUICK_REACTIONS.map((emoji) => (
              <button
                key={emoji}
                className="p-1.5 rounded-full hover:bg-muted transition-all hover:scale-125 active:scale-100"
                onClick={() => onReact(emoji)}
              >
                <span className="text-lg">{emoji}</span>
              </button>
            ))}
            <Popover open={showAllEmojis} onOpenChange={setShowAllEmojis}>
              <PopoverTrigger asChild>
                <button className="p-1.5 rounded-full hover:bg-muted transition-colors">
                  <SmilePlus className="h-4 w-4 text-muted-foreground" />
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-popover/95 backdrop-blur-sm border-border rounded-xl" align="start">
                <EmojiPicker 
                  onEmojiSelect={(emoji) => {
                    onReact(emoji);
                    setShowAllEmojis(false);
                  }}
                  showTrigger={false}
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Reply */}
          {onReply && (
            <ContextMenuItem onClick={onReply} className="gap-2 text-sm">
              <Reply className="h-4 w-4" />
              Reply
            </ContextMenuItem>
          )}

          {/* Forward */}
          {onForward && (
            <ContextMenuItem onClick={onForward} className="gap-2 text-sm">
              <Forward className="h-4 w-4" />
              Forward
            </ContextMenuItem>
          )}

          {/* Copy */}
          {content && messageType === "text" && (
            <ContextMenuItem onClick={onCopy} className="gap-2 text-sm">
              <Copy className="h-4 w-4" />
              Copy
            </ContextMenuItem>
          )}

          {/* Share */}
          {content && (
            <ContextMenuItem onClick={handleShare} className="gap-2 text-sm">
              <Share2 className="h-4 w-4" />
              Share
            </ContextMenuItem>
          )}

          {/* Edit - only for own text messages within 15 mins */}
          {isOwnMessage && isEditable && onEdit && (
            <ContextMenuItem 
              onClick={() => {
                setEditedContent(content || "");
                setShowEditDialog(true);
              }} 
              className="gap-2 text-sm"
            >
              <Edit3 className="h-4 w-4" />
              Edit
            </ContextMenuItem>
          )}

          {/* Save to gallery (for media) */}
          {canSaveMedia && onSaveMedia && (
            <ContextMenuItem onClick={onSaveMedia} className="gap-2 text-sm">
              <Download className="h-4 w-4" />
              Save
            </ContextMenuItem>
          )}

          <ContextMenuSeparator />

          {/* Pin */}
          <ContextMenuItem onClick={onPin} className="gap-2 text-sm">
            <Pin className="h-4 w-4" />
            {isPinned ? "Unpin" : "Pin"}
          </ContextMenuItem>

          {/* Delete - only for own messages */}
          {isOwnMessage && (
            <>
              <ContextMenuSeparator />
              <ContextMenuItem
                onClick={onDelete}
                className="gap-2 text-sm text-destructive focus:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
                Delete
              </ContextMenuItem>
            </>
          )}
        </ContextMenuContent>
      </ContextMenu>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit message</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Input
              value={editedContent}
              onChange={(e) => setEditedContent(e.target.value)}
              placeholder="Edit your message..."
              className="w-full"
              autoFocus
            />
            <p className="text-xs text-muted-foreground">
              You can edit messages within 15 minutes of sending
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditSubmit} disabled={!editedContent.trim()}>
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

interface MessageReactionsProps {
  reactions: Array<{ emoji: string; count: number; hasReacted: boolean }>;
  onReact: (emoji: string) => void;
}

export const MessageReactions = ({ reactions, onReact }: MessageReactionsProps) => {
  if (reactions.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-0.5 mt-0.5 -mb-1">
      {reactions.map(({ emoji, count, hasReacted }) => (
        <button
          key={emoji}
          onClick={() => onReact(emoji)}
          className={`
            inline-flex items-center gap-0.5 px-1 py-0.5 rounded-full text-[10px]
            transition-all border shadow-sm
            ${hasReacted
              ? "bg-primary/20 border-primary/40 text-primary scale-105"
              : "bg-card border-border hover:bg-muted"
            }
          `}
        >
          <span>{emoji}</span>
          <span className="font-medium">{count}</span>
        </button>
      ))}
    </div>
  );
};

// Backward compatibility export
export const MessageContextMenu = WhatsAppContextMenu;
