import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Loader2,
  Send,
  Mic,
  X,
  Square,
  Lock,
  Reply as ReplyIcon
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useVoiceRecorder } from "@/hooks/useVoiceRecorder";
import { toast } from "sonner";
import { StickerPicker } from "./StickerPicker";
import { FileAttachment } from "./FileAttachment";

interface ReplyingTo {
  messageId: string;
  content: string;
  senderName: string;
}

interface ChatInputBarProps {
  isClosed: boolean;
  onSendText: (text: string, replyTo?: ReplyingTo | null) => Promise<void>;
  onSendVoice: (blob: Blob) => Promise<void>;
  onSendImage: (file: File) => Promise<void>;
  onSendSticker?: (sticker: string) => Promise<void>;
  onSendFile?: (file: File) => Promise<void>;
  onTyping?: () => void;
  onSearch?: () => void;
  replyingTo?: ReplyingTo | null;
  onCancelReply?: () => void;
  isOffline?: boolean;
  onRecordingChange?: (isRecording: boolean) => void;
}

export const ChatInputBar = ({
  isClosed,
  onSendText,
  onSendVoice,
  onSendImage,
  onSendSticker,
  onSendFile,
  onTyping,
  onSearch,
  replyingTo,
  onCancelReply,
  isOffline,
  onRecordingChange,
}: ChatInputBarProps) => {
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  const {
    isRecording,
    recordingDuration,
    startRecording,
    stopRecording,
    cancelRecording
  } = useVoiceRecorder();

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNewMessage(e.target.value);
    onTyping?.();
    
    // Auto-resize textarea without causing layout shifts
    if (textareaRef.current) {
      // Use requestAnimationFrame to batch DOM updates
      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.style.height = 'auto';
          const newHeight = Math.min(textareaRef.current.scrollHeight, 120);
          textareaRef.current.style.height = newHeight + 'px';
        }
      });
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    setSending(true);
    try {
      await onSendText(newMessage.trim(), replyingTo);
      setNewMessage("");
      onCancelReply?.();
      
      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    } catch (error) {
      if (!isOffline) {
        toast.error("Failed to send message");
      }
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage(e);
    }
  };

  const handleStartRecording = async () => {
    try {
      await startRecording();
      onRecordingChange?.(true);
    } catch (error) {
      toast.error("Failed to access microphone. Please allow microphone access.");
    }
  };

  const handleStopRecording = async () => {
    setSending(true);
    onRecordingChange?.(false);
    try {
      const audioBlob = await stopRecording();
      if (audioBlob) {
        await onSendVoice(audioBlob);
      }
    } catch (error) {
      toast.error("Failed to send voice message");
    } finally {
      setSending(false);
    }
  };

  const handleCancelRecording = () => {
    cancelRecording();
    onRecordingChange?.(false);
  };

  const handleStickerSelect = async (sticker: string) => {
    if (!onSendSticker) {
      setSending(true);
      try {
        await onSendText(sticker);
      } catch (error) {
        toast.error("Failed to send sticker");
      } finally {
        setSending(false);
      }
      return;
    }

    setSending(true);
    try {
      await onSendSticker(sticker);
    } catch (error) {
      toast.error("Failed to send sticker");
    } finally {
      setSending(false);
    }
  };

  const handleFileSelect = async (file: File, type: "image" | "file") => {
    setSending(true);
    try {
      if (type === "image") {
        await onSendImage(file);
      } else if (onSendFile) {
        await onSendFile(file);
      } else {
        await onSendImage(file);
      }
    } catch (error) {
      toast.error("Failed to send file");
    } finally {
      setSending(false);
    }
  };

  if (isClosed) {
    return (
      <div className="sticky bottom-0 bg-background/95 backdrop-blur-sm border-t border-border px-3 py-2">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-center gap-2 py-2 text-muted-foreground text-sm">
            <Lock className="h-4 w-4" />
            <span>This conversation has been closed</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="sticky bottom-0 bg-background/95 backdrop-blur-sm border-t border-border px-2 py-2 will-change-transform">
      <div className="max-w-2xl mx-auto transform-gpu">
        {/* Offline indicator */}
        {isOffline && (
          <div className="flex items-center justify-center gap-1 py-1 mb-1 text-xs text-amber-600 dark:text-amber-400">
            <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            Offline - messages will send when connected
          </div>
        )}

        {/* Reply preview */}
        {replyingTo && (
          <div className="flex items-center gap-2 mb-2 px-2 py-1.5 bg-muted/50 rounded-lg border-l-2 border-primary">
            <ReplyIcon className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <span className="text-xs font-medium text-primary block">{replyingTo.senderName}</span>
              <span className="text-xs text-muted-foreground truncate block">{replyingTo.content}</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 flex-shrink-0"
              onClick={onCancelReply}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        )}

        {isRecording ? (
          // Recording UI - more compact
          <div className="flex items-center gap-2 py-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleCancelRecording}
              className="h-8 w-8 text-destructive hover:text-destructive"
            >
              <X className="h-4 w-4" />
            </Button>
            <div className="flex-1 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
              <span className="text-xs font-medium">{formatDuration(recordingDuration)}</span>
              <div className="flex-1 flex items-center gap-0.5">
                {Array.from({ length: 24 }).map((_, i) => (
                  <div
                    key={i}
                    className="w-0.5 bg-primary rounded-full animate-pulse"
                    style={{
                      height: `${Math.random() * 16 + 4}px`,
                      animationDelay: `${i * 50}ms`
                    }}
                  />
                ))}
              </div>
            </div>
            <Button
              onClick={handleStopRecording}
              disabled={sending}
              size="icon"
              className="h-8 w-8 bg-primary"
            >
              {sending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Square className="h-3 w-3" />
              )}
            </Button>
          </div>
        ) : (
          // Normal input UI - WhatsApp style compact
          <form onSubmit={handleSendMessage} className="flex items-end gap-1">
            <div className="flex items-center gap-0.5">
              <StickerPicker 
                onStickerSelect={handleStickerSelect}
                disabled={sending}
              />
              <FileAttachment 
                onFileSelect={handleFileSelect}
                disabled={sending}
              />
            </div>
            
            <div className="flex-1 flex items-end bg-muted/50 rounded-2xl px-3 py-1">
              <Textarea
                ref={textareaRef}
                value={newMessage}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder="Message"
                disabled={sending}
                rows={1}
                className="flex-1 bg-transparent border-none resize-none min-h-[32px] max-h-[120px] py-1.5 px-0 text-sm focus-visible:ring-0 focus-visible:ring-offset-0"
              />
            </div>
            
            {newMessage.trim() ? (
              <Button 
                type="submit" 
                disabled={sending} 
                size="icon"
                className="h-9 w-9 rounded-full bg-primary flex-shrink-0"
              >
                {sending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            ) : (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={handleStartRecording}
                disabled={sending}
                className="h-9 w-9 rounded-full flex-shrink-0 hover:bg-primary hover:text-primary-foreground"
              >
                <Mic className="h-5 w-5" />
              </Button>
            )}
          </form>
        )}
      </div>
    </div>
  );
};
