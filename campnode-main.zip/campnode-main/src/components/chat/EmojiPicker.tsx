import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { SmilePlus } from "lucide-react";
import { Input } from "@/components/ui/input";

interface EmojiPickerProps {
  onEmojiSelect: (emoji: string) => void;
  disabled?: boolean;
  triggerClassName?: string;
  showTrigger?: boolean;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

// Common emojis organized by category
const EMOJI_CATEGORIES = {
  recent: ["👍", "❤️", "😂", "😮", "😢", "🙏", "🔥", "💯"],
  smileys: ["😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂", "🙂", "😊", "😇", "🥰", "😍", "🤩", "😘", "😋", "😛", "🤔", "🤭", "🤫", "🤥", "😶", "😏", "😒", "🙄", "😬", "😮‍💨", "🤤", "😪", "😴", "😷", "🤒", "🤕"],
  gestures: ["👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤌", "🤏", "✌️", "🤞", "🤟", "🤘", "🤙", "👈", "👉", "👆", "🖕", "👇", "☝️", "👍", "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🙏"],
  hearts: ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝"],
  objects: ["🎉", "🎊", "🎁", "🏆", "🥇", "🎯", "💡", "📱", "💻", "🎮", "🎧", "📷", "🎬", "🎵", "🎹", "⚽", "🏀", "🎾"],
  symbols: ["✅", "❌", "❓", "❗", "💯", "🔥", "⭐", "✨", "💫", "🌟", "💥", "💢", "💤", "💬", "👁️‍🗨️", "🗯️", "💭", "🕳️"]
};

export const EmojiPicker = ({ 
  onEmojiSelect, 
  disabled,
  triggerClassName,
  showTrigger = true,
  open: controlledOpen,
  onOpenChange: controlledOnOpenChange
}: EmojiPickerProps) => {
  const [internalOpen, setInternalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<keyof typeof EMOJI_CATEGORIES>("recent");
  const inputRef = useRef<HTMLInputElement>(null);

  const isControlled = controlledOpen !== undefined;
  const open = isControlled ? controlledOpen : internalOpen;
  const setOpen = isControlled ? controlledOnOpenChange! : setInternalOpen;

  // Focus input when opened
  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open]);

  const handleEmojiClick = (emoji: string) => {
    onEmojiSelect(emoji);
    setOpen(false);
    setSearchQuery("");
  };

  // Filter emojis based on search (simple matching)
  const getFilteredEmojis = () => {
    if (!searchQuery.trim()) {
      return EMOJI_CATEGORIES[selectedCategory];
    }
    // When searching, show all emojis that might match
    const allEmojis = Object.values(EMOJI_CATEGORIES).flat();
    return [...new Set(allEmojis)];
  };

  const categories = Object.keys(EMOJI_CATEGORIES) as (keyof typeof EMOJI_CATEGORIES)[];
  const categoryLabels: Record<keyof typeof EMOJI_CATEGORIES, string> = {
    recent: "Recent",
    smileys: "Smileys",
    gestures: "Gestures", 
    hearts: "Hearts",
    objects: "Objects",
    symbols: "Symbols"
  };

  const content = (
    <div className="w-72">
      {/* Search */}
      <div className="p-2 border-b border-border">
        <Input
          ref={inputRef}
          placeholder="Search emoji..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="h-8 text-sm"
        />
      </div>

      {/* Category tabs */}
      {!searchQuery && (
        <div className="flex gap-1 p-1 border-b border-border overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2 py-1 text-xs rounded whitespace-nowrap transition-colors ${
                selectedCategory === cat 
                  ? "bg-primary text-primary-foreground" 
                  : "hover:bg-muted text-muted-foreground"
              }`}
            >
              {categoryLabels[cat]}
            </button>
          ))}
        </div>
      )}

      {/* Emoji grid */}
      <div className="p-2 max-h-48 overflow-y-auto">
        <div className="grid grid-cols-8 gap-0.5">
          {getFilteredEmojis().map((emoji, idx) => (
            <button
              key={`${emoji}-${idx}`}
              onClick={() => handleEmojiClick(emoji)}
              className="w-8 h-8 flex items-center justify-center text-xl hover:bg-muted rounded transition-all hover:scale-110"
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>

      {/* Hint for native keyboard */}
      <div className="px-2 py-1.5 border-t border-border bg-muted/50">
        <p className="text-[10px] text-muted-foreground text-center">
          Tip: Use your device's emoji keyboard for more options
        </p>
      </div>
    </div>
  );

  if (!showTrigger) {
    return content;
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button 
          type="button" 
          variant="ghost" 
          size="icon" 
          disabled={disabled}
          className={triggerClassName}
        >
          <SmilePlus className="h-5 w-5" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start" side="top">
        {content}
      </PopoverContent>
    </Popover>
  );
};