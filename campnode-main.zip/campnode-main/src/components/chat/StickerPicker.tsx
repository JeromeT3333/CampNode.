import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Smile } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { EmojiPicker } from "./EmojiPicker";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface Sticker {
  id: string;
  url: string;
  emoji: string | null;
}

interface StickerPickerProps {
  onStickerSelect: (sticker: string) => void;
  disabled?: boolean;
}

export const StickerPicker = ({ onStickerSelect, disabled }: StickerPickerProps) => {
  const [open, setOpen] = useState(false);
  const [stickers, setStickers] = useState<Sticker[]>([]);
  const [activeTab, setActiveTab] = useState("emoji");

  useEffect(() => {
    const fetchStickers = async () => {
      const { data } = await supabase
        .from("stickers")
        .select("*")
        .order("created_at", { ascending: true });
      
      if (data) {
        setStickers(data);
      }
    };

    fetchStickers();
  }, []);

  const handleStickerClick = (sticker: Sticker) => {
    onStickerSelect(sticker.emoji || sticker.url);
    setOpen(false);
  };

  const handleEmojiSelect = (emoji: string) => {
    onStickerSelect(emoji);
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button 
          type="button" 
          variant="ghost" 
          size="icon" 
          disabled={disabled}
          className="flex-shrink-0"
        >
          <Smile className="h-5 w-5" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="start" side="top">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-2 h-9">
            <TabsTrigger value="emoji" className="text-xs">Emoji</TabsTrigger>
            <TabsTrigger value="stickers" className="text-xs">Stickers</TabsTrigger>
          </TabsList>
          
          <TabsContent value="emoji" className="m-0">
            <EmojiPicker 
              onEmojiSelect={handleEmojiSelect}
              showTrigger={false}
            />
          </TabsContent>
          
          <TabsContent value="stickers" className="m-0 p-2">
            {stickers.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground text-sm">
                No stickers available
              </div>
            ) : (
              <div className="grid grid-cols-4 gap-2 max-h-48 overflow-y-auto">
                {stickers.map((sticker) => (
                  <button
                    key={sticker.id}
                    onClick={() => handleStickerClick(sticker)}
                    className="aspect-square flex items-center justify-center text-3xl hover:bg-muted rounded-lg transition-colors"
                  >
                    {sticker.emoji || "😊"}
                  </button>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </PopoverContent>
    </Popover>
  );
};