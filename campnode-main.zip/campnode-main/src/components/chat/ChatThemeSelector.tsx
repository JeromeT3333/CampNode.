import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Palette, Check } from "lucide-react";
import { cn } from "@/lib/utils";

export interface ChatTheme {
  id: string;
  name: string;
  ownBubble: string;
  otherBubble: string;
  ownText: string;
  otherText: string;
  background: string;
}

export const chatThemes: ChatTheme[] = [
  {
    id: "default",
    name: "Default",
    ownBubble: "bg-primary",
    otherBubble: "bg-muted",
    ownText: "text-primary-foreground",
    otherText: "text-foreground",
    background: "bg-background",
  },
  {
    id: "ocean",
    name: "Ocean",
    ownBubble: "bg-blue-500",
    otherBubble: "bg-blue-100 dark:bg-blue-900",
    ownText: "text-white",
    otherText: "text-blue-900 dark:text-blue-100",
    background: "bg-gradient-to-b from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950",
  },
  {
    id: "sunset",
    name: "Sunset",
    ownBubble: "bg-gradient-to-r from-orange-500 to-pink-500",
    otherBubble: "bg-orange-100 dark:bg-orange-900",
    ownText: "text-white",
    otherText: "text-orange-900 dark:text-orange-100",
    background: "bg-gradient-to-b from-orange-50 to-pink-50 dark:from-orange-950 dark:to-pink-950",
  },
  {
    id: "forest",
    name: "Forest",
    ownBubble: "bg-green-600",
    otherBubble: "bg-green-100 dark:bg-green-900",
    ownText: "text-white",
    otherText: "text-green-900 dark:text-green-100",
    background: "bg-gradient-to-b from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950",
  },
  {
    id: "midnight",
    name: "Midnight",
    ownBubble: "bg-purple-600",
    otherBubble: "bg-purple-100 dark:bg-purple-900",
    ownText: "text-white",
    otherText: "text-purple-900 dark:text-purple-100",
    background: "bg-gradient-to-b from-purple-50 to-indigo-50 dark:from-purple-950 dark:to-indigo-950",
  },
  {
    id: "candy",
    name: "Candy",
    ownBubble: "bg-gradient-to-r from-pink-500 to-rose-500",
    otherBubble: "bg-pink-100 dark:bg-pink-900",
    ownText: "text-white",
    otherText: "text-pink-900 dark:text-pink-100",
    background: "bg-gradient-to-b from-pink-50 to-rose-50 dark:from-pink-950 dark:to-rose-950",
  },
  {
    id: "coffee",
    name: "Coffee",
    ownBubble: "bg-amber-700",
    otherBubble: "bg-amber-100 dark:bg-amber-900",
    ownText: "text-white",
    otherText: "text-amber-900 dark:text-amber-100",
    background: "bg-gradient-to-b from-amber-50 to-yellow-50 dark:from-amber-950 dark:to-yellow-950",
  },
  {
    id: "lavender",
    name: "Lavender",
    ownBubble: "bg-violet-500",
    otherBubble: "bg-violet-100 dark:bg-violet-900",
    ownText: "text-white",
    otherText: "text-violet-900 dark:text-violet-100",
    background: "bg-gradient-to-b from-violet-50 to-fuchsia-50 dark:from-violet-950 dark:to-fuchsia-950",
  },
  {
    id: "crimson",
    name: "Crimson",
    ownBubble: "bg-red-600",
    otherBubble: "bg-red-100 dark:bg-red-900",
    ownText: "text-white",
    otherText: "text-red-900 dark:text-red-100",
    background: "bg-gradient-to-b from-red-50 to-rose-50 dark:from-red-950 dark:to-rose-950",
  },
  {
    id: "slate",
    name: "Slate",
    ownBubble: "bg-slate-700",
    otherBubble: "bg-slate-200 dark:bg-slate-800",
    ownText: "text-white",
    otherText: "text-slate-900 dark:text-slate-100",
    background: "bg-gradient-to-b from-slate-100 to-slate-200 dark:from-slate-900 dark:to-slate-800",
  },
  {
    id: "teal",
    name: "Teal",
    ownBubble: "bg-teal-600",
    otherBubble: "bg-teal-100 dark:bg-teal-900",
    ownText: "text-white",
    otherText: "text-teal-900 dark:text-teal-100",
    background: "bg-gradient-to-b from-teal-50 to-cyan-50 dark:from-teal-950 dark:to-cyan-950",
  },
  {
    id: "gold",
    name: "Gold",
    ownBubble: "bg-gradient-to-r from-yellow-500 to-amber-500",
    otherBubble: "bg-yellow-100 dark:bg-yellow-900",
    ownText: "text-white",
    otherText: "text-yellow-900 dark:text-yellow-100",
    background: "bg-gradient-to-b from-yellow-50 to-amber-50 dark:from-yellow-950 dark:to-amber-950",
  },
];

interface ChatThemeSelectorProps {
  currentTheme: string;
  onThemeChange: (themeId: string) => void;
}

export const ChatThemeSelector = ({
  currentTheme,
  onThemeChange,
}: ChatThemeSelectorProps) => {
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Palette className="h-4 w-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-3" align="end">
        <div className="space-y-2">
          <h4 className="font-medium text-sm">Chat Theme</h4>
          <div className="grid grid-cols-4 gap-2">
            {chatThemes.map((theme) => (
              <button
                key={theme.id}
                onClick={() => {
                  onThemeChange(theme.id);
                  setOpen(false);
                }}
                className={cn(
                  "relative w-12 h-12 rounded-lg overflow-hidden border-2 transition-all",
                  currentTheme === theme.id
                    ? "border-primary ring-2 ring-primary/20"
                    : "border-transparent hover:border-muted-foreground/30"
                )}
                title={theme.name}
              >
                <div className={cn("absolute inset-0", theme.background)} />
                <div className={cn("absolute top-1 right-1 w-4 h-2 rounded-full", theme.ownBubble)} />
                <div className={cn("absolute bottom-1 left-1 w-4 h-2 rounded-full", theme.otherBubble)} />
                {currentTheme === theme.id && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};