import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, User, MoreVertical, Search, X, MessageCircle, ShoppingBag, MapPin } from "lucide-react";
import { OnlineStatus, OnlineIndicatorBadge } from "./OnlineStatus";
import { ChatThemeSelector } from "./ChatThemeSelector";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

interface UserProfile {
  full_name: string | null;
  avatar_url: string | null;
  campus_location: string | null;
  department: string | null;
  phone: string | null;
}

interface ChatHeaderProps {
  otherUserName: string;
  otherUserAvatar: string | null;
  otherUserId?: string;
  isTyping?: boolean;
  isRecording?: boolean;
  isClosed?: boolean;
  isOrderChat?: boolean;
  chatTheme: string;
  onThemeChange: (theme: string) => void;
  onBack: () => void;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
}

export const ChatHeader = ({
  otherUserName,
  otherUserAvatar,
  otherUserId,
  isTyping,
  isRecording,
  isClosed,
  isOrderChat,
  chatTheme,
  onThemeChange,
  onBack,
  searchQuery = "",
  onSearchChange,
}: ChatHeaderProps) => {
  const navigate = useNavigate();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [productCount, setProductCount] = useState(0);

  // Fetch user profile when sheet opens
  useEffect(() => {
    if (isProfileOpen && otherUserId) {
      const fetchProfile = async () => {
        const { data: profile } = await supabase
          .from("profiles")
          .select("full_name, avatar_url, campus_location, department, phone")
          .eq("user_id", otherUserId)
          .single();

        if (profile) {
          setUserProfile(profile);
        }

        // Get product count
        const { count } = await supabase
          .from("products")
          .select("*", { count: "exact", head: true })
          .eq("seller_id", otherUserId)
          .eq("is_active", true);

        setProductCount(count || 0);
      };

      fetchProfile();
    }
  }, [isProfileOpen, otherUserId]);

  const handleSearchToggle = () => {
    if (isSearchOpen) {
      onSearchChange?.("");
    }
    setIsSearchOpen(!isSearchOpen);
  };

  const handleProfileClick = () => {
    setIsProfileOpen(true);
  };

  const handleViewFullProfile = () => {
    if (otherUserId) {
      navigate(`/user/${otherUserId}`);
    }
    setIsProfileOpen(false);
  };

  return (
    <>
      {/* Fixed height header to prevent layout shifts */}
      <div className="sticky top-0 z-10 bg-gradient-to-b from-background via-background to-background/95 backdrop-blur-xl border-b border-border/50">
        <div className="max-w-3xl mx-auto px-4 py-3 h-[72px] flex items-center">
          {/* Search bar */}
          {isSearchOpen ? (
            <div className="flex items-center gap-2 w-full">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleSearchToggle}
                className="rounded-full hover:bg-muted/80 flex-shrink-0"
              >
                <X className="h-5 w-5" />
              </Button>
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search messages..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange?.(e.target.value)}
                  className="pl-10 bg-muted/50 border-0 focus-visible:ring-1"
                  autoFocus
                />
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3 w-full">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={onBack}
                className="rounded-full hover:bg-muted/80 -ml-2 flex-shrink-0"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              
              {/* Clickable Avatar with online indicator */}
              <button 
                onClick={handleProfileClick}
                className="relative flex-shrink-0 focus:outline-none focus:ring-2 focus:ring-primary rounded-full"
              >
                <div className="w-11 h-11 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center overflow-hidden ring-2 ring-background shadow-md transition-transform hover:scale-105">
                  {otherUserAvatar ? (
                    <img
                      src={otherUserAvatar}
                      alt={otherUserName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
                <OnlineIndicatorBadge userId={otherUserId} />
              </button>

              {/* Clickable Name and status - Fixed width to prevent jumps */}
              <button 
                onClick={handleProfileClick}
                className="flex-1 min-w-0 text-left focus:outline-none overflow-hidden"
              >
                <h1 className="font-semibold text-foreground truncate hover:text-primary transition-colors leading-tight">
                  {otherUserName}
                </h1>
                {/* Fixed height status container to prevent layout shifts */}
                <div className="h-4 flex items-center">
                  {isRecording ? (
                    <span className="text-xs text-destructive font-medium flex items-center gap-1">
                      <span className="w-2 h-2 bg-destructive rounded-full animate-pulse" />
                      recording...
                    </span>
                  ) : isTyping ? (
                    <span className="text-xs text-primary font-medium flex items-center gap-1">
                      <span className="flex gap-0.5">
                        <span className="w-1 h-1 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                        <span className="w-1 h-1 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                        <span className="w-1 h-1 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                      </span>
                      typing...
                    </span>
                  ) : isClosed ? (
                    <span className="text-xs text-muted-foreground">Closed</span>
                  ) : (
                    <OnlineStatus userId={otherUserId} showText size="sm" />
                  )}
                </div>
              </button>

              {/* Actions - Fixed width container */}
              <div className="flex items-center gap-1 flex-shrink-0">
                {onSearchChange && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={handleSearchToggle}
                    className="rounded-full hover:bg-muted/80 h-9 w-9"
                  >
                    <Search className="h-5 w-5" />
                  </Button>
                )}
                
                {!isClosed && (
                  <ChatThemeSelector
                    currentTheme={chatTheme}
                    onThemeChange={onThemeChange}
                  />
                )}
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-full hover:bg-muted/80 h-9 w-9">
                      <MoreVertical className="h-5 w-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem onClick={handleProfileClick}>
                      <User className="h-4 w-4 mr-2" />
                      View profile
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Mini Profile Sheet */}
      <Sheet open={isProfileOpen} onOpenChange={setIsProfileOpen}>
        <SheetContent side="right" className="w-[320px] sm:w-[400px]">
          <SheetHeader className="text-left">
            <SheetTitle>Profile</SheetTitle>
          </SheetHeader>
          
          <div className="mt-6 flex flex-col items-center">
            {/* Avatar */}
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center overflow-hidden ring-4 ring-background shadow-xl">
              {otherUserAvatar ? (
                <img
                  src={otherUserAvatar}
                  alt={otherUserName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <User className="h-12 w-12 text-muted-foreground" />
              )}
            </div>

            {/* Name */}
            <h2 className="mt-4 text-xl font-bold text-foreground">{otherUserName}</h2>
            
            {/* Online Status */}
            <div className="mt-1">
              <OnlineStatus userId={otherUserId} showText size="md" />
            </div>

            {/* Quick Info */}
            <div className="mt-6 w-full space-y-3">
              {userProfile?.department && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <ShoppingBag className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Department</p>
                    <p className="text-sm font-medium">{userProfile.department}</p>
                  </div>
                </div>
              )}

              {userProfile?.campus_location && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <MapPin className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Location</p>
                    <p className="text-sm font-medium">{userProfile.campus_location}</p>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <ShoppingBag className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Active Listings</p>
                  <p className="text-sm font-medium">{productCount} products</p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-6 w-full space-y-2">
              <Button 
                className="w-full" 
                onClick={handleViewFullProfile}
              >
                <User className="h-4 w-4 mr-2" />
                View Full Profile
              </Button>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setIsProfileOpen(false)}
              >
                <MessageCircle className="h-4 w-4 mr-2" />
                Continue Chat
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
};
