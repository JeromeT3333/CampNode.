import { cn } from "@/lib/utils";
import { useOnlineStatus, formatLastSeen } from "@/hooks/useOnlineStatus";

interface OnlineStatusProps {
  userId?: string;
  showText?: boolean;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export const OnlineStatus = ({
  userId,
  showText = false,
  size = "md",
  className
}: OnlineStatusProps) => {
  const { isOnline, lastSeen } = useOnlineStatus(userId);

  const sizeClasses = {
    sm: "w-2 h-2",
    md: "w-3 h-3",
    lg: "w-4 h-4"
  };

  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <span
        className={cn(
          "rounded-full flex-shrink-0 ring-2 ring-background",
          sizeClasses[size],
          isOnline ? "bg-green-500" : "bg-muted-foreground/50"
        )}
      />
      {showText && (
        <span className="text-xs text-muted-foreground">
          {isOnline ? "Online" : `Last seen ${formatLastSeen(lastSeen)}`}
        </span>
      )}
    </div>
  );
};

interface OnlineIndicatorBadgeProps {
  userId?: string;
  className?: string;
}

export const OnlineIndicatorBadge = ({ userId, className }: OnlineIndicatorBadgeProps) => {
  const { isOnline } = useOnlineStatus(userId);

  if (!isOnline) return null;

  return (
    <span
      className={cn(
        "absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-background",
        className
      )}
    />
  );
};