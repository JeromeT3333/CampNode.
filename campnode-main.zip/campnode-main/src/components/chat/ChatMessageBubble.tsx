import { useState, useRef } from "react";
import { cn } from "@/lib/utils";
import { Play, Pause, Check, CheckCheck, FileIcon, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ChatMessageBubbleProps {
  content: string | null;
  messageType: "text" | "image" | "voice" | "sticker" | "file";
  attachmentUrl: string | null;
  isOwnMessage: boolean;
  createdAt: string;
  isRead?: boolean | null;
}

export const ChatMessageBubble = ({
  content,
  messageType,
  attachmentUrl,
  isOwnMessage,
  createdAt,
  isRead
}: ChatMessageBubbleProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioDuration, setAudioDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString("en-NG", {
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const handlePlayPause = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleAudioEnded = () => {
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setAudioDuration(audioRef.current.duration);
    }
  };

  const renderContent = () => {
    switch (messageType) {
      case "image":
        return (
          <div className="space-y-2">
            {attachmentUrl && (
              <div className="rounded-lg overflow-hidden max-w-[250px]">
                <img
                  src={attachmentUrl}
                  alt="Shared image"
                  className="w-full h-auto object-cover cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={() => window.open(attachmentUrl, "_blank")}
                />
              </div>
            )}
            {content && <p className="break-words text-sm">{content}</p>}
          </div>
        );

      case "voice":
        return (
          <div className="flex items-center gap-3 min-w-[180px]">
            <audio
              ref={audioRef}
              src={attachmentUrl || ""}
              onEnded={handleAudioEnded}
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              className="hidden"
            />
            <Button
              size="icon"
              variant="ghost"
              className={cn(
                "h-10 w-10 rounded-full flex-shrink-0",
                isOwnMessage
                  ? "bg-primary-foreground/20 hover:bg-primary-foreground/30 text-primary-foreground"
                  : "bg-foreground/10 hover:bg-foreground/20"
              )}
              onClick={handlePlayPause}
            >
              {isPlaying ? (
                <Pause className="h-4 w-4" />
              ) : (
                <Play className="h-4 w-4 ml-0.5" />
              )}
            </Button>
            <div className="flex-1">
              {/* Waveform visualization placeholder */}
              <div className="flex items-center gap-0.5 h-6">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div
                    key={i}
                    className={cn(
                      "w-1 rounded-full transition-all",
                      isOwnMessage ? "bg-primary-foreground/50" : "bg-foreground/30",
                      i < (currentTime / audioDuration) * 20
                        ? isOwnMessage
                          ? "bg-primary-foreground"
                          : "bg-foreground"
                        : ""
                    )}
                    style={{
                      height: `${Math.random() * 16 + 8}px`
                    }}
                  />
                ))}
              </div>
              <span
                className={cn(
                  "text-xs",
                  isOwnMessage ? "text-primary-foreground/70" : "text-muted-foreground"
                )}
              >
                {formatDuration(isPlaying ? currentTime : audioDuration || 0)}
              </span>
            </div>
          </div>
        );

      case "sticker":
        return <span className="text-5xl">{content}</span>;

      case "file":
        const fileName = content || attachmentUrl?.split("/").pop() || "Document";
        return (
          <a
            href={attachmentUrl || "#"}
            target="_blank"
            rel="noopener noreferrer"
            className={cn(
              "flex items-center gap-3 p-2 rounded-lg transition-colors min-w-[180px]",
              isOwnMessage
                ? "bg-primary-foreground/10 hover:bg-primary-foreground/20"
                : "bg-foreground/5 hover:bg-foreground/10"
            )}
          >
            <div className={cn(
              "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
              isOwnMessage ? "bg-primary-foreground/20" : "bg-foreground/10"
            )}>
              <FileIcon className="h-5 w-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{fileName}</p>
              <p className="text-xs opacity-70">Document</p>
            </div>
            <Download className="h-4 w-4 opacity-70 flex-shrink-0" />
          </a>
        );

      default:
        return <p className="break-words">{content}</p>;
    }
  };

  // Sticker messages have minimal bubble
  if (messageType === "sticker") {
    return (
      <div
        className={cn(
          "flex flex-col",
          isOwnMessage ? "items-end" : "items-start"
        )}
      >
        {renderContent()}
        <div className="flex items-center gap-1 mt-1 px-1">
          <span className="text-xs text-muted-foreground">
            {formatTime(createdAt)}
          </span>
          {isOwnMessage && (
            isRead ? (
              <CheckCheck className="h-3.5 w-3.5 text-blue-400" />
            ) : (
              <Check className="h-3.5 w-3.5 text-muted-foreground" />
            )
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "flex",
        isOwnMessage ? "justify-end" : "justify-start"
      )}
    >
      <div
        className={cn(
          "max-w-[75%] px-4 py-2 rounded-2xl",
          isOwnMessage
            ? "bg-primary text-primary-foreground rounded-br-sm"
            : "bg-muted text-foreground rounded-bl-sm"
        )}
      >
        {renderContent()}
        <div
          className={cn(
            "flex items-center gap-1 mt-1",
            isOwnMessage ? "justify-end" : "justify-start"
          )}
        >
          <p
            className={cn(
              "text-xs",
              isOwnMessage
                ? "text-primary-foreground/70"
                : "text-muted-foreground"
            )}
          >
            {formatTime(createdAt)}
          </p>
          {isOwnMessage && (
            isRead ? (
              <CheckCheck className="h-3.5 w-3.5 text-blue-400" />
            ) : (
              <Check className="h-3.5 w-3.5 text-primary-foreground/70" />
            )
          )}
        </div>
      </div>
    </div>
  );
};
