import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { MapPin, Store, Sparkles, Truck, ChevronLeft, ChevronRight, ImageOff } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Product } from "@/data/mockData";

// Image component with fallback for broken images
const ProductImage = ({ src, alt, className }: { src?: string; alt: string; className?: string }) => {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  if (error || !src) {
    return (
      <div className={cn("flex items-center justify-center bg-muted", className)}>
        <ImageOff className="h-8 w-8 text-muted-foreground" />
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      className={cn(className, loading && "opacity-0")}
      onError={() => setError(true)}
      onLoad={() => setLoading(false)}
    />
  );
};

interface ProductCardProps {
  product: Product & { gif_url?: string | null; gif_interval?: number | null };
  index?: number;
}

export const ProductCard = ({ product, index = 0 }: ProductCardProps) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showGif, setShowGif] = useState(false);
  
  // GIF/Photo toggle effect
  useEffect(() => {
    if (!product.gif_url) return;
    
    const interval = product.gif_interval || 3000;
    const timer = setInterval(() => {
      setShowGif((prev) => !prev);
    }, interval);
    
    return () => clearInterval(timer);
  }, [product.gif_url, product.gif_interval]);
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(price);
  };

  // Combine main image with additional images
  const allImages = [product.image, ...(product.additionalImages || [])].filter(Boolean) as string[];
  const hasMultipleImages = allImages.length > 1;

  const handlePrevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev === 0 ? allImages.length - 1 : prev - 1));
  };

  const handleNextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev === allImages.length - 1 ? 0 : prev + 1));
  };

  return (
    <Link 
      to={`/product/${product.id}`}
      className={cn(
        "group block bg-card rounded-xl overflow-hidden border border-border h-full",
        "transition-all duration-300 hover:shadow-card-hover hover:-translate-y-0.5",
        "animate-fade-in flex flex-col"
      )}
      style={{ animationDelay: `${index * 50}ms` }}
    >
      {/* Image */}
      <div className="relative overflow-hidden aspect-square flex-shrink-0 bg-muted">
        <ProductImage
          src={showGif && product.gif_url ? product.gif_url : allImages[currentImageIndex]}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* GIF indicator */}
        {product.gif_url && (
          <div className="absolute bottom-1.5 right-1.5 px-2 py-0.5 rounded-full bg-background/80 text-[10px] font-medium">
            {showGif ? "GIF" : "Photo"}
          </div>
        )}

        {/* Image navigation */}
        {hasMultipleImages && (
          <>
            <button
              onClick={handlePrevImage}
              className="absolute left-1 top-1/2 -translate-y-1/2 p-1 rounded-full bg-background/80 text-foreground opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={handleNextImage}
              className="absolute right-1 top-1/2 -translate-y-1/2 p-1 rounded-full bg-background/80 text-foreground opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background"
            >
              <ChevronRight className="h-4 w-4" />
            </button>

            {/* Dots indicator */}
            <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 flex gap-1">
              {allImages.map((_, i) => (
                <span
                  key={i}
                  className={cn(
                    "w-1.5 h-1.5 rounded-full transition-colors",
                    i === currentImageIndex ? "bg-primary" : "bg-background/60"
                  )}
                />
              ))}
            </div>
          </>
        )}
        
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isSponsored && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-accent text-accent-foreground text-[10px] font-medium">
              <Sparkles className="h-2.5 w-2.5" />
              Sponsored
            </span>
          )}
          {product.isService && (
            <span className="px-2 py-0.5 rounded-full bg-secondary text-secondary-foreground text-[10px] font-medium">
              Service
            </span>
          )}
        </div>

        {product.hasDelivery && (
          <span className="absolute top-2 right-2 p-1 rounded-full bg-primary text-primary-foreground">
            <Truck className="h-3 w-3" />
          </span>
        )}
      </div>

      {/* Content */}
      <div className="p-3 flex flex-col flex-grow min-h-0">
        <h3 className="font-semibold text-sm text-card-foreground group-hover:text-primary transition-colors line-clamp-2 leading-tight">
          {product.name}
        </h3>

        <div className="mt-auto pt-2">
          <span className="font-bold text-primary text-base">
            {formatPrice(product.price)}
          </span>
        </div>

        {/* Shop or Location Info */}
        <div className="mt-1.5 flex items-center gap-1 text-xs text-muted-foreground">
          {product.shopName ? (
            <>
              <Store className="h-3 w-3 text-secondary flex-shrink-0" />
              <span className="font-medium text-secondary truncate">{product.shopName}</span>
            </>
          ) : product.location ? (
            <>
              <MapPin className="h-3 w-3 flex-shrink-0" />
              <span className="truncate">{product.location}</span>
            </>
          ) : null}
        </div>
      </div>
    </Link>
  );
};
