import { useState, useRef } from "react";
import { Upload, X, Loader2, Camera } from "lucide-react";
import { cn } from "@/lib/utils";
import { useImageUpload } from "@/hooks/useImageUpload";

interface ImageUploadProps {
  value?: string;
  onChange: (url: string | null) => void;
  bucket: "avatars" | "products" | "shops";
  folder?: string;
  aspectRatio?: "square" | "cover" | "banner";
  placeholder?: string;
  className?: string;
}

export const ImageUpload = ({
  value,
  onChange,
  bucket,
  folder,
  aspectRatio = "square",
  placeholder = "Click to upload",
  className,
}: ImageUploadProps) => {
  const [preview, setPreview] = useState<string | null>(value || null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { uploadImage, isUploading } = useImageUpload();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Show preview immediately
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);

    // Upload to storage
    const url = await uploadImage(file, bucket, folder);
    if (url) {
      onChange(url);
    } else {
      // Reset preview if upload failed
      setPreview(value || null);
    }
  };

  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPreview(null);
    onChange(null);
    if (inputRef.current) {
      inputRef.current.value = "";
    }
  };

  const aspectClasses = {
    square: "aspect-square",
    cover: "aspect-video",
    banner: "aspect-[3/1]",
  };

  return (
    <div
      onClick={() => !isUploading && inputRef.current?.click()}
      className={cn(
        "relative overflow-hidden rounded-xl border-2 border-dashed border-border",
        "cursor-pointer transition-all hover:border-primary/50",
        "bg-muted/50",
        aspectClasses[aspectRatio],
        className
      )}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif"
        onChange={handleFileChange}
        className="hidden"
        disabled={isUploading}
      />

      {preview ? (
        <>
          <img
            src={preview}
            alt="Preview"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
            <Camera className="h-8 w-8 text-white" />
          </div>
          {!isUploading && (
            <button
              onClick={handleRemove}
              className="absolute top-2 right-2 p-1.5 rounded-full bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </>
      ) : (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-muted-foreground">
          {isUploading ? (
            <>
              <Loader2 className="h-8 w-8 animate-spin" />
              <span className="text-sm">Uploading...</span>
            </>
          ) : (
            <>
              <Upload className="h-8 w-8" />
              <span className="text-sm">{placeholder}</span>
            </>
          )}
        </div>
      )}

      {isUploading && preview && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <Loader2 className="h-8 w-8 animate-spin text-white" />
        </div>
      )}
    </div>
  );
};
