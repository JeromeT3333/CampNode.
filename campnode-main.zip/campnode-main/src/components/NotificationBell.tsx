import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { 
  requestNotificationPermission, 
  showBrowserNotification,
  subscribeToMessageNotifications 
} from "@/lib/notifications";
import { toast } from "sonner";

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  is_read: boolean | null;
  created_at: string;
  data: any;
}

export const NotificationBell = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [permissionGranted, setPermissionGranted] = useState(false);

  // Request notification permission on mount - more prominently
  useEffect(() => {
    const checkAndRequestPermission = async () => {
      if (!("Notification" in window)) {
        console.log("This browser does not support notifications");
        return;
      }

      if (Notification.permission === "granted") {
        setPermissionGranted(true);
        return;
      }

      if (Notification.permission === "default") {
        // Show toast after a short delay so it's not immediately dismissed
        setTimeout(() => {
          toast("🔔 Enable Notifications", {
            description: "Stay updated with new messages, orders, and more!",
            duration: 10000,
            action: {
              label: "Enable",
              onClick: async () => {
                const result = await requestNotificationPermission();
                setPermissionGranted(result);
                if (result) {
                  toast.success("Notifications enabled!");
                }
              }
            }
          });
        }, 2000);
      }
    };

    checkAndRequestPermission();
  }, []);

  useEffect(() => {
    if (!user) return;

    const fetchNotifications = async () => {
      const { data, error } = await supabase
        .from("notifications")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10);

      if (!error && data) {
        setNotifications(data);
        setUnreadCount(data.filter((n) => !n.is_read).length);
      }
    };

    fetchNotifications();

    // Real-time subscription for notifications table
    const channel = supabase
      .channel(`notifications-${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "notifications",
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          const newNotif = payload.new as Notification;
          setNotifications((prev) => [newNotif, ...prev.slice(0, 9)]);
          setUnreadCount((prev) => prev + 1);
          
          // Show browser push notification
          showBrowserNotification(newNotif.title, {
            body: newNotif.message,
            tag: newNotif.id,
            data: { ...newNotif.data, type: newNotif.type },
            requireInteraction: newNotif.type === "order" || newNotif.type === "payment"
          });

          // Also show in-app toast
          toast(newNotif.title, {
            description: newNotif.message,
            action: {
              label: "View",
              onClick: () => {
                const path = getNavigationPath(newNotif);
                navigate(path);
              }
            }
          });
        }
      )
      .subscribe();

    // Subscribe to message notifications (for DMs)
    const unsubscribeMessages = subscribeToMessageNotifications(
      user.id,
      null,
      (message, senderName) => {
        let body = message.content || "";
        if (message.message_type === "image") body = "📷 Image";
        if (message.message_type === "voice") body = "🎤 Voice message";
        if (message.message_type === "file") body = "📎 File";
        if (message.message_type === "sticker") body = "🎭 Sticker";

        toast(`${senderName}`, {
          description: body,
          action: {
            label: "Reply",
            onClick: () => navigate(`/conversation/${message.conversation_id}`)
          }
        });
      }
    );

    return () => {
      supabase.removeChannel(channel);
      unsubscribeMessages();
    };
  }, [user, navigate]);

  const handleMarkAsRead = async (id: string) => {
    await supabase
      .from("notifications")
      .update({ is_read: true })
      .eq("id", id);

    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, is_read: true } : n))
    );
    setUnreadCount((prev) => Math.max(0, prev - 1));
  };

  const getNavigationPath = (notif: Notification): string => {
    switch (notif.type) {
      case "order":
        if (notif.data?.order_id) {
          return `/chat/${notif.data.order_id}`;
        }
        return "/orders";
      case "message":
        if (notif.data?.conversation_id) {
          return `/conversation/${notif.data.conversation_id}`;
        } else if (notif.data?.order_id) {
          return `/chat/${notif.data.order_id}`;
        } else if (notif.data?.sender_id) {
          return `/dm/${notif.data.sender_id}`;
        }
        return "/conversations";
      case "payout":
      case "payment":
        return "/seller-dashboard";
      case "shop":
        if (notif.data?.shop_id) {
          return `/shop/${notif.data.shop_id}`;
        }
        return "/my-shops";
      case "product":
        if (notif.data?.product_id) {
          return `/product/${notif.data.product_id}`;
        }
        return "/products";
      case "review":
        return "/seller-dashboard";
      case "reservation":
        if (notif.data?.shop_id) {
          return `/shop-dashboard/${notif.data.shop_id}`;
        }
        return "/my-shops";
      default:
        return "/notifications";
    }
  };

  const handleNotificationClick = (notif: Notification) => {
    handleMarkAsRead(notif.id);
    const path = getNavigationPath(notif);
    navigate(path);
  };

  const formatTime = (date: string) => {
    const now = new Date();
    const notifDate = new Date(date);
    const diffMs = now.getTime() - notifDate.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  if (!user) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className={cn(
              "absolute -top-1 -right-1 flex items-center justify-center",
              "min-w-[18px] h-[18px] px-1 rounded-full",
              "bg-red-500 text-white text-[10px] font-bold",
              "animate-pulse"
            )}>
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <div className="p-2 border-b border-border flex items-center justify-between">
          <h3 className="font-semibold text-foreground">Notifications</h3>
          {!permissionGranted && Notification.permission !== "denied" && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs h-7"
              onClick={async () => {
                const result = await requestNotificationPermission();
                setPermissionGranted(result);
              }}
            >
              Enable alerts
            </Button>
          )}
        </div>
        {notifications.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground text-sm">
            No notifications yet
          </div>
        ) : (
          notifications.map((notif) => (
            <DropdownMenuItem
              key={notif.id}
              className={cn(
                "flex flex-col items-start gap-1 p-3 cursor-pointer",
                !notif.is_read && "bg-muted/50"
              )}
              onClick={() => handleNotificationClick(notif)}
            >
              <div className="flex items-start justify-between w-full gap-2">
                <span className="font-medium text-foreground text-sm">
                  {notif.title}
                </span>
                {!notif.is_read && (
                  <span className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0 mt-1.5" />
                )}
              </div>
              <span className="text-xs text-muted-foreground line-clamp-2">
                {notif.message}
              </span>
              <span className="text-xs text-muted-foreground">
                {formatTime(notif.created_at)}
              </span>
            </DropdownMenuItem>
          ))
        )}
        {notifications.length > 0 && (
          <div className="p-2 border-t border-border">
            <Button
              variant="ghost"
              size="sm"
              className="w-full text-xs"
              onClick={() => navigate("/notifications")}
            >
              View all notifications
            </Button>
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
