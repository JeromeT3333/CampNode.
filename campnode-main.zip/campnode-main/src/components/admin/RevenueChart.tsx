import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { formatNaira } from "@/lib/formatCurrency";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

type TimeRange = "7d" | "30d" | "90d";

interface RevenueData {
  date: string;
  revenue: number;
  orders: number;
  fees: number;
}

export const RevenueChart = () => {
  const [data, setData] = useState<RevenueData[]>([]);
  const [timeRange, setTimeRange] = useState<TimeRange>("7d");
  const [loading, setLoading] = useState(true);
  const [chartType, setChartType] = useState<"area" | "bar">("area");

  useEffect(() => {
    fetchRevenueData();
  }, [timeRange]);

  const fetchRevenueData = async () => {
    setLoading(true);
    try {
      const daysMap = { "7d": 7, "30d": 30, "90d": 90 };
      const days = daysMap[timeRange];
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const { data: transactions } = await supabase
        .from("transactions")
        .select("gross_amount, platform_fee, created_at")
        .gte("created_at", startDate.toISOString())
        .eq("payment_status", "completed");

      // Group by date
      const grouped: Record<string, RevenueData> = {};
      
      // Initialize all dates
      for (let i = days - 1; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateKey = date.toLocaleDateString("en-US", { 
          month: "short", 
          day: "numeric" 
        });
        grouped[dateKey] = { date: dateKey, revenue: 0, orders: 0, fees: 0 };
      }

      // Fill in actual data
      (transactions || []).forEach((tx) => {
        const date = new Date(tx.created_at);
        const dateKey = date.toLocaleDateString("en-US", { 
          month: "short", 
          day: "numeric" 
        });
        if (grouped[dateKey]) {
          grouped[dateKey].revenue += Number(tx.gross_amount);
          grouped[dateKey].fees += Number(tx.platform_fee);
          grouped[dateKey].orders += 1;
        }
      });

      setData(Object.values(grouped));
    } catch (error) {
      console.error("Error fetching revenue data:", error);
    } finally {
      setLoading(false);
    }
  };

  const totalRevenue = data.reduce((sum, d) => sum + d.revenue, 0);
  const totalFees = data.reduce((sum, d) => sum + d.fees, 0);
  const totalOrders = data.reduce((sum, d) => sum + d.orders, 0);

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <CardTitle className="text-lg">Revenue Overview</CardTitle>
            <div className="flex gap-4 mt-2 text-sm">
              <span className="text-muted-foreground">
                Total: <span className="font-semibold text-foreground">{formatNaira(totalRevenue)}</span>
              </span>
              <span className="text-muted-foreground">
                Fees: <span className="font-semibold text-green-600">{formatNaira(totalFees)}</span>
              </span>
              <span className="text-muted-foreground">
                Orders: <span className="font-semibold text-foreground">{totalOrders}</span>
              </span>
            </div>
          </div>
          <div className="flex gap-2">
            <div className="flex border rounded-lg overflow-hidden">
              {(["7d", "30d", "90d"] as TimeRange[]).map((range) => (
                <Button
                  key={range}
                  variant={timeRange === range ? "default" : "ghost"}
                  size="sm"
                  className="rounded-none"
                  onClick={() => setTimeRange(range)}
                >
                  {range}
                </Button>
              ))}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setChartType(chartType === "area" ? "bar" : "area")}
            >
              {chartType === "area" ? "Bar" : "Area"}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-[300px] flex items-center justify-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            {chartType === "area" ? (
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorFees" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="date" className="text-xs" tick={{ fontSize: 11 }} />
                <YAxis className="text-xs" tick={{ fontSize: 11 }} tickFormatter={(v) => `₦${(v/1000).toFixed(0)}k`} />
                <Tooltip
                  formatter={(value: number, name: string) => [
                    formatNaira(value),
                    name === "revenue" ? "Revenue" : "Platform Fees"
                  ]}
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="hsl(var(--primary))"
                  fill="url(#colorRevenue)"
                  strokeWidth={2}
                />
                <Area
                  type="monotone"
                  dataKey="fees"
                  stroke="#22c55e"
                  fill="url(#colorFees)"
                  strokeWidth={2}
                />
              </AreaChart>
            ) : (
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="date" className="text-xs" tick={{ fontSize: 11 }} />
                <YAxis className="text-xs" tick={{ fontSize: 11 }} tickFormatter={(v) => `₦${(v/1000).toFixed(0)}k`} />
                <Tooltip
                  formatter={(value: number, name: string) => [
                    formatNaira(value),
                    name === "revenue" ? "Revenue" : "Platform Fees"
                  ]}
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                <Bar dataKey="fees" fill="#22c55e" radius={[4, 4, 0, 0]} />
              </BarChart>
            )}
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
};
