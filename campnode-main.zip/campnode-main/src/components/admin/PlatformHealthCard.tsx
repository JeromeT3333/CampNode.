import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import {
  CheckCircle,
  AlertTriangle,
  XCircle,
  Database,
  Server,
  CreditCard,
  Shield,
} from "lucide-react";

interface HealthCheck {
  name: string;
  status: "healthy" | "warning" | "error";
  message: string;
  icon: React.ElementType;
}

export const PlatformHealthCard = () => {
  const [healthChecks, setHealthChecks] = useState<HealthCheck[]>([]);
  const [overallHealth, setOverallHealth] = useState(100);

  useEffect(() => {
    checkPlatformHealth();
  }, []);

  const checkPlatformHealth = async () => {
    const checks: HealthCheck[] = [];

    // Database connection check
    try {
      const { error } = await supabase.from("profiles").select("id").limit(1);
      checks.push({
        name: "Database",
        status: error ? "error" : "healthy",
        message: error ? "Connection issues detected" : "Connected",
        icon: Database,
      });
    } catch {
      checks.push({
        name: "Database",
        status: "error",
        message: "Failed to connect",
        icon: Database,
      });
    }

    // Check for pending orders (warning if too many)
    try {
      const { count } = await supabase
        .from("orders")
        .select("*", { count: "exact", head: true })
        .eq("status", "pending");

      const pendingCount = count || 0;
      checks.push({
        name: "Order Queue",
        status: pendingCount > 50 ? "warning" : "healthy",
        message: `${pendingCount} pending orders`,
        icon: Server,
      });
    } catch {
      checks.push({
        name: "Order Queue",
        status: "error",
        message: "Unable to check",
        icon: Server,
      });
    }

    // Check for restricted accounts
    try {
      const { count } = await supabase
        .from("account_restrictions")
        .select("*", { count: "exact", head: true })
        .eq("is_active", true);

      checks.push({
        name: "Account Security",
        status: "healthy",
        message: `${count || 0} active restrictions`,
        icon: Shield,
      });
    } catch {
      checks.push({
        name: "Account Security",
        status: "healthy",
        message: "No issues",
        icon: Shield,
      });
    }

    // Payment system check
    checks.push({
      name: "Payment Gateway",
      status: "healthy",
      message: "Flutterwave connected",
      icon: CreditCard,
    });

    setHealthChecks(checks);

    // Calculate overall health
    const healthyCount = checks.filter((c) => c.status === "healthy").length;
    setOverallHealth(Math.round((healthyCount / checks.length) * 100));
  };

  const statusIcons = {
    healthy: CheckCircle,
    warning: AlertTriangle,
    error: XCircle,
  };

  const statusColors = {
    healthy: "text-green-500",
    warning: "text-yellow-500",
    error: "text-red-500",
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Platform Health</CardTitle>
          <Badge variant={overallHealth >= 90 ? "default" : overallHealth >= 70 ? "secondary" : "destructive"}>
            {overallHealth}% Healthy
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <Progress value={overallHealth} className="h-2" />
        
        <div className="space-y-3">
          {healthChecks.map((check) => {
            const StatusIcon = statusIcons[check.status];
            return (
              <div
                key={check.name}
                className="flex items-center justify-between p-2 rounded-lg bg-muted/30"
              >
                <div className="flex items-center gap-3">
                  <check.icon className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium text-sm">{check.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{check.message}</span>
                  <StatusIcon className={`h-4 w-4 ${statusColors[check.status]}`} />
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
