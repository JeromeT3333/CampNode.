import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import {
  UserPlus,
  Store,
  Package,
  MessageSquare,
  Shield,
  Settings,
  Download,
  RefreshCw,
} from "lucide-react";

interface QuickAction {
  icon: React.ElementType;
  label: string;
  description: string;
  href?: string;
  onClick?: () => void;
  variant?: "default" | "outline" | "secondary" | "destructive";
}

interface QuickActionsProps {
  onRefreshData?: () => void;
  onExportData?: () => void;
}

export const QuickActions = ({ onRefreshData, onExportData }: QuickActionsProps) => {
  const navigate = useNavigate();

  const actions: QuickAction[] = [
    {
      icon: UserPlus,
      label: "Manage Users",
      description: "View and manage user accounts",
      href: "/admin/users",
    },
    {
      icon: Store,
      label: "Verify Shops",
      description: "Review pending shop verifications",
      href: "/admin/shops",
    },
    {
      icon: Package,
      label: "Manage Products",
      description: "View and moderate products",
      href: "/admin/products",
    },
    {
      icon: MessageSquare,
      label: "Send Broadcast",
      description: "Send notification to all users",
      href: "/admin/broadcast",
    },
    {
      icon: Shield,
      label: "Restrictions",
      description: "Manage account restrictions",
      href: "/admin/restrictions",
    },
    {
      icon: Settings,
      label: "Platform Settings",
      description: "Configure platform settings",
      href: "/admin/settings",
    },
  ];

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Quick Actions</CardTitle>
          <div className="flex gap-2">
            {onRefreshData && (
              <Button variant="outline" size="sm" onClick={onRefreshData}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            )}
            {onExportData && (
              <Button variant="outline" size="sm" onClick={onExportData}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {actions.map((action) => (
            <Button
              key={action.label}
              variant="outline"
              className="h-auto py-4 flex flex-col gap-2 hover:bg-primary/5 hover:border-primary/30"
              onClick={() => action.href && navigate(action.href)}
            >
              <action.icon className="h-5 w-5" />
              <span className="text-xs font-medium">{action.label}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
