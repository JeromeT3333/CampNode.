import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { formatDistanceToNow } from "date-fns";
import {
  ShoppingCart,
  UserPlus,
  Store,
  Package,
  CreditCard,
  AlertTriangle,
} from "lucide-react";

interface Activity {
  id: string;
  type: "order" | "user" | "shop" | "product" | "transaction" | "restriction";
  title: string;
  description: string;
  timestamp: string;
  status?: string;
}

const activityIcons = {
  order: ShoppingCart,
  user: UserPlus,
  shop: Store,
  product: Package,
  transaction: CreditCard,
  restriction: AlertTriangle,
};

const activityColors = {
  order: "bg-blue-500/10 text-blue-500",
  user: "bg-green-500/10 text-green-500",
  shop: "bg-purple-500/10 text-purple-500",
  product: "bg-orange-500/10 text-orange-500",
  transaction: "bg-emerald-500/10 text-emerald-500",
  restriction: "bg-red-500/10 text-red-500",
};

export const RecentActivity = () => {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecentActivity();
  }, []);

  const fetchRecentActivity = async () => {
    try {
      // Fetch recent orders
      const { data: orders } = await supabase
        .from("orders")
        .select("id, status, total_amount, created_at")
        .order("created_at", { ascending: false })
        .limit(5);

      // Fetch recent users
      const { data: users } = await supabase
        .from("profiles")
        .select("id, full_name, created_at")
        .order("created_at", { ascending: false })
        .limit(3);

      // Fetch recent shops
      const { data: shops } = await supabase
        .from("shops")
        .select("id, name, created_at")
        .order("created_at", { ascending: false })
        .limit(3);

      const allActivities: Activity[] = [
        ...(orders || []).map((o) => ({
          id: o.id,
          type: "order" as const,
          title: "New Order",
          description: `Order ₦${Number(o.total_amount).toLocaleString()} - ${o.status}`,
          timestamp: o.created_at,
          status: o.status,
        })),
        ...(users || []).map((u) => ({
          id: u.id,
          type: "user" as const,
          title: "New User",
          description: u.full_name || "User registered",
          timestamp: u.created_at,
        })),
        ...(shops || []).map((s) => ({
          id: s.id,
          type: "shop" as const,
          title: "New Shop",
          description: s.name,
          timestamp: s.created_at,
        })),
      ];

      // Sort by timestamp
      allActivities.sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );

      setActivities(allActivities.slice(0, 10));
    } catch (error) {
      console.error("Error fetching activity:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px]">
          {loading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-12 bg-muted animate-pulse rounded" />
              ))}
            </div>
          ) : activities.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No recent activity</p>
          ) : (
            <div className="space-y-4">
              {activities.map((activity) => {
                const Icon = activityIcons[activity.type];
                return (
                  <div
                    key={`${activity.type}-${activity.id}`}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className={`p-2 rounded-full ${activityColors[activity.type]}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-medium text-sm">{activity.title}</p>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                          {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground truncate">
                        {activity.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
};
