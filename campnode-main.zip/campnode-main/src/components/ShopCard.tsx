import { Link } from "react-router-dom";
import { MapPin, Star, Package, BadgeCheck, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface Shop {
  id: string;
  name: string;
  description: string;
  coverImage: string;
  profileImage: string;
  category: string;
  location: string;
  rating: number;
  productCount: number;
  isVerified?: boolean;
  openingTime?: string | null;
  closingTime?: string | null;
  isOpen24hrs?: boolean | null;
}

interface ShopCardProps {
  shop: Shop;
  index?: number;
}

const formatTime = (time: string | null | undefined) => {
  if (!time) return null;
  try {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  } catch {
    return time;
  }
};

export const ShopCard = ({ shop, index = 0 }: ShopCardProps) => {
  return (
    <Link
      to={`/shop/${shop.id}`}
      className={cn(
        "group block bg-card rounded-xl overflow-hidden border border-border",
        "transition-all duration-300 hover:shadow-card-hover hover:-translate-y-1",
        "animate-fade-in"
      )}
      style={{ animationDelay: `${index * 50}ms` }}
    >
      {/* Cover Image */}
      <div className="relative h-28 overflow-hidden">
        <img
          src={shop.coverImage}
          alt={shop.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        
        {/* Profile Image */}
        <div className="absolute -bottom-6 left-4">
          <div className="w-14 h-14 rounded-xl overflow-hidden border-3 border-card shadow-lg">
            <img
              src={shop.profileImage}
              alt={shop.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="pt-8 pb-4 px-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-1.5">
              <h3 className="font-semibold text-card-foreground group-hover:text-primary transition-colors">
                {shop.name}
              </h3>
              {shop.isVerified && (
                <BadgeCheck className="h-4 w-4 text-primary fill-primary/20" />
              )}
            </div>
            <p className="mt-0.5 text-sm text-muted-foreground line-clamp-2">
              {shop.description}
            </p>
          </div>
        </div>

        {/* Opening Hours */}
        {(shop.openingTime || shop.isOpen24hrs) && (
          <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            {shop.isOpen24hrs ? (
              <span>Open 24 hours</span>
            ) : (
              <span>{formatTime(shop.openingTime)} - {formatTime(shop.closingTime)}</span>
            )}
          </div>
        )}

        <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Star className="h-3 w-3 text-accent fill-accent" />
            <span className="font-medium text-foreground">{shop.rating}</span>
          </span>
          <span className="flex items-center gap-1">
            <Package className="h-3 w-3" />
            {shop.productCount} items
          </span>
          <span className="flex items-center gap-1">
            <MapPin className="h-3 w-3" />
            {shop.location}
          </span>
        </div>
      </div>
    </Link>
  );
};
