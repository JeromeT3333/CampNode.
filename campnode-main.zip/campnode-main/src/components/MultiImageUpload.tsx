import { useState, useRef } from "react";
import { Upload, X, Loader2, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { useImageUpload } from "@/hooks/useImageUpload";

interface MultiImageUploadProps {
  value: string[];
  onChange: (urls: string[]) => void;
  bucket: "avatars" | "products" | "shops";
  folder?: string;
  maxImages?: number;
  className?: string;
}

export const MultiImageUpload = ({
  value = [],
  onChange,
  bucket,
  folder,
  maxImages = 5,
  className,
}: MultiImageUploadProps) => {
  const [uploading, setUploading] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { uploadImage } = useImageUpload();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const remainingSlots = maxImages - value.length;
    const filesToUpload = Array.from(files).slice(0, remainingSlots);

    for (let i = 0; i < filesToUpload.length; i++) {
      setUploading(value.length + i);
      const url = await uploadImage(filesToUpload[i], bucket, folder);
      if (url) {
        onChange([...value, url]);
      }
    }
    
    setUploading(null);
    if (inputRef.current) {
      inputRef.current.value = "";
    }
  };

  const handleRemove = (index: number) => {
    const newUrls = value.filter((_, i) => i !== index);
    onChange(newUrls);
  };

  return (
    <div className={cn("space-y-3", className)}>
      <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
        {value.map((url, index) => (
          <div
            key={url}
            className="relative aspect-square rounded-lg overflow-hidden border border-border group"
          >
            <img
              src={url}
              alt={`Image ${index + 1}`}
              className="w-full h-full object-cover"
            />
            <button
              type="button"
              onClick={() => handleRemove(index)}
              className="absolute top-1 right-1 p-1 rounded-full bg-destructive text-destructive-foreground opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="h-3 w-3" />
            </button>
            {index === 0 && (
              <span className="absolute bottom-1 left-1 text-[10px] px-1.5 py-0.5 rounded bg-primary text-primary-foreground">
                Main
              </span>
            )}
          </div>
        ))}

        {value.length < maxImages && (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={uploading !== null}
            className={cn(
              "aspect-square rounded-lg border-2 border-dashed border-border",
              "flex flex-col items-center justify-center gap-1",
              "text-muted-foreground hover:border-primary/50 hover:text-foreground",
              "transition-colors cursor-pointer",
              uploading !== null && "cursor-not-allowed opacity-50"
            )}
          >
            {uploading !== null ? (
              <Loader2 className="h-6 w-6 animate-spin" />
            ) : (
              <>
                <Plus className="h-6 w-6" />
                <span className="text-xs">Add</span>
              </>
            )}
          </button>
        )}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif"
        onChange={handleFileChange}
        className="hidden"
        multiple
        disabled={uploading !== null}
      />

      <p className="text-xs text-muted-foreground">
        {value.length}/{maxImages} images • First image is the main photo
      </p>
    </div>
  );
};
