import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { 
  Home, 
  Search, 
  ShoppingBag, 
  Store, 
  User, 
  Info, 
  Menu, 
  X, 
  LayoutDashboard,
  PlusCircle,
  LogIn,
  LogOut,
  Loader2,
  TrendingUp,
  Package,
  Bell,
  Receipt,
  Settings,
  ShieldCheck
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useAdminCheck } from "@/hooks/useAdminCheck";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import logo from "@/assets/logo.png";

const navItems = [
  { icon: Home, label: "Home", path: "/" },
  { icon: Search, label: "Search", path: "/search" },
  { icon: Store, label: "Shops", path: "/shops" },
  { icon: ShoppingBag, label: "Products", path: "/products" },
  { icon: Info, label: "About", path: "/about" },
];

const userItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: Package, label: "My Listings", path: "/my-listings" },
  { icon: Store, label: "My Shops", path: "/my-shops" },
  { icon: ShoppingBag, label: "Orders", path: "/orders" },
  { icon: Bell, label: "Notifications", path: "/notifications" },
  { icon: Receipt, label: "Receipts", path: "/receipts" },
  { icon: TrendingUp, label: "Seller Dashboard", path: "/seller-dashboard" },
  { icon: PlusCircle, label: "Create Shop", path: "/create-shop" },
  { icon: User, label: "Profile", path: "/profile" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

export const AppSidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isSigningOut, setIsSigningOut] = useState(false);
  const { user, loading, signOut } = useAuth();
  const { isAdmin } = useAdminCheck();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const handleSignOut = async () => {
    setIsSigningOut(true);
    await signOut();
    setIsSigningOut(false);
    setIsOpen(false);
  };

  return (
    <>
      {/* Mobile Header */}
      <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-3 bg-card/95 backdrop-blur-md border-b border-border md:hidden">
        <Link to="/" className="flex items-center gap-2">
          <img src={logo} alt="CampNode" className="h-8 w-8" />
          <span className="font-bold text-lg text-primary">CampNode</span>
        </Link>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setIsOpen(!isOpen)}
          className="text-foreground"
        >
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </header>

      {/* Sidebar Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed top-0 left-0 z-50 h-full w-72 bg-sidebar border-r border-sidebar-border transition-transform duration-300 ease-in-out",
        "flex flex-col",
        isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-5 border-b border-sidebar-border">
          <img src={logo} alt="CampNode" className="h-10 w-10" />
          <div>
            <h1 className="font-bold text-xl text-sidebar-primary">CampNode</h1>
            <p className="text-xs text-muted-foreground">Campus Marketplace</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 overflow-y-auto">
          <div className="mb-6">
            <p className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Browse
            </p>
            <ul className="space-y-1">
              {navItems.map((item) => (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    onClick={() => setIsOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                      "hover:bg-sidebar-accent",
                      isActive(item.path) 
                        ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-md" 
                        : "text-sidebar-foreground"
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    <span className="font-medium">{item.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {user && (
            <>
              <div className="mb-6">
                <p className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Account
                </p>
                <ul className="space-y-1">
                  {userItems.map((item) => (
                    <li key={item.path}>
                      <Link
                        to={item.path}
                        onClick={() => setIsOpen(false)}
                        className={cn(
                          "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                          "hover:bg-sidebar-accent",
                          isActive(item.path) 
                            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-md" 
                            : "text-sidebar-foreground"
                        )}
                      >
                        <item.icon className="h-5 w-5" />
                        <span className="font-medium">{item.label}</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {isAdmin && (
                <div className="mb-6">
                  <p className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Admin
                  </p>
                  <ul className="space-y-1">
                    <li>
                      <Link
                        to="/admin"
                        onClick={() => setIsOpen(false)}
                        className={cn(
                          "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                          "hover:bg-sidebar-accent",
                          isActive("/admin") 
                            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-md" 
                            : "text-sidebar-foreground"
                        )}
                      >
                        <ShieldCheck className="h-5 w-5" />
                        <span className="font-medium">Admin Dashboard</span>
                      </Link>
                    </li>
                  </ul>
                </div>
              )}
            </>
          )}
        </nav>

        {/* Bottom Section */}
        <div className="p-4 border-t border-sidebar-border space-y-3">
          {/* User Info */}
          {user && (
            <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-sidebar-accent">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-sm font-medium">
                {user.email?.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-sidebar-foreground truncate">
                  {user.user_metadata?.full_name || user.email?.split("@")[0]}
                </p>
                <p className="text-xs text-muted-foreground truncate">{user.email}</p>
              </div>
            </div>
          )}

          {/* Sign In / Sign Out Button */}
          {loading ? (
            <Button className="w-full gap-2" disabled>
              <Loader2 className="h-4 w-4 animate-spin" />
              Loading...
            </Button>
          ) : user ? (
            <Button 
              variant="outline" 
              className="w-full gap-2"
              onClick={handleSignOut}
              disabled={isSigningOut}
            >
              {isSigningOut ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Signing out...
                </>
              ) : (
                <>
                  <LogOut className="h-4 w-4" />
                  Sign Out
                </>
              )}
            </Button>
          ) : (
            <Link to="/auth" onClick={() => setIsOpen(false)}>
              <Button className="w-full gap-2 gradient-primary text-primary-foreground shadow-md hover:shadow-lg transition-shadow">
                <LogIn className="h-4 w-4" />
                Sign In
              </Button>
            </Link>
          )}
        </div>
      </aside>
    </>
  );
};
