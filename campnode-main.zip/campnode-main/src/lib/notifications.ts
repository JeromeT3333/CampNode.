// Browser push notification utilities
import { supabase } from "@/integrations/supabase/client";

export const requestNotificationPermission = async (): Promise<boolean> => {
  if (!("Notification" in window)) {
    console.log("This browser does not support notifications");
    return false;
  }

  if (Notification.permission === "granted") {
    return true;
  }

  if (Notification.permission !== "denied") {
    const permission = await Notification.requestPermission();
    return permission === "granted";
  }

  return false;
};

export const showBrowserNotification = (
  title: string,
  options?: {
    body?: string;
    icon?: string;
    tag?: string;
    data?: any;
    requireInteraction?: boolean;
  }
): Notification | null => {
  if (!("Notification" in window) || Notification.permission !== "granted") {
    return null;
  }

  const notification = new Notification(title, {
    body: options?.body,
    icon: options?.icon || "/favicon.ico",
    tag: options?.tag,
    requireInteraction: options?.requireInteraction || false,
  });

  notification.onclick = () => {
    window.focus();
    notification.close();
    
    // Navigate based on notification type
    if (options?.data) {
      const { type, order_id, conversation_id, sender_id, shop_id, product_id } = options.data;
      
      let path = "/notifications";
      
      switch (type) {
        case "order":
          path = "/orders";
          break;
        case "message":
          if (conversation_id) path = `/conversation/${conversation_id}`;
          else if (sender_id) path = `/dm/${sender_id}`;
          else path = "/conversations";
          break;
        case "payout":
        case "payment":
          path = "/seller-dashboard";
          break;
        case "shop":
          path = shop_id ? `/shop/${shop_id}` : "/my-shops";
          break;
        case "product":
          path = product_id ? `/product/${product_id}` : "/products";
          break;
      }
      
      window.location.href = path;
    }
  };

  // Auto close after 8 seconds unless requireInteraction is true
  if (!options?.requireInteraction) {
    setTimeout(() => notification.close(), 8000);
  }

  return notification;
};

// Subscribe to real-time notifications
export const subscribeToNotifications = (userId: string, onNotification: (notification: any) => void) => {
  const channel = supabase
    .channel(`notifications-${userId}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "notifications",
        filter: `user_id=eq.${userId}`
      },
      (payload) => {
        const notification = payload.new;
        onNotification(notification);
        
        // Show browser notification
        showBrowserNotification(notification.title, {
          body: notification.message,
          tag: notification.id,
          data: {
            type: notification.type,
            ...notification.data
          },
          requireInteraction: notification.type === "order" || notification.type === "payment"
        });
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

// Subscribe to new messages for notifications
export const subscribeToMessageNotifications = (
  userId: string, 
  currentConversationId: string | null,
  onNewMessage: (message: any, senderName: string) => void
) => {
  const channel = supabase
    .channel(`message-notifications-${userId}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "messages"
      },
      async (payload) => {
        const message = payload.new;
        
        // Don't notify for own messages or current conversation
        if (message.sender_id === userId) return;
        if (currentConversationId && message.conversation_id === currentConversationId) return;
        
        // Check if user is part of this conversation
        const { data: conversation } = await supabase
          .from("conversations")
          .select("buyer_id, seller_id")
          .eq("id", message.conversation_id)
          .single();

        if (!conversation) return;
        if (conversation.buyer_id !== userId && conversation.seller_id !== userId) return;

        // Get sender name
        const { data: senderProfile } = await supabase
          .from("profiles")
          .select("full_name")
          .eq("user_id", message.sender_id)
          .single();

        const senderName = senderProfile?.full_name || "Someone";
        
        onNewMessage(message, senderName);

        // Show browser notification
        let body = message.content || "";
        if (message.message_type === "image") body = "📷 Image";
        if (message.message_type === "voice") body = "🎤 Voice message";
        if (message.message_type === "file") body = "📎 File";
        if (message.message_type === "sticker") body = "🎭 Sticker";

        showBrowserNotification(`${senderName}`, {
          body,
          tag: `msg-${message.id}`,
          data: {
            type: "message",
            conversation_id: message.conversation_id,
            sender_id: message.sender_id
          }
        });
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};
