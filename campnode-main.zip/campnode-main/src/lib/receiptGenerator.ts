import { format } from "date-fns";

export interface ReceiptData {
  transactionReference: string;
  date: Date;
  productName: string;
  quantity?: number;
  unitPrice?: number;
  totalAmount: number;
  buyerName: string;
  sellerName?: string;
  paymentMethod?: string;
  status: string;
  type: "buyer" | "seller";
}

// Base64 encoded simple CampNode logo for receipts
const CAMPNODE_LOGO_BASE64 = `data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMjAiIGZpbGw9IiM2MzY2ZjEiLz4KPHBhdGggZD0iTTE1IDI1VjE1TDI1IDIwTDE1IDI1WiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+`;

const getStatusColor = (status: string) => {
  const s = status.toLowerCase();
  if (s === "completed" || s === "paid" || s === "successful") return "#22c55e";
  if (s === "pending") return "#f59e0b";
  if (s === "failed" || s === "cancelled") return "#ef4444";
  return "#6b7280";
};

export const generateReceiptText = (data: ReceiptData): string => {
  const line = "═".repeat(50);
  const thinLine = "─".repeat(50);
  const typeLabel = data.type === "buyer" ? "PURCHASE RECEIPT" : "SALES RECEIPT";
  
  return `
${line}
                    CAMPNODE
              Campus Marketplace
${line}

              ${typeLabel}
               
Transaction Ref: ${data.transactionReference}
Date: ${format(data.date, "PPpp")}

${thinLine}
ITEM DETAILS
${thinLine}

Product: ${data.productName}
${data.quantity ? `Quantity: ${data.quantity}` : ""}
${data.unitPrice ? `Unit Price: ₦${data.unitPrice.toLocaleString()}` : ""}

${thinLine}
PAYMENT SUMMARY
${thinLine}

Total ${data.type === "buyer" ? "Paid" : "Received"}: ₦${data.totalAmount.toLocaleString()}
Payment Status: ${data.status.toUpperCase()}

${thinLine}
${data.type === "buyer" ? "CUSTOMER" : "SELLER"} DETAILS
${thinLine}

Name: ${data.type === "buyer" ? data.buyerName : data.sellerName}
${data.type === "buyer" && data.sellerName ? `Seller: ${data.sellerName}` : ""}
${data.type === "seller" && data.buyerName ? `Buyer: ${data.buyerName}` : ""}

${line}

Thank you for ${data.type === "buyer" ? "your purchase" : "selling on CampNode"}!

Website: campnode.lovable.app
Email: support@campnode.com

Trade with confidence on your campus marketplace.

${line}
`.trim();
};

export const generateReceiptHTML = (data: ReceiptData): string => {
  const statusColor = getStatusColor(data.status);
  const typeLabel = data.type === "buyer" ? "Purchase Receipt" : "Sales Receipt";
  const amountLabel = data.type === "buyer" ? "Amount Paid" : "Amount Earned";
  
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${typeLabel} - ${data.transactionReference}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      min-height: 100vh;
      padding: 20px;
      display: flex;
      justify-content: center;
      align-items: flex-start;
    }
    .receipt {
      max-width: 420px;
      width: 100%;
      background: white;
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 25px 50px -12px rgba(0,0,0,0.15);
    }
    .header {
      background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #a855f7 100%);
      color: white;
      padding: 28px 24px;
      text-align: center;
      position: relative;
    }
    .header::after {
      content: '';
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
      width: 40px;
      height: 20px;
      background: white;
      border-radius: 50% 50% 0 0 / 100% 100% 0 0;
    }
    .logo-container {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      margin-bottom: 8px;
    }
    .logo { width: 36px; height: 36px; border-radius: 10px; }
    .brand-name { font-size: 26px; font-weight: 700; letter-spacing: -0.5px; }
    .header p { opacity: 0.9; font-size: 14px; margin-bottom: 16px; }
    .receipt-type {
      display: inline-block;
      background: rgba(255,255,255,0.2);
      padding: 6px 16px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .status {
      display: inline-block;
      margin-top: 12px;
      padding: 6px 20px;
      background: ${statusColor};
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .body { padding: 32px 24px 24px; }
    .amount {
      text-align: center;
      padding: 24px 0;
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      border-radius: 16px;
      margin-bottom: 24px;
    }
    .amount-value { 
      font-size: 42px; 
      font-weight: 700; 
      color: #1e293b;
      letter-spacing: -1px;
    }
    .amount-label { 
      color: #64748b; 
      font-size: 14px; 
      margin-top: 4px;
      font-weight: 500;
    }
    .details { }
    .detail-row {
      display: flex;
      justify-content: space-between;
      padding: 14px 0;
      font-size: 14px;
      border-bottom: 1px solid #f1f5f9;
    }
    .detail-row:last-child { border-bottom: none; }
    .detail-label { color: #64748b; font-weight: 500; }
    .detail-value { 
      font-weight: 600; 
      color: #1e293b; 
      text-align: right; 
      max-width: 55%;
      word-break: break-word;
    }
    .footer {
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      padding: 24px;
      text-align: center;
    }
    .footer-thanks {
      font-size: 15px;
      font-weight: 600;
      color: #1e293b;
      margin-bottom: 12px;
    }
    .footer-note {
      font-size: 12px;
      color: #64748b;
      margin-bottom: 16px;
      line-height: 1.5;
    }
    .footer-brand {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      font-size: 16px;
      font-weight: 700;
      color: #6366f1;
    }
    .footer-brand img { width: 24px; height: 24px; border-radius: 6px; }
    .footer-links {
      margin-top: 12px;
      font-size: 11px;
      color: #94a3b8;
    }
    .footer-links a {
      color: #6366f1;
      text-decoration: none;
    }
    @media print {
      body { background: white; padding: 0; }
      .receipt { box-shadow: none; max-width: none; }
    }
  </style>
</head>
<body>
  <div class="receipt">
    <div class="header">
      <div class="logo-container">
        <img src="${CAMPNODE_LOGO_BASE64}" alt="CampNode" class="logo" />
        <span class="brand-name">CampNode</span>
      </div>
      <p>Campus Marketplace</p>
      <span class="receipt-type">${typeLabel}</span>
      <br/>
      <span class="status">${data.status}</span>
    </div>
    
    <div class="body">
      <div class="amount">
        <div class="amount-value">₦${data.totalAmount.toLocaleString()}</div>
        <div class="amount-label">${amountLabel}</div>
      </div>
      
      <div class="details">
        <div class="detail-row">
          <span class="detail-label">Reference</span>
          <span class="detail-value">${data.transactionReference}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Date</span>
          <span class="detail-value">${format(data.date, "PPp")}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Product</span>
          <span class="detail-value">${data.productName}</span>
        </div>
        ${data.quantity ? `
        <div class="detail-row">
          <span class="detail-label">Quantity</span>
          <span class="detail-value">${data.quantity}</span>
        </div>
        ` : ''}
        <div class="detail-row">
          <span class="detail-label">${data.type === "buyer" ? "Customer" : "Seller"}</span>
          <span class="detail-value">${data.type === "buyer" ? data.buyerName : data.sellerName}</span>
        </div>
        ${data.type === "buyer" && data.sellerName ? `
        <div class="detail-row">
          <span class="detail-label">Seller</span>
          <span class="detail-value">${data.sellerName}</span>
        </div>
        ` : ''}
        ${data.type === "seller" && data.buyerName ? `
        <div class="detail-row">
          <span class="detail-label">Buyer</span>
          <span class="detail-value">${data.buyerName}</span>
        </div>
        ` : ''}
      </div>
    </div>
    
    <div class="footer">
      <p class="footer-thanks">Thank you for ${data.type === "buyer" ? "your purchase" : "selling on CampNode"}!</p>
      <p class="footer-note">
        This is an electronic receipt from CampNode.<br/>
        Trade with confidence on your campus marketplace.
      </p>
      <div class="footer-brand">
        <img src="${CAMPNODE_LOGO_BASE64}" alt="" />
        CampNode
      </div>
      <p class="footer-links">
        <a href="https://campnode.lovable.app">campnode.lovable.app</a> • support@campnode.com
      </p>
    </div>
  </div>
</body>
</html>
`.trim();
};

export const generateReceiptJSON = (data: ReceiptData): string => {
  return JSON.stringify({
    receipt: {
      type: data.type === "buyer" ? "purchase_receipt" : "sales_receipt",
      reference: data.transactionReference,
      date: data.date.toISOString(),
      status: data.status
    },
    transaction: {
      product: data.productName,
      quantity: data.quantity || 1,
      unitPrice: data.unitPrice || data.totalAmount,
      totalAmount: data.totalAmount,
      currency: "NGN"
    },
    parties: {
      buyer: data.buyerName,
      seller: data.sellerName || null
    },
    platform: {
      name: "CampNode",
      website: "campnode.lovable.app",
      email: "support@campnode.com",
      description: "Campus Marketplace"
    },
    generated: new Date().toISOString()
  }, null, 2);
};

export const downloadReceiptAsPDF = async (data: ReceiptData) => {
  const html = generateReceiptHTML(data);
  
  // Create a new window for printing
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    // Fallback to HTML download
    downloadReceiptAsHTML(data);
    return;
  }
  
  printWindow.document.write(html);
  printWindow.document.close();
  
  // Wait for content to load then trigger print (save as PDF)
  printWindow.onload = () => {
    setTimeout(() => {
      printWindow.print();
    }, 500);
  };
};

export const downloadReceiptAsText = (data: ReceiptData) => {
  const text = generateReceiptText(data);
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `receipt-${data.type}-${data.transactionReference}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const downloadReceiptAsHTML = (data: ReceiptData) => {
  const html = generateReceiptHTML(data);
  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `receipt-${data.type}-${data.transactionReference}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const downloadReceiptAsJSON = (data: ReceiptData) => {
  const json = generateReceiptJSON(data);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `receipt-${data.type}-${data.transactionReference}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const downloadReceiptAsImage = async (data: ReceiptData): Promise<void> => {
  // Create a temporary container
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.left = '-9999px';
  container.style.top = '0';
  document.body.appendChild(container);
  
  // Create an iframe to render the HTML
  const iframe = document.createElement('iframe');
  iframe.style.width = '500px';
  iframe.style.height = '800px';
  iframe.style.border = 'none';
  container.appendChild(iframe);
  
  const html = generateReceiptHTML(data);
  
  return new Promise((resolve) => {
    iframe.onload = () => {
      // Use html2canvas alternative via canvas
      setTimeout(() => {
        // For now, open the HTML in a new tab for screenshot
        const newWindow = window.open();
        if (newWindow) {
          newWindow.document.write(html);
          newWindow.document.close();
          alert('Right-click on the receipt and select "Save image as..." or use your browser screenshot tool.');
        }
        document.body.removeChild(container);
        resolve();
      }, 500);
    };
    
    iframe.contentDocument?.write(html);
    iframe.contentDocument?.close();
  });
};
