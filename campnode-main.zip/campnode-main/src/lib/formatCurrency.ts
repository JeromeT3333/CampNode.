/**
 * Format a number as Nigerian Naira currency
 * Uses Unicode Naira symbol ₦ (U+20A6) - NOT strikethrough N
 */
export const formatNaira = (amount: number | null | undefined): string => {
  if (amount === null || amount === undefined) return "\u20A60";
  
  // Format number with thousand separators
  const formatted = new Intl.NumberFormat("en-NG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
  
  // Use Unicode escape for Naira symbol to ensure correct rendering
  return `\u20A6${formatted}`;
};

/**
 * Format large numbers with K, M, B suffixes
 */
export const formatCompactNumber = (num: number): string => {
  if (num >= 1000000000) {
    return (num / 1000000000).toFixed(1) + "B";
  }
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M";
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + "K";
  }
  return num.toString();
};

/**
 * Format Naira with compact notation for large values
 */
export const formatNairaCompact = (amount: number): string => {
  return "\u20A6" + formatCompactNumber(amount);
};
