import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index";
import About from "./pages/About";
import Search from "./pages/Search";
import Shops from "./pages/Shops";
import ShopDetail from "./pages/ShopDetail";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetail";
import Auth from "./pages/Auth";
import CompleteProfile from "./pages/CompleteProfile";
import Dashboard from "./pages/Dashboard";
import CreateShop from "./pages/CreateShop";
import AddProduct from "./pages/AddProduct";
import Profile from "./pages/Profile";
import SellerDashboard from "./pages/SellerDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import Orders from "./pages/Orders";
import Chat from "./pages/Chat";
import DirectChat from "./pages/DirectChat";
import Checkout from "./pages/Checkout";
import PaymentComplete from "./pages/PaymentComplete";
import NotFound from "./pages/NotFound";
import Settings from "./pages/Settings";
import MyListings from "./pages/MyListings";
import MyShops from "./pages/MyShops";
import Notifications from "./pages/Notifications";
import Receipts from "./pages/Receipts";
import ShopDashboard from "./pages/ShopDashboard";
import UserProfile from "./pages/UserProfile";
import Conversations from "./pages/Conversations";
import ConversationChat from "./pages/ConversationChat";
import SellerWithdrawals from "./pages/SellerWithdrawals";
import SellerWallet from "./pages/SellerWallet";

// Admin pages
import AdminOverview from "./pages/admin/AdminOverview";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminBroadcast from "./pages/admin/AdminBroadcast";
import AdminShops from "./pages/admin/AdminShops";
import AdminProducts from "./pages/admin/AdminProducts";
import AdminOrders from "./pages/admin/AdminOrders";
import AdminTransactions from "./pages/admin/AdminTransactions";
import AdminPremium from "./pages/admin/AdminPremium";
import AdminRestrictions from "./pages/admin/AdminRestrictions";
import AdminSettings from "./pages/admin/AdminSettings";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/about" element={<About />} />
              <Route path="/search" element={<Search />} />
              <Route path="/shops" element={<Shops />} />
              <Route path="/shop/:id" element={<ShopDetail />} />
              <Route path="/products" element={<Products />} />
              <Route path="/product/:id" element={<ProductDetail />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/complete-profile" element={<CompleteProfile />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/create-shop" element={<CreateShop />} />
              <Route path="/add-product" element={<AddProduct />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/seller-dashboard" element={<SellerDashboard />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/orders" element={<Orders />} />
              <Route path="/chat/:orderId" element={<Chat />} />
              <Route path="/conversation/:conversationId" element={<ConversationChat />} />
              <Route path="/dm/:recipientId" element={<DirectChat />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/payment-complete" element={<PaymentComplete />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/my-listings" element={<MyListings />} />
              <Route path="/my-shops" element={<MyShops />} />
              <Route path="/shop-dashboard/:shopId" element={<ShopDashboard />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/receipts" element={<Receipts />} />
              <Route path="/withdrawals" element={<SellerWithdrawals />} />
              <Route path="/wallet" element={<SellerWallet />} />
              <Route path="/user/:userId" element={<UserProfile />} />
              <Route path="/conversations" element={<Conversations />} />
              {/* Admin Routes */}
              <Route path="/admin" element={<AdminOverview />} />
              <Route path="/admin/users" element={<AdminUsers />} />
              <Route path="/admin/shops" element={<AdminShops />} />
              <Route path="/admin/products" element={<AdminProducts />} />
              <Route path="/admin/orders" element={<AdminOrders />} />
              <Route path="/admin/transactions" element={<AdminTransactions />} />
              <Route path="/admin/premium" element={<AdminPremium />} />
              <Route path="/admin/restrictions" element={<AdminRestrictions />} />
              <Route path="/admin/broadcast" element={<AdminBroadcast />} />
              <Route path="/admin/settings" element={<AdminSettings />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
