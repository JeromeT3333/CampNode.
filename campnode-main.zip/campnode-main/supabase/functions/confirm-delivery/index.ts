import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { order_id } = await req.json();

    if (!order_id) {
      return new Response(
        JSON.stringify({ status: "error", message: "Order ID is required" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get authenticated user
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ status: "error", message: "Authentication required" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: userData, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !userData?.user) {
      return new Response(
        JSON.stringify({ status: "error", message: "Invalid authentication" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const buyerId = userData.user.id;

    // Get order and verify buyer
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('*')
      .eq('id', order_id)
      .eq('buyer_id', buyerId)
      .single();

    if (orderError || !order) {
      return new Response(
        JSON.stringify({ status: "error", message: "Order not found or you are not the buyer" }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (order.escrow_status !== 'held') {
      return new Response(
        JSON.stringify({ status: "error", message: "Order is not in escrow or already confirmed" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get escrow record
    const { data: escrow, error: escrowError } = await supabase
      .from('escrow_orders')
      .select('*')
      .eq('order_id', order_id)
      .eq('escrow_status', 'held')
      .single();

    if (escrowError || !escrow) {
      return new Response(
        JSON.stringify({ status: "error", message: "Escrow record not found" }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get seller wallet
    const { data: wallet, error: walletError } = await supabase
      .from('seller_wallets')
      .select('*')
      .eq('seller_id', order.seller_id)
      .single();

    if (walletError || !wallet) {
      return new Response(
        JSON.stringify({ status: "error", message: "Seller wallet not found" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const sellerAmount = escrow.seller_amount;
    const newPending = wallet.pending_balance - sellerAmount;
    const newAvailable = wallet.available_balance + sellerAmount;

    // Move from pending to available
    await supabase
      .from('seller_wallets')
      .update({
        pending_balance: Math.max(0, newPending),
        available_balance: newAvailable,
        updated_at: new Date().toISOString()
      })
      .eq('id', wallet.id);

    // Log wallet transaction
    await supabase
      .from('wallet_transactions')
      .insert({
        wallet_id: wallet.id,
        order_id,
        transaction_type: 'escrow_release',
        amount: sellerAmount,
        balance_before: wallet.available_balance,
        balance_after: newAvailable,
        balance_type: 'available',
        description: 'Escrow released - buyer confirmed delivery'
      });

    // Update escrow status
    await supabase
      .from('escrow_orders')
      .update({
        escrow_status: 'released',
        released_at: new Date().toISOString(),
        confirmed_by: buyerId,
        confirmed_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', escrow.id);

    // Update order status
    await supabase
      .from('orders')
      .update({
        escrow_status: 'released',
        buyer_confirmed_at: new Date().toISOString(),
        status: 'completed',
        updated_at: new Date().toISOString()
      })
      .eq('id', order_id);

    // Close the order chat
    await supabase.rpc('close_order_chat', { p_order_id: order_id });

    // Notify seller
    await supabase
      .from('notifications')
      .insert({
        user_id: order.seller_id,
        type: 'payment',
        title: 'Payment Released!',
        message: `₦${sellerAmount.toLocaleString()} has been added to your available balance`,
        data: { order_id }
      });

    return new Response(
      JSON.stringify({
        status: "success",
        message: "Delivery confirmed and payment released to seller",
        data: {
          order_id,
          amount_released: sellerAmount
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error("Confirm delivery error:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ status: "error", message: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
