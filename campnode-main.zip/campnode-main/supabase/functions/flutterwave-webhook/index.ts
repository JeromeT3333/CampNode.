import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, verif-hash',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const webhookSecret = Deno.env.get('FLUTTERWAVE_WEBHOOK_SECRET');
    const secretKey = Deno.env.get('FLUTTERWAVE_SECRET_KEY');
    
    // Verify webhook signature
    const signature = req.headers.get('verif-hash');
    if (!signature || signature !== webhookSecret) {
      console.error("Invalid webhook signature");
      return new Response(
        JSON.stringify({ status: "error", message: "Invalid signature" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const payload = await req.json();
    console.log("Webhook payload:", JSON.stringify(payload));

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    if (payload.event === "charge.completed" && payload.data.status === "successful") {
      const txRef = payload.data.tx_ref;
      const flwRef = payload.data.flw_ref;
      const amount = payload.data.amount;

      console.log(`Processing successful payment: ${txRef}, amount: ${amount}`);

      // Verify the transaction with Flutterwave
      const verifyResponse = await fetch(
        `https://api.flutterwave.com/v3/transactions/${payload.data.id}/verify`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${secretKey}`,
            'Content-Type': 'application/json',
          }
        }
      );
      
      const verifyData = await verifyResponse.json();
      console.log("Verification response:", JSON.stringify(verifyData));

      if (verifyData.status !== "success" || verifyData.data.status !== "successful") {
        console.error("Transaction verification failed");
        return new Response(
          JSON.stringify({ status: "error", message: "Verification failed" }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Parse tx_ref to get order details (format: CAMPNODE-{orderId}-{timestamp})
      const txParts = txRef.split('-');
      if (txParts.length < 2) {
        console.error("Invalid tx_ref format");
        return new Response(
          JSON.stringify({ status: "error", message: "Invalid transaction reference" }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Get platform fee percentage
      const { data: settings } = await supabase
        .from('platform_settings')
        .select('setting_value')
        .eq('setting_key', 'platform_fee_percentage')
        .single();
      
      const feePercentage = settings ? parseFloat(settings.setting_value) : 5;
      const platformFee = (amount * feePercentage) / 100;
      const sellerAmount = amount - platformFee;

      // Update transaction record
      const { data: transaction, error: txError } = await supabase
        .from('transactions')
        .update({
          flutterwave_reference: flwRef,
          payment_status: 'completed',
          updated_at: new Date().toISOString()
        })
        .eq('transaction_reference', txRef)
        .select()
        .single();

      if (txError) {
        console.error("Error updating transaction:", txError);
      }

      // Update order status
      if (transaction?.order_id) {
        await supabase
          .from('orders')
          .update({
            payment_status: 'paid',
            payment_reference: flwRef,
            status: 'confirmed'
          })
          .eq('id', transaction.order_id);
      }

      // Get seller bank details and initiate payout
      if (transaction?.seller_id) {
        const { data: bankDetails } = await supabase
          .from('seller_bank_details')
          .select('*')
          .eq('seller_id', transaction.seller_id)
          .eq('verification_status', 'verified')
          .single();

        if (bankDetails) {
          // Create payout record
          const payoutRef = `PAYOUT-${transaction.id}-${Date.now()}`;
          
          const { data: payout, error: payoutError } = await supabase
            .from('payouts')
            .insert({
              payout_reference: payoutRef,
              transaction_id: transaction.id,
              seller_id: transaction.seller_id,
              amount: sellerAmount,
              bank_code: bankDetails.bank_code,
              account_number: bankDetails.account_number,
              account_name: bankDetails.account_name,
              status: 'pending'
            })
            .select()
            .single();

          if (payoutError) {
            console.error("Error creating payout:", payoutError);
          } else {
            // Initiate transfer to seller
            const transferResponse = await fetch(
              'https://api.flutterwave.com/v3/transfers',
              {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${secretKey}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  account_bank: bankDetails.bank_code,
                  account_number: bankDetails.account_number,
                  amount: sellerAmount,
                  narration: `CampNode payout for order`,
                  currency: 'NGN',
                  reference: payoutRef,
                  debit_currency: 'NGN'
                })
              }
            );

            const transferData = await transferResponse.json();
            console.log("Transfer response:", JSON.stringify(transferData));

            if (transferData.status === "success") {
              await supabase
                .from('payouts')
                .update({
                  flutterwave_reference: transferData.data.id,
                  status: 'processing'
                })
                .eq('id', payout.id);
            } else {
              await supabase
                .from('payouts')
                .update({
                  status: 'failed',
                  failure_reason: transferData.message || 'Transfer initiation failed'
                })
                .eq('id', payout.id);
            }
          }
        } else {
          console.log("No verified bank details found for seller");
        }
      }

      return new Response(
        JSON.stringify({ status: "success", message: "Payment processed" }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Handle transfer webhooks (payout status updates)
    if (payload.event === "transfer.completed") {
      const reference = payload.data.reference;
      const status = payload.data.status === "SUCCESSFUL" ? "completed" : "failed";
      
      await supabase
        .from('payouts')
        .update({
          status,
          failure_reason: status === "failed" ? payload.data.complete_message : null
        })
        .eq('payout_reference', reference);

      console.log(`Payout ${reference} status updated to ${status}`);
    }

    return new Response(
      JSON.stringify({ status: "success" }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    console.error("Webhook error:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ status: "error", message: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
