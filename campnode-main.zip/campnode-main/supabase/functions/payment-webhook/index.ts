import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, verif-hash',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const webhookSecret = Deno.env.get('FLUTTERWAVE_WEBHOOK_SECRET');
  const secretKey = Deno.env.get('FLUTTERWAVE_SECRET_KEY');
  
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    // Verify webhook signature
    const signature = req.headers.get('verif-hash');
    if (!signature || signature !== webhookSecret) {
      console.error("Invalid webhook signature");
      await logWebhook(supabase, 'unknown', {}, 'failed', 'Invalid signature');
      return new Response(
        JSON.stringify({ status: "error", message: "Invalid signature" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const payload = await req.json();
    console.log("Webhook payload:", JSON.stringify(payload));

    // Check for duplicate webhook
    const { data: existingLog } = await supabase
      .from('webhook_logs')
      .select('id')
      .eq('payload->>id', payload.data?.id?.toString())
      .eq('status', 'processed')
      .single();

    if (existingLog) {
      console.log("Duplicate webhook, skipping");
      return new Response(
        JSON.stringify({ status: "success", message: "Already processed" }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Log webhook receipt
    const webhookLogId = await logWebhook(supabase, payload.event, payload, 'received');

    // Handle charge.completed event
    if (payload.event === "charge.completed" && payload.data.status === "successful") {
      await handleChargeCompleted(supabase, secretKey!, payload, webhookLogId);
    }

    // Handle transfer events (for withdrawals)
    if (payload.event === "transfer.completed") {
      await handleTransferCompleted(supabase, payload, webhookLogId);
    }

    if (payload.event === "transfer.failed") {
      await handleTransferFailed(supabase, payload, webhookLogId);
    }

    return new Response(
      JSON.stringify({ status: "success" }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error("Webhook error:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ status: "error", message: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

async function logWebhook(
  supabase: ReturnType<typeof createClient>,
  eventType: string,
  payload: Record<string, unknown>,
  status: string,
  errorMessage?: string
): Promise<string> {
  const { data } = await supabase
    .from('webhook_logs')
    .insert({
      event_type: eventType,
      payload,
      status,
      error_message: errorMessage,
      processed_at: status === 'processed' ? new Date().toISOString() : null
    })
    .select('id')
    .single();
  
  return data?.id || '';
}

async function handleChargeCompleted(
  supabase: ReturnType<typeof createClient>,
  secretKey: string,
  payload: Record<string, unknown>,
  webhookLogId: string
) {
  const data = payload.data as Record<string, unknown>;
  const txRef = data.tx_ref as string;
  const flwRef = data.flw_ref as string;
  const amount = data.amount as number;
  const transactionId = data.id as number;

  console.log(`Processing charge.completed: ${txRef}, amount: ${amount}`);

  // Verify transaction with Flutterwave
  const verifyResponse = await fetch(
    `https://api.flutterwave.com/v3/transactions/${transactionId}/verify`,
    {
      headers: {
        'Authorization': `Bearer ${secretKey}`,
        'Content-Type': 'application/json',
      }
    }
  );
  
  const verifyData = await verifyResponse.json();
  console.log("Verification:", JSON.stringify(verifyData));

  if (verifyData.status !== "success" || verifyData.data.status !== "successful") {
    console.error("Transaction verification failed");
    await supabase.from('webhook_logs').update({ 
      status: 'failed', 
      error_message: 'Verification failed' 
    }).eq('id', webhookLogId);
    return;
  }

  // Get actual Flutterwave fee
  const actualFlwFee = verifyData.data.app_fee || 0;

  // Get transaction and order details
  const { data: transaction } = await supabase
    .from('transactions')
    .select('*, orders(*)')
    .eq('transaction_reference', txRef)
    .single();

  if (!transaction) {
    console.error("Transaction not found");
    return;
  }

  const order = transaction.orders;
  const useEscrow = order.escrow_status !== 'not_applicable';

  // Update transaction with Flutterwave reference
  await supabase
    .from('transactions')
    .update({
      flutterwave_reference: flwRef,
      payment_status: 'completed',
      updated_at: new Date().toISOString()
    })
    .eq('id', transaction.id);

  // Update order status
  await supabase
    .from('orders')
    .update({
      payment_status: 'paid',
      payment_reference: flwRef,
      status: useEscrow ? 'confirmed' : 'completed',
      escrow_status: useEscrow ? 'held' : 'not_applicable'
    })
    .eq('id', order.id);

  if (useEscrow) {
    // Create escrow record
    const serviceFee = order.service_fee || 0;
    const sellerAmount = transaction.seller_amount;
    const productPrice = sellerAmount / 0.95; // Back-calculate P from seller_amount
    const vatAmount = amount * 0.015; // 1.5% VAT
    const platformAmount = serviceFee - vatAmount - actualFlwFee;

    await supabase
      .from('escrow_orders')
      .insert({
        order_id: order.id,
        seller_id: transaction.seller_id,
        buyer_id: transaction.buyer_id,
        product_price: productPrice,
        service_fee: serviceFee,
        seller_amount: sellerAmount,
        platform_amount: Math.max(0, platformAmount),
        flutterwave_fee: actualFlwFee,
        vat_amount: vatAmount,
        escrow_status: 'held'
      });

    // Credit seller's pending balance
    await creditSellerPending(supabase, transaction.seller_id, sellerAmount, order.id);

    // Credit platform wallet
    if (platformAmount > 0) {
      await creditPlatformWallet(supabase, platformAmount, order.id);
    }
  } else {
    // For low-value orders without escrow, credit seller's available balance directly
    await creditSellerAvailable(supabase, transaction.seller_id, transaction.seller_amount, order.id);
  }

  // Create notification for seller
  await supabase
    .from('notifications')
    .insert({
      user_id: transaction.seller_id,
      type: 'order',
      title: 'New Order Received!',
      message: `You have a new order worth ₦${transaction.seller_amount.toLocaleString()}`,
      data: { order_id: order.id }
    });

  // Update webhook log
  await supabase.from('webhook_logs').update({ 
    status: 'processed',
    processed_at: new Date().toISOString()
  }).eq('id', webhookLogId);
}

async function handleTransferCompleted(
  supabase: ReturnType<typeof createClient>,
  payload: Record<string, unknown>,
  webhookLogId: string
) {
  const data = payload.data as Record<string, unknown>;
  const reference = data.reference as string;
  const status = data.status === "SUCCESSFUL" ? "completed" : "failed";

  await supabase
    .from('payouts')
    .update({
      status,
      updated_at: new Date().toISOString()
    })
    .eq('payout_reference', reference);

  await supabase.from('webhook_logs').update({ 
    status: 'processed',
    processed_at: new Date().toISOString()
  }).eq('id', webhookLogId);

  console.log(`Transfer ${reference} completed with status: ${status}`);
}

async function handleTransferFailed(
  supabase: ReturnType<typeof createClient>,
  payload: Record<string, unknown>,
  webhookLogId: string
) {
  const data = payload.data as Record<string, unknown>;
  const reference = data.reference as string;
  const message = data.complete_message as string || "Transfer failed";

  // Get payout to refund wallet
  const { data: payout } = await supabase
    .from('payouts')
    .select('*, seller_wallets(*)')
    .eq('payout_reference', reference)
    .single();

  if (payout) {
    // Refund the amount back to available balance
    await supabase
      .from('seller_wallets')
      .update({
        available_balance: payout.seller_wallets.available_balance + payout.amount,
        updated_at: new Date().toISOString()
      })
      .eq('id', payout.seller_wallets.id);

    // Log refund transaction
    await supabase
      .from('wallet_transactions')
      .insert({
        wallet_id: payout.seller_wallets.id,
        transaction_type: 'withdrawal_refund',
        amount: payout.amount,
        balance_before: payout.seller_wallets.available_balance,
        balance_after: payout.seller_wallets.available_balance + payout.amount,
        balance_type: 'available',
        description: `Withdrawal refund: ${message}`,
        reference
      });

    await supabase
      .from('payouts')
      .update({
        status: 'failed',
        failure_reason: message,
        updated_at: new Date().toISOString()
      })
      .eq('id', payout.id);
  }

  await supabase.from('webhook_logs').update({ 
    status: 'processed',
    processed_at: new Date().toISOString()
  }).eq('id', webhookLogId);

  console.log(`Transfer ${reference} failed: ${message}`);
}

async function creditSellerPending(
  supabase: ReturnType<typeof createClient>,
  sellerId: string,
  amount: number,
  orderId: string
) {
  // Get or create wallet
  let { data: wallet } = await supabase
    .from('seller_wallets')
    .select('*')
    .eq('seller_id', sellerId)
    .single();

  if (!wallet) {
    const { data: newWallet } = await supabase
      .from('seller_wallets')
      .insert({ seller_id: sellerId })
      .select()
      .single();
    wallet = newWallet;
  }

  if (!wallet) {
    console.error("Failed to get/create wallet");
    return;
  }

  const newPending = wallet.pending_balance + amount;
  const newTotal = wallet.total_earnings + amount;

  await supabase
    .from('seller_wallets')
    .update({
      pending_balance: newPending,
      total_earnings: newTotal,
      updated_at: new Date().toISOString()
    })
    .eq('id', wallet.id);

  await supabase
    .from('wallet_transactions')
    .insert({
      wallet_id: wallet.id,
      order_id: orderId,
      transaction_type: 'escrow_credit',
      amount,
      balance_before: wallet.pending_balance,
      balance_after: newPending,
      balance_type: 'pending',
      description: 'Payment received - held in escrow'
    });
}

async function creditSellerAvailable(
  supabase: ReturnType<typeof createClient>,
  sellerId: string,
  amount: number,
  orderId: string
) {
  let { data: wallet } = await supabase
    .from('seller_wallets')
    .select('*')
    .eq('seller_id', sellerId)
    .single();

  if (!wallet) {
    const { data: newWallet } = await supabase
      .from('seller_wallets')
      .insert({ seller_id: sellerId })
      .select()
      .single();
    wallet = newWallet;
  }

  if (!wallet) return;

  const newAvailable = wallet.available_balance + amount;
  const newTotal = wallet.total_earnings + amount;

  await supabase
    .from('seller_wallets')
    .update({
      available_balance: newAvailable,
      total_earnings: newTotal,
      updated_at: new Date().toISOString()
    })
    .eq('id', wallet.id);

  await supabase
    .from('wallet_transactions')
    .insert({
      wallet_id: wallet.id,
      order_id: orderId,
      transaction_type: 'instant_credit',
      amount,
      balance_before: wallet.available_balance,
      balance_after: newAvailable,
      balance_type: 'available',
      description: 'Payment received - instant settlement'
    });
}

async function creditPlatformWallet(
  supabase: ReturnType<typeof createClient>,
  amount: number,
  orderId: string
) {
  const { data: platformWallet } = await supabase
    .from('platform_wallet')
    .select('*')
    .single();

  if (!platformWallet) return;

  const newBalance = platformWallet.balance + amount;
  const newTotal = platformWallet.total_earnings + amount;

  await supabase
    .from('platform_wallet')
    .update({
      balance: newBalance,
      total_earnings: newTotal,
      updated_at: new Date().toISOString()
    })
    .eq('id', platformWallet.id);

  await supabase
    .from('platform_wallet_transactions')
    .insert({
      transaction_type: 'commission',
      amount,
      balance_before: platformWallet.balance,
      balance_after: newBalance,
      order_id: orderId,
      description: 'Platform commission from order'
    });
}
