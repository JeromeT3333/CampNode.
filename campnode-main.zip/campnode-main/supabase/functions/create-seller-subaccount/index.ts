import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { bank_code, account_number, business_name } = await req.json();

    if (!bank_code || !account_number) {
      return new Response(
        JSON.stringify({ status: "error", message: "Bank code and account number are required" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const secretKey = Deno.env.get('FLUTTERWAVE_SECRET_KEY');

    if (!secretKey) {
      return new Response(
        JSON.stringify({ status: "error", message: "Payment gateway not configured" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get authenticated user
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ status: "error", message: "Authentication required" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: userData, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !userData?.user) {
      return new Response(
        JSON.stringify({ status: "error", message: "Invalid authentication" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const sellerId = userData.user.id;

    // Check if subaccount already exists
    const { data: existingSubaccount } = await supabase
      .from('seller_subaccounts')
      .select('subaccount_id')
      .eq('seller_id', sellerId)
      .single();

    if (existingSubaccount) {
      return new Response(
        JSON.stringify({ 
          status: "success", 
          message: "Subaccount already exists",
          data: { subaccount_id: existingSubaccount.subaccount_id }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // First verify the bank account
    const verifyResponse = await fetch(
      'https://api.flutterwave.com/v3/accounts/resolve',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${secretKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          account_number,
          account_bank: bank_code
        })
      }
    );

    const verifyData = await verifyResponse.json();
    console.log("Bank verification:", JSON.stringify(verifyData));

    if (verifyData.status !== "success") {
      return new Response(
        JSON.stringify({ status: "error", message: verifyData.message || "Bank verification failed" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const accountName = verifyData.data.account_name;
    const businessNameFinal = business_name || accountName;

    // Create Flutterwave subaccount
    // Seller receives 95% of product price (split_value = 95)
    const subaccountResponse = await fetch(
      'https://api.flutterwave.com/v3/subaccounts',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${secretKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          account_bank: bank_code,
          account_number: account_number,
          business_name: businessNameFinal,
          business_email: userData.user.email,
          country: "NG",
          split_type: "percentage",
          split_value: 0.95, // Seller gets 95% of original price (decimal format)
        })
      }
    );

    const subaccountData = await subaccountResponse.json();
    console.log("Subaccount creation:", JSON.stringify(subaccountData));

    if (subaccountData.status !== "success") {
      return new Response(
        JSON.stringify({ status: "error", message: subaccountData.message || "Failed to create subaccount" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const subaccountId = subaccountData.data.subaccount_id;

    // Store subaccount in database
    const { error: insertError } = await supabase
      .from('seller_subaccounts')
      .insert({
        seller_id: sellerId,
        subaccount_id: subaccountId,
        business_name: businessNameFinal,
        split_value: 0.95,
        split_type: 'percentage',
        is_active: true
      });

    if (insertError) {
      console.error("Error storing subaccount:", insertError);
      // Don't fail - subaccount was created in Flutterwave
    }

    // Initialize seller wallet
    await supabase.rpc('initialize_seller_wallet', { p_seller_id: sellerId });

    // Update bank details verification status
    await supabase
      .from('seller_bank_details')
      .update({ verification_status: 'verified' })
      .eq('seller_id', sellerId)
      .eq('bank_code', bank_code)
      .eq('account_number', account_number);

    return new Response(
      JSON.stringify({
        status: "success",
        message: "Seller subaccount created successfully",
        data: {
          subaccount_id: subaccountId,
          account_name: accountName,
          business_name: businessNameFinal
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error("Error creating subaccount:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ status: "error", message: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
