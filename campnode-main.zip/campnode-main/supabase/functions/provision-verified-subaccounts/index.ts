import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

/**
 * This function provisions Flutterwave subaccounts for sellers
 * who have verified bank accounts but no subaccount yet.
 * Can be called manually or scheduled to run periodically.
 */
Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const secretKey = Deno.env.get('FLUTTERWAVE_SECRET_KEY');

    if (!secretKey) {
      return new Response(
        JSON.stringify({ status: "error", message: "Payment gateway not configured" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Find all verified bank accounts that don't have a subaccount yet
    const { data: verifiedAccounts, error: fetchError } = await supabase
      .from('seller_bank_details')
      .select('seller_id, bank_code, account_number, account_name, bank_name')
      .eq('verification_status', 'verified');

    if (fetchError) {
      console.error("Error fetching verified accounts:", fetchError);
      return new Response(
        JSON.stringify({ status: "error", message: "Failed to fetch verified accounts" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!verifiedAccounts || verifiedAccounts.length === 0) {
      return new Response(
        JSON.stringify({ status: "success", message: "No verified accounts to process", processed: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const results = {
      processed: 0,
      created: 0,
      skipped: 0,
      failed: 0,
      details: [] as Array<{ seller_id: string; status: string; message: string }>
    };

    for (const account of verifiedAccounts) {
      results.processed++;

      // Check if subaccount already exists for this seller
      const { data: existingSubaccount } = await supabase
        .from('seller_subaccounts')
        .select('subaccount_id')
        .eq('seller_id', account.seller_id)
        .single();

      if (existingSubaccount) {
        results.skipped++;
        results.details.push({
          seller_id: account.seller_id,
          status: 'skipped',
          message: 'Subaccount already exists'
        });
        continue;
      }

      // Get seller's email from profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('user_id', account.seller_id)
        .single();

      // Get user email from auth (via service role)
      const { data: authData } = await supabase.auth.admin.getUserById(account.seller_id);
      const sellerEmail = authData?.user?.email || 'seller@campnode.com';

      const businessName = account.account_name || profile?.full_name || 'CampNode Seller';

      try {
        // Create Flutterwave subaccount
        const subaccountResponse = await fetch(
          'https://api.flutterwave.com/v3/subaccounts',
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${secretKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              account_bank: account.bank_code,
              account_number: account.account_number,
              business_name: businessName,
              business_email: sellerEmail,
              country: "NG",
            split_type: "percentage",
            split_value: 0.95, // Seller gets 95% of original price (decimal format)
            })
          }
        );

        const subaccountData = await subaccountResponse.json();
        console.log(`Subaccount creation for ${account.seller_id}:`, JSON.stringify(subaccountData));

        if (subaccountData.status !== "success") {
          results.failed++;
          results.details.push({
            seller_id: account.seller_id,
            status: 'failed',
            message: subaccountData.message || 'Flutterwave API error'
          });
          continue;
        }

        const subaccountId = subaccountData.data.subaccount_id;

        // Store subaccount in database
        const { error: insertError } = await supabase
          .from('seller_subaccounts')
          .insert({
            seller_id: account.seller_id,
            subaccount_id: subaccountId,
            business_name: businessName,
            split_value: 0.95,
            split_type: 'percentage',
            is_active: true
          });

        if (insertError) {
          console.error(`Error storing subaccount for ${account.seller_id}:`, insertError);
          results.failed++;
          results.details.push({
            seller_id: account.seller_id,
            status: 'partial',
            message: 'Subaccount created in Flutterwave but failed to store in database'
          });
          continue;
        }

        // Initialize seller wallet if not exists
        await supabase.rpc('initialize_seller_wallet', { p_seller_id: account.seller_id });

        results.created++;
        results.details.push({
          seller_id: account.seller_id,
          status: 'created',
          message: `Subaccount ${subaccountId} created successfully`
        });

      } catch (apiError) {
        console.error(`API error for ${account.seller_id}:`, apiError);
        results.failed++;
        results.details.push({
          seller_id: account.seller_id,
          status: 'error',
          message: apiError instanceof Error ? apiError.message : 'Unknown error'
        });
      }
    }

    console.log("Provisioning complete:", JSON.stringify(results));

    return new Response(
      JSON.stringify({
        status: "success",
        message: `Processed ${results.processed} accounts: ${results.created} created, ${results.skipped} skipped, ${results.failed} failed`,
        ...results
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error("Error provisioning subaccounts:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ status: "error", message: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
