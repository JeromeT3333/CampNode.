import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const MIN_WITHDRAWAL = 1000; // ₦1,000 minimum

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { amount } = await req.json();

    if (!amount || amount < MIN_WITHDRAWAL) {
      return new Response(
        JSON.stringify({ 
          status: "error", 
          message: `Minimum withdrawal is ₦${MIN_WITHDRAWAL.toLocaleString()}` 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const secretKey = Deno.env.get('FLUTTERWAVE_SECRET_KEY');

    if (!secretKey) {
      return new Response(
        JSON.stringify({ status: "error", message: "Payment gateway not configured" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get authenticated user
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ status: "error", message: "Authentication required" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: userData, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !userData?.user) {
      return new Response(
        JSON.stringify({ status: "error", message: "Invalid authentication" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const sellerId = userData.user.id;

    // Get seller wallet with row lock to prevent race conditions
    const { data: wallet, error: walletError } = await supabase
      .from('seller_wallets')
      .select('*')
      .eq('seller_id', sellerId)
      .single();

    if (walletError || !wallet) {
      return new Response(
        JSON.stringify({ status: "error", message: "Wallet not found" }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check balance
    if (wallet.available_balance < amount) {
      return new Response(
        JSON.stringify({ 
          status: "error", 
          message: `Insufficient balance. Available: ₦${wallet.available_balance.toLocaleString()}` 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get verified bank details
    const { data: bankDetails, error: bankError } = await supabase
      .from('seller_bank_details')
      .select('*')
      .eq('seller_id', sellerId)
      .eq('verification_status', 'verified')
      .single();

    if (bankError || !bankDetails) {
      return new Response(
        JSON.stringify({ 
          status: "error", 
          message: "No verified bank account found. Please add and verify your bank account first." 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Calculate withdrawal fee (Flutterwave transfer fee)
    // Typically ₦10.75 for amounts below ₦5,000, ₦26.88 for amounts between ₦5,001 and ₦50,000
    let transferFee = 10.75;
    if (amount > 5000 && amount <= 50000) {
      transferFee = 26.88;
    } else if (amount > 50000) {
      transferFee = 53.75;
    }

    const netAmount = amount - transferFee;

    if (netAmount <= 0) {
      return new Response(
        JSON.stringify({ 
          status: "error", 
          message: "Amount too low after transfer fees" 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Deduct from wallet first
    const newBalance = wallet.available_balance - amount;
    const newWithdrawn = wallet.total_withdrawn + amount;

    const { error: updateError } = await supabase
      .from('seller_wallets')
      .update({
        available_balance: newBalance,
        total_withdrawn: newWithdrawn,
        updated_at: new Date().toISOString()
      })
      .eq('id', wallet.id)
      .eq('available_balance', wallet.available_balance); // Optimistic lock

    if (updateError) {
      return new Response(
        JSON.stringify({ status: "error", message: "Balance changed during withdrawal. Please try again." }),
        { status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const payoutRef = `WD-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    // Log wallet transaction
    await supabase
      .from('wallet_transactions')
      .insert({
        wallet_id: wallet.id,
        transaction_type: 'withdrawal',
        amount: -amount,
        balance_before: wallet.available_balance,
        balance_after: newBalance,
        balance_type: 'available',
        description: `Withdrawal to ${bankDetails.bank_name} - ${bankDetails.account_number}`,
        reference: payoutRef
      });

    // Create payout record
    const { data: payout, error: payoutError } = await supabase
      .from('payouts')
      .insert({
        payout_reference: payoutRef,
        seller_id: sellerId,
        amount: netAmount,
        bank_code: bankDetails.bank_code,
        account_number: bankDetails.account_number,
        account_name: bankDetails.account_name,
        status: 'pending'
      })
      .select()
      .single();

    if (payoutError) {
      console.error("Error creating payout record:", payoutError);
      // Refund wallet
      await supabase
        .from('seller_wallets')
        .update({
          available_balance: wallet.available_balance,
          total_withdrawn: wallet.total_withdrawn,
          updated_at: new Date().toISOString()
        })
        .eq('id', wallet.id);

      return new Response(
        JSON.stringify({ status: "error", message: "Failed to create payout" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initiate Flutterwave transfer
    const transferResponse = await fetch(
      'https://api.flutterwave.com/v3/transfers',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${secretKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          account_bank: bankDetails.bank_code,
          account_number: bankDetails.account_number,
          amount: netAmount,
          narration: `CampNode withdrawal`,
          currency: 'NGN',
          reference: payoutRef,
          debit_currency: 'NGN'
        })
      }
    );

    const transferData = await transferResponse.json();
    console.log("Transfer response:", JSON.stringify(transferData));

    if (transferData.status === "success") {
      await supabase
        .from('payouts')
        .update({
          flutterwave_reference: transferData.data?.id?.toString(),
          status: 'processing'
        })
        .eq('id', payout.id);

      return new Response(
        JSON.stringify({
          status: "success",
          message: "Withdrawal initiated successfully",
          data: {
            reference: payoutRef,
            amount,
            transfer_fee: transferFee,
            net_amount: netAmount,
            status: 'processing'
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else {
      // Refund wallet on transfer failure
      await supabase
        .from('seller_wallets')
        .update({
          available_balance: wallet.available_balance,
          total_withdrawn: wallet.total_withdrawn,
          updated_at: new Date().toISOString()
        })
        .eq('id', wallet.id);

      await supabase
        .from('payouts')
        .update({
          status: 'failed',
          failure_reason: transferData.message || 'Transfer initiation failed'
        })
        .eq('id', payout.id);

      return new Response(
        JSON.stringify({ 
          status: "error", 
          message: transferData.message || "Transfer failed" 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

  } catch (error: unknown) {
    console.error("Withdrawal error:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ status: "error", message: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
