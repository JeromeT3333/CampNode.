import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Platform configuration
const PLATFORM_FEE_PERCENT = 5; // 5% service fee
const VAT_PERCENT = 1.5; // 1.5% VAT
const MIN_ESCROW_PRICE = 500; // ₦500 minimum for escrow
const SUPPORTED_CURRENCIES = ['NGN', 'USD', 'GHS', 'KES'];

interface PaymentRequest {
  product_id: string;
  quantity: number;
  buyer_email: string;
  buyer_name?: string;
  buyer_phone?: string;
  currency?: string;
  redirect_url?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body: PaymentRequest = await req.json();
    const { product_id, quantity = 1, buyer_email, buyer_name, buyer_phone, currency = 'NGN', redirect_url } = body;

    if (!product_id || !buyer_email) {
      return new Response(
        JSON.stringify({ status: "error", message: "Product ID and buyer email are required" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!SUPPORTED_CURRENCIES.includes(currency)) {
      return new Response(
        JSON.stringify({ status: "error", message: `Unsupported currency. Supported: ${SUPPORTED_CURRENCIES.join(', ')}` }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const publicKey = Deno.env.get('FLUTTERWAVE_PUBLIC_KEY');
    const secretKey = Deno.env.get('FLUTTERWAVE_SECRET_KEY');

    if (!publicKey || !secretKey) {
      return new Response(
        JSON.stringify({ status: "error", message: "Payment gateway not configured" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get authenticated user
    const authHeader = req.headers.get('authorization');
    let buyerId: string | null = null;
    
    if (authHeader) {
      const token = authHeader.replace('Bearer ', '');
      const { data: userData } = await supabase.auth.getUser(token);
      if (userData?.user) {
        buyerId = userData.user.id;
      }
    }

    if (!buyerId) {
      return new Response(
        JSON.stringify({ status: "error", message: "Authentication required to make a purchase" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get product details
    const { data: product, error: productError } = await supabase
      .from('products')
      .select('*, shops(name)')
      .eq('id', product_id)
      .single();

    if (productError || !product) {
      return new Response(
        JSON.stringify({ status: "error", message: "Product not found" }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Prevent self-purchase
    if (buyerId === product.seller_id) {
      return new Response(
        JSON.stringify({ status: "error", message: "You cannot buy your own product" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Calculate pricing
    // P = product price, Buyer pays P × 1.05, Seller receives P × 0.95
    const productPrice = parseFloat(product.price) * quantity;
    const serviceFee = productPrice * (PLATFORM_FEE_PERCENT / 100); // 5% service fee
    const totalAmount = productPrice + serviceFee; // What buyer pays: P × 1.05
    const sellerAmount = productPrice * 0.95; // What seller receives: P × 0.95

    // Check minimum escrow price
    const useEscrow = productPrice >= MIN_ESCROW_PRICE;

    // Calculate platform breakdown
    // From the 5% service fee: VAT (1.5%) + Flutterwave fees + platform commission
    const vatAmount = totalAmount * (VAT_PERCENT / 100);
    // Flutterwave fee is approximately 1.4% + ₦100 for local cards, but varies
    // We'll record actual fee from webhook
    const estimatedFlwFee = (totalAmount * 0.014) + 100;
    const estimatedPlatformCommission = serviceFee - vatAmount - estimatedFlwFee;

    const txRef = `CN-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    // Get seller's subaccount
    const { data: sellerSubaccount } = await supabase
      .from('seller_subaccounts')
      .select('subaccount_id')
      .eq('seller_id', product.seller_id)
      .eq('is_active', true)
      .single();

    // Create order record
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        buyer_id: buyerId,
        seller_id: product.seller_id,
        product_id: product.id,
        quantity,
        total_amount: totalAmount,
        service_fee: serviceFee,
        seller_amount: sellerAmount,
        status: 'pending',
        payment_status: 'pending',
        escrow_status: useEscrow ? 'pending' : 'not_applicable'
      })
      .select()
      .single();

    if (orderError) {
      console.error("Error creating order:", orderError);
      return new Response(
        JSON.stringify({ status: "error", message: "Failed to create order" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create transaction record
    const { error: txError } = await supabase
      .from('transactions')
      .insert({
        transaction_reference: txRef,
        seller_id: product.seller_id,
        buyer_id: buyerId,
        product_id: product.id,
        order_id: order.id,
        gross_amount: totalAmount,
        platform_fee: serviceFee,
        seller_amount: sellerAmount,
        currency,
        payment_status: 'pending'
      });

    if (txError) {
      console.error("Error creating transaction:", txError);
    }

    console.log(`Payment initialized: tx_ref=${txRef}, amount=${totalAmount}, seller_amount=${sellerAmount}`);

    // Build payment config with split if seller has subaccount
    // CampNode brand colors for Flutterwave theming
    const brandColors = {
      primary: "#2D9769", // Primary teal from --primary: 160 55% 40%
      secondary: "#7C5CD6", // Secondary purple from --secondary: 250 60% 55%
      accent: "#F59E0B", // Accent orange from --accent: 35 95% 55%
    };

    const paymentConfig: Record<string, unknown> = {
      public_key: publicKey,
      tx_ref: txRef,
      amount: totalAmount,
      currency,
      customer: {
        email: buyer_email,
        name: buyer_name || buyer_email.split('@')[0],
        phone_number: buyer_phone || ""
      },
      customizations: {
        title: "CampNode",
        description: `Payment for ${product.name}`,
        logo: "https://campnode.lovable.app/logo.png",
        // Flutterwave theming to match CampNode brand
        theme: {
          primary_color: brandColors.primary,
          secondary_color: brandColors.secondary,
        }
      },
      redirect_url: redirect_url || `${supabaseUrl.replace('.supabase.co', '.lovable.app')}/payment-complete`,
      meta: {
        order_id: order.id,
        product_id: product.id,
        seller_id: product.seller_id,
        use_escrow: useEscrow,
        brand_color: brandColors.primary
      }
    };

    // Add split payment if seller has subaccount
    if (sellerSubaccount) {
      paymentConfig.subaccounts = [
        {
          id: sellerSubaccount.subaccount_id,
          transaction_split_ratio: 95 // Seller gets 95% of product price
        }
      ];
    }

    return new Response(
      JSON.stringify({
        status: "success",
        data: {
          ...paymentConfig,
          order_id: order.id,
          product_name: product.name,
          seller_id: product.seller_id,
          use_escrow: useEscrow,
          breakdown: {
            product_price: productPrice,
            service_fee: serviceFee,
            total_amount: totalAmount,
            seller_receives: sellerAmount,
            vat_estimate: vatAmount,
            platform_estimate: estimatedPlatformCommission
          }
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error("Error processing payment:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ status: "error", message: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
