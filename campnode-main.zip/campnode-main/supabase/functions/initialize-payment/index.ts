import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { product_id, quantity, buyer_email, buyer_name, buyer_phone, redirect_url } = await req.json();

    if (!product_id || !buyer_email) {
      return new Response(
        JSON.stringify({ status: "error", message: "Product ID and buyer email are required" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const publicKey = Deno.env.get('FLUTTERWAVE_PUBLIC_KEY');
    const secretKey = Deno.env.get('FLUTTERWAVE_SECRET_KEY');

    if (!publicKey || !secretKey) {
      console.error("Flutterwave keys not configured");
      return new Response(
        JSON.stringify({ status: "error", message: "Payment gateway not configured" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get product details
    const { data: product, error: productError } = await supabase
      .from('products')
      .select('*, shops(name)')
      .eq('id', product_id)
      .single();

    if (productError || !product) {
      console.error("Product not found:", productError);
      return new Response(
        JSON.stringify({ status: "error", message: "Product not found" }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get authorization header to extract user
    const authHeader = req.headers.get('authorization');
    let buyerId = null;
    
    if (authHeader) {
      const token = authHeader.replace('Bearer ', '');
      const { data: userData, error: authError } = await supabase.auth.getUser(token);
      if (!authError && userData?.user) {
        buyerId = userData.user.id;
      }
    }

    // Require authentication for payment
    if (!buyerId) {
      return new Response(
        JSON.stringify({ status: "error", message: "Authentication required to make a purchase" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Prevent buying own product
    if (buyerId === product.seller_id) {
      return new Response(
        JSON.stringify({ status: "error", message: "You cannot buy your own product" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const qty = quantity || 1;
    const totalAmount = parseFloat(product.price) * qty;
    const txRef = `CAMPNODE-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    // Get platform fee
    const { data: settings } = await supabase
      .from('platform_settings')
      .select('setting_value')
      .eq('setting_key', 'platform_fee_percentage')
      .single();
    
    const feePercentage = settings ? parseFloat(settings.setting_value) : 5;
    const platformFee = (totalAmount * feePercentage) / 100;
    const sellerAmount = totalAmount - platformFee;

    // Create order
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        buyer_id: buyerId,
        seller_id: product.seller_id,
        product_id: product.id,
        quantity: qty,
        total_amount: totalAmount,
        status: 'pending',
        payment_status: 'pending'
      })
      .select()
      .single();

    if (orderError) {
      console.error("Error creating order:", orderError);
      return new Response(
        JSON.stringify({ status: "error", message: "Failed to create order" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create transaction record
    const { error: txError } = await supabase
      .from('transactions')
      .insert({
        transaction_reference: txRef,
        seller_id: product.seller_id,
        buyer_id: buyerId,
        product_id: product.id,
        order_id: order.id,
        gross_amount: totalAmount,
        platform_fee: platformFee,
        seller_amount: sellerAmount,
        payment_status: 'pending'
      });

    if (txError) {
      console.error("Error creating transaction:", txError);
    }

    console.log(`Payment initialized: tx_ref=${txRef}, amount=${totalAmount}, buyer=${buyerId}`);

    // Return payment config for Flutterwave checkout
    return new Response(
      JSON.stringify({
        status: "success",
        data: {
          public_key: publicKey,
          tx_ref: txRef,
          amount: totalAmount,
          currency: "NGN",
          customer: {
            email: buyer_email,
            name: buyer_name || buyer_email.split('@')[0],
            phone_number: buyer_phone || ""
          },
          customizations: {
            title: "CampNode",
            description: `Payment for ${product.name}`,
            logo: "https://campnode.lovable.app/logo.png"
          },
          redirect_url: redirect_url || `${supabaseUrl.replace('.supabase.co', '.lovable.app')}/payment-complete`,
          order_id: order.id,
          product_name: product.name,
          seller_id: product.seller_id
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    console.error("Error initializing payment:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ status: "error", message: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
