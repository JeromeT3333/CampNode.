-- Add opening and closing hours to shops
ALTER TABLE public.shops 
ADD COLUMN IF NOT EXISTS opening_time TIME DEFAULT '08:00:00',
ADD COLUMN IF NOT EXISTS closing_time TIME DEFAULT '18:00:00',
ADD COLUMN IF NOT EXISTS is_open_24hrs BOOLEAN DEFAULT false;

-- Add available colors and sizes to products (as arrays)
ALTER TABLE public.products
ADD COLUMN IF NOT EXISTS available_colors TEXT[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS available_sizes TEXT[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS additional_images TEXT[] DEFAULT '{}';