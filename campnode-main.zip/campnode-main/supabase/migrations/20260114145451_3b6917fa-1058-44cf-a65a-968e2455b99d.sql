-- Add attachment columns to messages table
ALTER TABLE public.messages 
  ADD COLUMN IF NOT EXISTS message_type TEXT NOT NULL DEFAULT 'text',
  ADD COLUMN IF NOT EXISTS attachment_url TEXT,
  ALTER COLUMN content DROP NOT NULL;

-- Add check constraint for message types
ALTER TABLE public.messages 
  ADD CONSTRAINT messages_type_check 
  CHECK (message_type IN ('text', 'image', 'voice'));

-- Create chat attachments storage bucket
INSERT INTO storage.buckets (id, name, public) 
VALUES ('chat-attachments', 'chat-attachments', false)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for chat attachments bucket
-- Users can upload to their own folder
CREATE POLICY "Users can upload chat attachments"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'chat-attachments' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can view attachments from conversations they're part of
CREATE POLICY "Users can view chat attachments"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'chat-attachments'
  AND (
    auth.uid()::text = (storage.foldername(name))[1]
    OR EXISTS (
      SELECT 1 FROM public.conversations c
      WHERE c.id::text = (storage.foldername(name))[2]
      AND (c.buyer_id = auth.uid() OR c.seller_id = auth.uid())
    )
  )
);

-- Users can delete their own attachments
CREATE POLICY "Users can delete own chat attachments"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'chat-attachments'
  AND auth.uid()::text = (storage.foldername(name))[1]
);