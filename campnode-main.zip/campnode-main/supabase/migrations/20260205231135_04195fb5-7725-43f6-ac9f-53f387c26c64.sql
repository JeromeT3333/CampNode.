-- Create seller_wallets table for virtual wallet balances
CREATE TABLE public.seller_wallets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  seller_id UUID NOT NULL UNIQUE,
  pending_balance NUMERIC NOT NULL DEFAULT 0 CHECK (pending_balance >= 0),
  available_balance NUMERIC NOT NULL DEFAULT 0 CHECK (available_balance >= 0),
  total_earnings NUMERIC NOT NULL DEFAULT 0 CHECK (total_earnings >= 0),
  total_withdrawn NUMERIC NOT NULL DEFAULT 0 CHECK (total_withdrawn >= 0),
  currency TEXT NOT NULL DEFAULT 'NGN',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create wallet_transactions table as a complete ledger
CREATE TABLE public.wallet_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_id UUID NOT NULL REFERENCES public.seller_wallets(id) ON DELETE CASCADE,
  order_id UUID REFERENCES public.orders(id),
  transaction_type TEXT NOT NULL, -- 'escrow_credit', 'escrow_release', 'withdrawal', 'internal_purchase', 'refund'
  amount NUMERIC NOT NULL,
  balance_before NUMERIC NOT NULL,
  balance_after NUMERIC NOT NULL,
  balance_type TEXT NOT NULL, -- 'pending' or 'available'
  description TEXT,
  reference TEXT,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create seller_subaccounts table to store Flutterwave subaccount IDs
CREATE TABLE public.seller_subaccounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  seller_id UUID NOT NULL UNIQUE,
  subaccount_id TEXT NOT NULL, -- Flutterwave subaccount ID
  business_name TEXT,
  split_value NUMERIC NOT NULL DEFAULT 95, -- Seller gets 95% (P × 0.95)
  split_type TEXT NOT NULL DEFAULT 'percentage',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create escrow_orders table for tracking escrow state
CREATE TABLE public.escrow_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL UNIQUE REFERENCES public.orders(id) ON DELETE CASCADE,
  seller_id UUID NOT NULL,
  buyer_id UUID NOT NULL,
  product_price NUMERIC NOT NULL, -- Original product price (P)
  service_fee NUMERIC NOT NULL, -- 5% of P paid by buyer
  seller_amount NUMERIC NOT NULL, -- P × 0.95 (what seller receives)
  platform_amount NUMERIC NOT NULL, -- Remaining after Flutterwave fees
  flutterwave_fee NUMERIC, -- Actual Flutterwave fee charged
  vat_amount NUMERIC, -- 1.5% VAT
  escrow_status TEXT NOT NULL DEFAULT 'held', -- 'held', 'released', 'refunded', 'disputed'
  held_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  released_at TIMESTAMP WITH TIME ZONE,
  confirmed_by UUID, -- Buyer who confirmed
  confirmed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create platform_wallet for accumulating platform earnings
CREATE TABLE public.platform_wallet (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  balance NUMERIC NOT NULL DEFAULT 0 CHECK (balance >= 0),
  total_earnings NUMERIC NOT NULL DEFAULT 0 CHECK (total_earnings >= 0),
  total_withdrawn NUMERIC NOT NULL DEFAULT 0 CHECK (total_withdrawn >= 0),
  currency TEXT NOT NULL DEFAULT 'NGN',
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create platform_wallet_transactions for platform ledger
CREATE TABLE public.platform_wallet_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  transaction_type TEXT NOT NULL, -- 'commission', 'withdrawal', 'fee_refund'
  amount NUMERIC NOT NULL,
  balance_before NUMERIC NOT NULL,
  balance_after NUMERIC NOT NULL,
  order_id UUID REFERENCES public.orders(id),
  reference TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create webhook_logs for audit trail
CREATE TABLE public.webhook_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_type TEXT NOT NULL,
  payload JSONB NOT NULL,
  status TEXT NOT NULL DEFAULT 'received', -- 'received', 'processed', 'failed', 'duplicate'
  error_message TEXT,
  processed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add escrow-related columns to orders table
ALTER TABLE public.orders 
ADD COLUMN IF NOT EXISTS escrow_status TEXT DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS buyer_confirmed_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS service_fee NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS seller_amount NUMERIC;

-- Enable RLS on all new tables
ALTER TABLE public.seller_wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seller_subaccounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.escrow_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_wallet ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.webhook_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for seller_wallets
CREATE POLICY "Sellers can view their own wallet"
ON public.seller_wallets FOR SELECT
USING (auth.uid() = seller_id);

CREATE POLICY "System can insert wallets"
ON public.seller_wallets FOR INSERT
WITH CHECK (true);

CREATE POLICY "System can update wallets"
ON public.seller_wallets FOR UPDATE
USING (true);

-- RLS Policies for wallet_transactions
CREATE POLICY "Sellers can view their wallet transactions"
ON public.wallet_transactions FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.seller_wallets
    WHERE seller_wallets.id = wallet_transactions.wallet_id
    AND seller_wallets.seller_id = auth.uid()
  )
);

CREATE POLICY "System can insert wallet transactions"
ON public.wallet_transactions FOR INSERT
WITH CHECK (true);

-- RLS Policies for seller_subaccounts
CREATE POLICY "Sellers can view their own subaccount"
ON public.seller_subaccounts FOR SELECT
USING (auth.uid() = seller_id);

CREATE POLICY "System can manage subaccounts"
ON public.seller_subaccounts FOR ALL
USING (true);

-- RLS Policies for escrow_orders
CREATE POLICY "Users can view their escrow orders"
ON public.escrow_orders FOR SELECT
USING (auth.uid() = seller_id OR auth.uid() = buyer_id);

CREATE POLICY "Admins can view all escrow orders"
ON public.escrow_orders FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "System can manage escrow orders"
ON public.escrow_orders FOR ALL
USING (true);

-- RLS Policies for platform_wallet (admin only)
CREATE POLICY "Admins can view platform wallet"
ON public.platform_wallet FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage platform wallet"
ON public.platform_wallet FOR ALL
USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for platform_wallet_transactions (admin only)
CREATE POLICY "Admins can view platform transactions"
ON public.platform_wallet_transactions FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "System can insert platform transactions"
ON public.platform_wallet_transactions FOR INSERT
WITH CHECK (true);

-- RLS Policies for webhook_logs (admin only)
CREATE POLICY "Admins can view webhook logs"
ON public.webhook_logs FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "System can manage webhook logs"
ON public.webhook_logs FOR ALL
USING (true);

-- Create function to initialize seller wallet
CREATE OR REPLACE FUNCTION public.initialize_seller_wallet(p_seller_id UUID)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  wallet_id UUID;
BEGIN
  -- Check if wallet already exists
  SELECT id INTO wallet_id FROM seller_wallets WHERE seller_id = p_seller_id;
  
  IF wallet_id IS NULL THEN
    INSERT INTO seller_wallets (seller_id)
    VALUES (p_seller_id)
    RETURNING id INTO wallet_id;
  END IF;
  
  RETURN wallet_id;
END;
$$;

-- Create function to release escrow to seller
CREATE OR REPLACE FUNCTION public.release_escrow(p_order_id UUID, p_buyer_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_escrow RECORD;
  v_wallet RECORD;
  v_new_available NUMERIC;
BEGIN
  -- Get escrow record
  SELECT * INTO v_escrow FROM escrow_orders 
  WHERE order_id = p_order_id AND buyer_id = p_buyer_id AND escrow_status = 'held';
  
  IF v_escrow IS NULL THEN
    RAISE EXCEPTION 'Escrow not found or already released';
  END IF;
  
  -- Get seller wallet
  SELECT * INTO v_wallet FROM seller_wallets WHERE seller_id = v_escrow.seller_id FOR UPDATE;
  
  IF v_wallet IS NULL THEN
    RAISE EXCEPTION 'Seller wallet not found';
  END IF;
  
  -- Calculate new balances
  v_new_available := v_wallet.available_balance + v_escrow.seller_amount;
  
  -- Move from pending to available
  UPDATE seller_wallets SET
    pending_balance = pending_balance - v_escrow.seller_amount,
    available_balance = v_new_available,
    updated_at = now()
  WHERE id = v_wallet.id;
  
  -- Log the transaction
  INSERT INTO wallet_transactions (
    wallet_id, order_id, transaction_type, amount, 
    balance_before, balance_after, balance_type, description
  ) VALUES (
    v_wallet.id, p_order_id, 'escrow_release', v_escrow.seller_amount,
    v_wallet.available_balance, v_new_available, 'available',
    'Escrow released after buyer confirmation'
  );
  
  -- Update escrow status
  UPDATE escrow_orders SET
    escrow_status = 'released',
    released_at = now(),
    confirmed_by = p_buyer_id,
    confirmed_at = now(),
    updated_at = now()
  WHERE id = v_escrow.id;
  
  -- Update order status
  UPDATE orders SET
    escrow_status = 'released',
    buyer_confirmed_at = now(),
    status = 'completed',
    updated_at = now()
  WHERE id = p_order_id;
  
  RETURN TRUE;
END;
$$;

-- Initialize platform wallet with single row
INSERT INTO public.platform_wallet (id) VALUES (gen_random_uuid())
ON CONFLICT DO NOTHING;

-- Create trigger for updated_at on seller_wallets
CREATE TRIGGER update_seller_wallets_updated_at
BEFORE UPDATE ON public.seller_wallets
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create trigger for updated_at on escrow_orders
CREATE TRIGGER update_escrow_orders_updated_at
BEFORE UPDATE ON public.escrow_orders
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();