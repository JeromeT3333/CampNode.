-- Add gif_url and gif_interval columns to products table
ALTER TABLE public.products
ADD COLUMN IF NOT EXISTS gif_url text,
ADD COLUMN IF NOT EXISTS gif_interval integer DEFAULT 3000;