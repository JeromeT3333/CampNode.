-- Create seller_bank_details table for verified bank accounts
CREATE TABLE public.seller_bank_details (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  bank_code text NOT NULL,
  bank_name text NOT NULL,
  account_number text NOT NULL,
  account_name text NOT NULL,
  verification_status text NOT NULL DEFAULT 'pending',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(seller_id)
);

-- Enable RLS
ALTER TABLE public.seller_bank_details ENABLE ROW LEVEL SECURITY;

-- RLS Policies for seller_bank_details
CREATE POLICY "Users can view their own bank details"
ON public.seller_bank_details
FOR SELECT
USING (auth.uid() = seller_id);

CREATE POLICY "Users can insert their own bank details"
ON public.seller_bank_details
FOR INSERT
WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Users can update their own bank details"
ON public.seller_bank_details
FOR UPDATE
USING (auth.uid() = seller_id);

-- Create transactions table for payment records
CREATE TABLE public.transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_reference text UNIQUE NOT NULL,
  flutterwave_reference text,
  seller_id uuid NOT NULL,
  buyer_id uuid NOT NULL,
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  gross_amount numeric NOT NULL,
  platform_fee numeric NOT NULL,
  seller_amount numeric NOT NULL,
  currency text NOT NULL DEFAULT 'NGN',
  payment_status text NOT NULL DEFAULT 'pending',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for transactions
CREATE POLICY "Users can view their transactions"
ON public.transactions
FOR SELECT
USING (auth.uid() = seller_id OR auth.uid() = buyer_id);

CREATE POLICY "System can insert transactions"
ON public.transactions
FOR INSERT
WITH CHECK (true);

-- Create payouts table
CREATE TABLE public.payouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payout_reference text UNIQUE NOT NULL,
  flutterwave_reference text,
  transaction_id uuid REFERENCES public.transactions(id) ON DELETE SET NULL,
  seller_id uuid NOT NULL,
  amount numeric NOT NULL,
  currency text NOT NULL DEFAULT 'NGN',
  bank_code text NOT NULL,
  account_number text NOT NULL,
  account_name text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  failure_reason text,
  retry_count integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.payouts ENABLE ROW LEVEL SECURITY;

-- RLS Policies for payouts
CREATE POLICY "Sellers can view their own payouts"
ON public.payouts
FOR SELECT
USING (auth.uid() = seller_id);

-- Create platform_settings table for configurable fees
CREATE TABLE public.platform_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;

-- Allow public read for platform settings
CREATE POLICY "Platform settings are viewable by everyone"
ON public.platform_settings
FOR SELECT
USING (true);

-- Insert default platform fee (5%)
INSERT INTO public.platform_settings (setting_key, setting_value) 
VALUES ('platform_fee_percentage', '5');

-- Create triggers for updated_at
CREATE TRIGGER update_seller_bank_details_updated_at
BEFORE UPDATE ON public.seller_bank_details
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_transactions_updated_at
BEFORE UPDATE ON public.transactions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_payouts_updated_at
BEFORE UPDATE ON public.payouts
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_platform_settings_updated_at
BEFORE UPDATE ON public.platform_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();