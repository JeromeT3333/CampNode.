-- Create a system account for CampNode official support
CREATE TABLE IF NOT EXISTS public.system_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_type TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  avatar_url TEXT,
  is_verified BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.system_accounts ENABLE ROW LEVEL SECURITY;

-- Everyone can view system accounts
CREATE POLICY "System accounts viewable by everyone"
ON public.system_accounts FOR SELECT
USING (true);

-- Only admins can modify system accounts
CREATE POLICY "Admins can manage system accounts"
ON public.system_accounts FOR ALL
USING (has_role(auth.uid(), 'admin'));

-- Insert CampNode support account
INSERT INTO public.system_accounts (account_type, display_name, avatar_url, is_verified)
VALUES ('campnode_support', 'CampNode', NULL, true)
ON CONFLICT (account_type) DO NOTHING;

-- Create table for account restrictions
CREATE TABLE IF NOT EXISTS public.account_restrictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  restriction_type TEXT NOT NULL DEFAULT 'suspended',
  reason TEXT,
  restricted_by UUID NOT NULL,
  restricted_at TIMESTAMPTZ DEFAULT now(),
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT true,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.account_restrictions ENABLE ROW LEVEL SECURITY;

-- Users can view their own restrictions
CREATE POLICY "Users can view their own restrictions"
ON public.account_restrictions FOR SELECT
USING (auth.uid() = user_id);

-- Support and admins can view all restrictions
CREATE POLICY "Support can view all restrictions"
ON public.account_restrictions FOR SELECT
USING (has_role(auth.uid(), 'support') OR has_role(auth.uid(), 'admin'));

-- Support and admins can manage restrictions
CREATE POLICY "Support can manage restrictions"
ON public.account_restrictions FOR INSERT
WITH CHECK (has_role(auth.uid(), 'support') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Support can update restrictions"
ON public.account_restrictions FOR UPDATE
USING (has_role(auth.uid(), 'support') OR has_role(auth.uid(), 'admin'));

-- Create premium memberships table
CREATE TABLE IF NOT EXISTS public.premium_memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE,
  tier TEXT NOT NULL DEFAULT 'basic',
  started_at TIMESTAMPTZ DEFAULT now(),
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT true,
  enabled_by UUID,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.premium_memberships ENABLE ROW LEVEL SECURITY;

-- Users can view their own membership
CREATE POLICY "Users can view their own membership"
ON public.premium_memberships FOR SELECT
USING (auth.uid() = user_id);

-- Admins can manage memberships
CREATE POLICY "Admins can manage memberships"
ON public.premium_memberships FOR ALL
USING (has_role(auth.uid(), 'admin'));

-- Create support authorization tokens (for when user authorizes support to view their account)
CREATE TABLE IF NOT EXISTS public.support_auth_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  token TEXT NOT NULL UNIQUE,
  authorized_scope TEXT[] DEFAULT ARRAY['basic'],
  expires_at TIMESTAMPTZ NOT NULL,
  used_by UUID,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.support_auth_tokens ENABLE ROW LEVEL SECURITY;

-- Users can create and view their own tokens
CREATE POLICY "Users can manage their own tokens"
ON public.support_auth_tokens FOR ALL
USING (auth.uid() = user_id);

-- Support can view tokens (to verify them)
CREATE POLICY "Support can view tokens"
ON public.support_auth_tokens FOR SELECT
USING (has_role(auth.uid(), 'support') OR has_role(auth.uid(), 'admin'));

-- Support can update tokens when verifying
CREATE POLICY "Support can update tokens"
ON public.support_auth_tokens FOR UPDATE
USING (has_role(auth.uid(), 'support') OR has_role(auth.uid(), 'admin'));

-- Create broadcast messages table (for sending messages to all users)
CREATE TABLE IF NOT EXISTS public.broadcast_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  sent_by UUID NOT NULL,
  target_audience TEXT DEFAULT 'all',
  scheduled_at TIMESTAMPTZ,
  sent_at TIMESTAMPTZ,
  is_sent BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.broadcast_messages ENABLE ROW LEVEL SECURITY;

-- Admins can manage broadcasts
CREATE POLICY "Admins can manage broadcasts"
ON public.broadcast_messages FOR ALL
USING (has_role(auth.uid(), 'admin'));

-- Update triggers for new tables
CREATE TRIGGER update_account_restrictions_updated_at
BEFORE UPDATE ON public.account_restrictions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_premium_memberships_updated_at
BEFORE UPDATE ON public.premium_memberships
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();