-- Add optional order_id to conversations (allow direct messages without orders)
ALTER TABLE public.conversations 
  ALTER COLUMN order_id DROP NOT NULL;

-- Add unique constraint for direct conversations between two users
CREATE UNIQUE INDEX IF NOT EXISTS conversations_direct_unique 
  ON public.conversations (LEAST(buyer_id, seller_id), GREATEST(buyer_id, seller_id))
  WHERE order_id IS NULL;

-- Update conversations RLS to allow creating direct conversations
DROP POLICY IF EXISTS "System can create conversations" ON public.conversations;
CREATE POLICY "Users can create conversations"
  ON public.conversations
  FOR INSERT
  WITH CHECK (auth.uid() = buyer_id OR auth.uid() = seller_id);

-- Add trigger to send notification on new message
CREATE OR REPLACE FUNCTION public.notify_new_message()
RETURNS TRIGGER AS $$
DECLARE
  recipient_id UUID;
  sender_name TEXT;
  conv RECORD;
BEGIN
  -- Get conversation details
  SELECT * INTO conv FROM public.conversations WHERE id = NEW.conversation_id;
  
  -- Determine recipient (the other user in the conversation)
  IF NEW.sender_id = conv.buyer_id THEN
    recipient_id := conv.seller_id;
  ELSE
    recipient_id := conv.buyer_id;
  END IF;

  -- Get sender name
  SELECT full_name INTO sender_name 
  FROM public.profiles 
  WHERE user_id = NEW.sender_id;

  -- Create notification for recipient
  INSERT INTO public.notifications (user_id, type, title, message, data)
  VALUES (
    recipient_id,
    'message',
    'New Message',
    COALESCE(sender_name, 'Someone') || ' sent you a message',
    jsonb_build_object(
      'conversation_id', NEW.conversation_id,
      'order_id', conv.order_id,
      'sender_id', NEW.sender_id,
      'message_type', NEW.message_type
    )
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for new messages
DROP TRIGGER IF EXISTS on_new_message ON public.messages;
CREATE TRIGGER on_new_message
  AFTER INSERT ON public.messages
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_new_message();