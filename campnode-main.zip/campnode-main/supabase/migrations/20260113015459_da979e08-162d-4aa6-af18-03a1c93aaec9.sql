-- Add policy to allow viewing public profile data
-- This is safe because sensitive data like emails are in auth.users (protected)
-- Phone numbers will be omitted from public queries in the application code

CREATE POLICY "Public profiles are viewable by everyone"
ON public.profiles
FOR SELECT
USING (true);