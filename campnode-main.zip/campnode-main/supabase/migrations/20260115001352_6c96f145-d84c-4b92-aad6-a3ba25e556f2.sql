-- Enable realtime for conversations table (skip messages as it's already added)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'conversations'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;
  END IF;
END $$;

-- Create typing_status table for real-time typing indicators
CREATE TABLE IF NOT EXISTS public.typing_status (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  is_typing BOOLEAN NOT NULL DEFAULT false,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create unique constraint for one typing status per user per conversation
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'typing_status_unique'
  ) THEN
    ALTER TABLE public.typing_status ADD CONSTRAINT typing_status_unique UNIQUE (conversation_id, user_id);
  END IF;
END $$;

-- Enable RLS on typing_status
ALTER TABLE public.typing_status ENABLE ROW LEVEL SECURITY;

-- RLS policies for typing_status
DROP POLICY IF EXISTS "Users can view typing status in their conversations" ON public.typing_status;
CREATE POLICY "Users can view typing status in their conversations"
ON public.typing_status FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.conversations c
    WHERE c.id = typing_status.conversation_id
    AND (c.buyer_id = auth.uid() OR c.seller_id = auth.uid())
  )
);

DROP POLICY IF EXISTS "Users can update their own typing status" ON public.typing_status;
CREATE POLICY "Users can update their own typing status"
ON public.typing_status FOR INSERT
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can modify their own typing status" ON public.typing_status;
CREATE POLICY "Users can modify their own typing status"
ON public.typing_status FOR UPDATE
USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can delete their own typing status" ON public.typing_status;
CREATE POLICY "Users can delete their own typing status"
ON public.typing_status FOR DELETE
USING (auth.uid() = user_id);

-- Enable realtime for typing_status
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'typing_status'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.typing_status;
  END IF;
END $$;

-- Add chat_theme column to conversations for per-conversation theming
ALTER TABLE public.conversations ADD COLUMN IF NOT EXISTS chat_theme TEXT DEFAULT 'default';

-- Create sticker packs table
CREATE TABLE IF NOT EXISTS public.sticker_packs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  preview_url TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create stickers table
CREATE TABLE IF NOT EXISTS public.stickers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  pack_id UUID NOT NULL REFERENCES public.sticker_packs(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  emoji TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on stickers tables
ALTER TABLE public.sticker_packs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stickers ENABLE ROW LEVEL SECURITY;

-- Stickers are viewable by everyone
DROP POLICY IF EXISTS "Sticker packs viewable by everyone" ON public.sticker_packs;
CREATE POLICY "Sticker packs viewable by everyone"
ON public.sticker_packs FOR SELECT
USING (true);

DROP POLICY IF EXISTS "Stickers viewable by everyone" ON public.stickers;
CREATE POLICY "Stickers viewable by everyone"
ON public.stickers FOR SELECT
USING (true);

-- Insert default sticker pack with emojis (only if not exists)
INSERT INTO public.sticker_packs (id, name, preview_url) VALUES
  ('11111111-1111-1111-1111-111111111111', 'Classic Emojis', '😊')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.stickers (pack_id, url, emoji) VALUES
  ('11111111-1111-1111-1111-111111111111', '😀', '😀'),
  ('11111111-1111-1111-1111-111111111111', '😂', '😂'),
  ('11111111-1111-1111-1111-111111111111', '🥰', '🥰'),
  ('11111111-1111-1111-1111-111111111111', '😍', '😍'),
  ('11111111-1111-1111-1111-111111111111', '🤔', '🤔'),
  ('11111111-1111-1111-1111-111111111111', '😢', '😢'),
  ('11111111-1111-1111-1111-111111111111', '😡', '😡'),
  ('11111111-1111-1111-1111-111111111111', '👍', '👍'),
  ('11111111-1111-1111-1111-111111111111', '👎', '👎'),
  ('11111111-1111-1111-1111-111111111111', '❤️', '❤️'),
  ('11111111-1111-1111-1111-111111111111', '🔥', '🔥'),
  ('11111111-1111-1111-1111-111111111111', '🎉', '🎉'),
  ('11111111-1111-1111-1111-111111111111', '👏', '👏'),
  ('11111111-1111-1111-1111-111111111111', '🙏', '🙏'),
  ('11111111-1111-1111-1111-111111111111', '💯', '💯'),
  ('11111111-1111-1111-1111-111111111111', '✨', '✨'),
  ('11111111-1111-1111-1111-111111111111', '🤝', '🤝'),
  ('11111111-1111-1111-1111-111111111111', '🙌', '🙌'),
  ('11111111-1111-1111-1111-111111111111', '💪', '💪'),
  ('11111111-1111-1111-1111-111111111111', '🤣', '🤣')
ON CONFLICT DO NOTHING;